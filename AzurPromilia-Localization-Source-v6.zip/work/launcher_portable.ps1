$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$originalHash = '30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa'
$patchedHash = '__FINAL_HASH__'
$knownHashes = @($originalHash, $patchedHash, '1b9de08cf73e5c44e98b26d06df58b7a0d36d2fb7629c6014b413f35c548c1e3', '67a4704230cc64b328e4945ce032b0417e7a17254e27eb0b7d5f8dc086e1367f')
$script:candidates = @{}

function Get-BytesHash([byte[]]$bytes) {
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}
function Get-PathHash([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose(); $stream.Dispose() }
}
function Read-Answer([string]$prompt) {
    Write-Host $prompt -NoNewline
    $answer = [Console]::ReadLine()
    if ($null -eq $answer) { return '' }
    return $answer.Trim().Trim('"')
}
function Add-Candidate([string]$hint, [int]$priority) {
    if ([string]::IsNullOrWhiteSpace($hint)) { return }
    try {
        $path = [IO.Path]::GetFullPath($hint.Trim().Trim('"'))
        if ([IO.File]::Exists($path)) {
            $path = [IO.Path]::GetDirectoryName($path)
            if ([IO.Path]::GetFileName($path) -eq 'resources') { $path = [IO.Path]::GetDirectoryName($path) }
        }
        if (-not [IO.Directory]::Exists($path)) { return }
        $directories = @($path)
        $directories += @([IO.Directory]::GetDirectories($path) | Where-Object { [IO.Path]::GetFileName($_) -match '^\d+\.\d+\.\d+(?:\.\d+)?$' })
        foreach ($directory in $directories) {
            $archive = Join-Path $directory 'resources\app.asar'
            $exe = Join-Path $directory 'launcher.exe'
            if ([IO.File]::Exists($archive) -and [IO.File]::Exists($exe)) {
                if (-not $script:candidates.ContainsKey($archive) -or $script:candidates[$archive].Priority -lt $priority) {
                    $script:candidates[$archive] = [PSCustomObject]@{ Archive = $archive; Exe = $exe; Directory = $directory; Root = [IO.Path]::GetDirectoryName($directory); Priority = $priority }
                }
            }
        }
    } catch { }
}
function Find-Launchers {
    Add-Candidate $env:AZUR_PATCH_HINT 1200
    $nearby = [IO.Path]::GetDirectoryName($env:AZUR_PATCH_SELF)
    for ($level = 0; $level -lt 4 -and $nearby; $level++) {
        Add-Candidate $nearby (1100 - $level)
        $parent = [IO.Directory]::GetParent($nearby)
        if ($null -eq $parent) { break }
        $nearby = $parent.FullName
    }
    try {
        foreach ($process in @(Get-CimInstance Win32_Process -Filter "Name = 'launcher.exe'" -ErrorAction Stop)) {
            Add-Candidate $process.ExecutablePath 800
        }
    } catch { }
    foreach ($registry in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
        foreach ($key in @(Get-ChildItem -LiteralPath $registry -ErrorAction SilentlyContinue)) {
            $entry = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
            if ($entry.DisplayName -match 'AzurPromilia|蓝色星原|藍色星原') {
                Add-Candidate $entry.InstallLocation 600
                if ($entry.DisplayIcon) { Add-Candidate ($entry.DisplayIcon -replace ',\s*-?\d+$', '') 600 }
            }
        }
    }
    try {
        $shortcutReader = New-Object -ComObject WScript.Shell
        foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('StartMenu'), [Environment]::GetFolderPath('CommonStartMenu'))) {
            if (-not $folder) { continue }
            foreach ($shortcut in @(Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'AzurPromilia|蓝色星原|藍色星原' })) {
                Add-Candidate ($shortcutReader.CreateShortcut($shortcut.FullName).TargetPath) 500
            }
        }
    } catch { }
    foreach ($drive in [IO.DriveInfo]::GetDrives()) {
        if (-not $drive.IsReady -or $drive.DriveType -notin @([IO.DriveType]::Fixed, [IO.DriveType]::Removable)) { continue }
        $driveRoot = $drive.RootDirectory.FullName
        $rootDirectories = @(Get-ChildItem -LiteralPath $driveRoot -Directory -ErrorAction SilentlyContinue)
        foreach ($directory in $rootDirectories) {
            if ($directory.Name -match 'AzurPromilia|蓝色星原|藍色星原') { Add-Candidate $directory.FullName 300 }
            elseif ($directory.Name -match '^(Games?|游戏|遊戲|Program Files(?: \(x86\))?)$') {
                foreach ($child in @(Get-ChildItem -LiteralPath $directory.FullName -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'AzurPromilia|蓝色星原|藍色星原' })) { Add-Candidate $child.FullName 300 }
            }
        }
    }
    $compatible = @()
    foreach ($candidate in $script:candidates.Values) {
        try {
            $hash = Get-PathHash $candidate.Archive
            if ($hash -in $knownHashes) {
                $candidate | Add-Member -NotePropertyName Hash -NotePropertyValue $hash
                $compatible += $candidate
            }
        } catch { }
    }
    return @($compatible | Sort-Object @{ Expression = 'Priority'; Descending = $true }, Archive)
}
function Select-Launcher {
    Write-Host '正在自动定位台服启动器……'
    if (-not [string]::IsNullOrWhiteSpace($env:AZUR_PATCH_HINT)) {
        Add-Candidate $env:AZUR_PATCH_HINT 1200
        foreach ($candidate in $script:candidates.Values) {
            if ((Get-PathHash $candidate.Archive) -in $knownHashes) { return $candidate }
        }
        throw '指定路径没有匹配的台服启动器 1.0.1.4，未修改任何文件。'
    }
    $found = @(Find-Launchers)
    if ($found.Count -eq 1) { return $found[0] }
    if ($found.Count -gt 1) {
        if ($found[0].Priority -ge 1000 -and $found[0].Priority -gt $found[1].Priority) { return $found[0] }
        Write-Host '找到多个匹配的台服启动器：'
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i + 1), $found[$i].Directory) }
        $answer = Read-Answer '请选择目录编号（Q 退出）：'
        if ($answer -eq 'q') { throw '已取消。' }
        $index = 0
        if (-not [int]::TryParse($answer, [ref]$index) -or $index -lt 1 -or $index -gt $found.Count) { throw '目录编号无效。' }
        return $found[$index - 1]
    }
    Write-Host '未自动找到匹配版本。可把本 BAT 放进游戏安装根目录，也可手动输入路径。' -ForegroundColor Yellow
    $manual = Read-Answer '请输入游戏根目录、启动器版本目录或 launcher.exe 路径（Q 退出）：'
    if (-not $manual -or $manual -eq 'q') { throw '已取消。' }
    $script:candidates = @{}
    Add-Candidate $manual 1200
    foreach ($candidate in $script:candidates.Values) {
        if ((Get-PathHash $candidate.Archive) -in $knownHashes) { return $candidate }
    }
    throw '该目录没有匹配的台服启动器 1.0.1.4，未修改任何文件。'
}
function Find-GameDirectory([string]$root) {
    $directories = @($root)
    $directories += @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    foreach ($directory in $directories) {
        if ([IO.File]::Exists((Join-Path $directory 'AzurPromilia.exe')) -and [IO.Directory]::Exists((Join-Path $directory 'AzurPromilia_Data'))) { return $directory }
    }
    return $null
}
function Invoke-LanguagePatch {
    try { [Console]::Title = '蓝色星原台服启动器 - 简体汉化与还原' } catch { }
    # 菜单文字：可以修改下列 Write-Host 后单引号内的显示内容。
    Write-Host ''
    Write-Host '=============================================='
    Write-Host '      台服启动器简体汉化 / 原版还原'
    Write-Host '=============================================='
    Write-Host '支持台服启动器 1.0.1.4，自动查找安装目录。'
    Write-Host '操作前请完全退出台服启动器，包括托盘图标。'
    Write-Host ''
    Write-Host '  1. 汉化为简体中文'
    Write-Host '  2. 还原原版启动器'
    Write-Host '  Q. 退出'
    Write-Host ''
    $action = Read-Answer '请输入选项并按回车：'
    if ($action -eq 'q') { return }
    if ($action -notin @('1', '2')) { throw '请输入 1 或 2，或输入 Q 退出。' }
    $launcher = Select-Launcher
    $launcherExe = $launcher.Exe
    $targetArchive = $launcher.Archive
    $backupArchive = $targetArchive + '.before-zhcn-20261124.bak'
    Write-Host ('已定位启动器：' + $launcher.Directory) -ForegroundColor Cyan
    $gameDirectory = Find-GameDirectory $launcher.Root
    if ($gameDirectory) { Write-Host ('已找到游戏本体：' + $gameDirectory) }
    else { Write-Host '游戏本体尚未找到；启动器汉化不依赖游戏下载完成。' }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'launcher.exe'" | Where-Object { $_.ExecutablePath -eq $launcherExe })
    if ($running.Count -gt 0) { throw '请先完全退出上述台服启动器（包括托盘图标），再运行本脚本。其他启动器可以继续下载。' }
    $currentHash = Get-PathHash $targetArchive
    if ($currentHash -notin $knownHashes) { throw '启动器文件已经变化，未修改任何文件。' }
    if ($action -eq '2' -and $currentHash -eq $originalHash) { Write-Host '当前已经是原版，无需还原。' -ForegroundColor Green; return }
    if ([IO.File]::Exists($backupArchive)) {
        if ((Get-PathHash $backupArchive) -ne $originalHash) { throw '原版备份校验失败，操作已停止。' }
    } elseif ($currentHash -eq $originalHash -and $action -eq '1') {
        [IO.File]::Copy($targetArchive, $backupArchive, $false)
        if ((Get-PathHash $backupArchive) -ne $originalHash) { throw '备份校验失败，操作已停止。' }
    } else { throw '未找到经过校验的原版备份，操作已停止。' }
    if ($action -eq '1' -and $currentHash -eq $patchedHash) { Write-Host '当前已经是完整简体汉化版本。' -ForegroundColor Green; return }
    $staging = $targetArchive + '.zhcn-oneclick.tmp'
    if (Test-Path -LiteralPath $staging) { throw "发现上次遗留的临时文件，请先检查：$staging" }
    if ($action -eq '2') {
        [IO.File]::Copy($backupArchive, $staging, $false)
        $expectedHash = $originalHash
    } else {
        Write-Host '正在校验并构建完整简体补丁……'
        $selfText = [IO.File]::ReadAllText($env:AZUR_PATCH_SELF)
        $base64 = ($selfText -split '(?m)^:__DATA__\r?$', 2)[1] -replace '\s', ''
        $compressed = [Convert]::FromBase64String($base64)
        $inputStream = New-Object IO.MemoryStream(,$compressed)
        $gzip = New-Object IO.Compression.GZipStream($inputStream, [IO.Compression.CompressionMode]::Decompress)
        $reader = New-Object IO.StreamReader($gzip, [Text.Encoding]::UTF8)
        try { $bundle = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose(); $gzip.Dispose(); $inputStream.Dispose() }
        $sourceBytes = [IO.File]::ReadAllBytes($backupArchive)
        $outputStream = New-Object IO.MemoryStream
        try {
            $header = [Convert]::FromBase64String($bundle.header)
            $outputStream.Write($header, 0, $header.Length)
            foreach ($operation in $bundle.operations) {
                if ($null -ne $operation.data) {
                    $block = [Convert]::FromBase64String($operation.data)
                    $outputStream.Write($block, 0, $block.Length)
                } else { $outputStream.Write($sourceBytes, [int]$operation.offset, [int]$operation.length) }
            }
            $patchedBytes = $outputStream.ToArray()
        } finally { $outputStream.Dispose() }
        if ((Get-BytesHash $patchedBytes) -ne $patchedHash) { throw '补丁构建校验失败，未写入启动器。' }
        [IO.File]::WriteAllBytes($staging, $patchedBytes)
        $expectedHash = $patchedHash
    }
    if ((Get-PathHash $staging) -ne $expectedHash) { throw '写入前校验失败，未替换启动器。' }
    Move-Item -LiteralPath $staging -Destination $targetArchive -Force
    if ((Get-PathHash $targetArchive) -ne $expectedHash) { throw '写入后校验失败，请保留原版备份。' }
    if ($action -eq '1') { Write-Host '简体汉化完成！现在可以正常打开台服启动器。' -ForegroundColor Green }
    else { Write-Host '已成功还原原版启动器。' -ForegroundColor Green }
    Write-Host ('原版备份：' + $backupArchive)
}
$exitCode = 0
try { Invoke-LanguagePatch }
catch { Write-Host ('操作停止：' + $_.Exception.Message) -ForegroundColor Red; $exitCode = 1 }
Write-Host ''
$null = Read-Answer '按回车关闭窗口……'
exit $exitCode
