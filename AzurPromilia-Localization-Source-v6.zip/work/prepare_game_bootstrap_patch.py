import base64,csv,difflib,hashlib,io,json,re,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent
sys.path.insert(0,str(HERE/'analysis_deps'))
import UnityPy
from opencc import OpenCC
TARGET=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\resources.assets')
ORIGINAL='f96fc1afe1675cdabd3c3d54008b539e89e3e65399511aa23cfc864b91c74d9f'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=TARGET.read_bytes();assert sha(source)==ORIGINAL
env=UnityPy.load(source)
obj=next(o for o in env.objects if o.type.name=='TextAsset' and o.path_id==209)
asset=obj.read();assert asset.m_Name=='builtInLangString'
script=asset.m_Script;old_script=script.encode('utf-8')
rows=list(csv.reader(io.StringIO(script.lstrip('\ufeff'))));assert rows[0]==['key','chs','cht','en','jp','kr']
assert len(rows)==114 and all(len(r)==6 for r in rows)
# Locate CSV cells without changing original quoting, separators or line endings.
cells=[];row=[];start=0;quoted=False;i=0
while i<len(script):
    char=script[i]
    if char=='"':
        if quoted and i+1<len(script) and script[i+1]=='"':i+=2;continue
        quoted=not quoted
    elif not quoted and char in ',\n':
        row.append((start,i))
        if char=='\n':cells.append(row);row=[]
        start=i+1
    i+=1
if start<len(script):row.append((start,len(script)))
if row:cells.append(row)
assert len(cells)==len(rows) and all(len(r)==6 for r in cells)
cc=OpenCC('t2s');replacements=[];changes=[]
for values,spans in zip(rows[1:],cells[1:]):
    key,chs,cht=values[:3];a,b=spans[2];raw=script[a:b]
    assert next(csv.reader([raw]))==[cht]
    def encode_field(text):
        if raw.startswith('"'):return '"'+text.replace('"','""')+'"'
        if any(c in text for c in ',\r\n"'):return None
        return text
    official=encode_field(chs)
    use_official=official is not None and len(official.encode())==len(raw.encode())
    after=chs if use_official else cc.convert(cht)
    encoded=encode_field(after)
    assert encoded is not None and len(encoded.encode())==len(raw.encode()),key
    assert sorted(re.findall(r'\{[^{}]*\}',after))==sorted(re.findall(r'\{[^{}]*\}',cht)),key
    if after!=cht:
        replacements.append((a,b,encoded))
        changes.append(dict(key=key,before=cht,after=after,method='builtin_chs' if use_official else 't2s'))
for a,b,after in reversed(replacements):script=script[:a]+after+script[b:]
new_script=script.encode('utf-8');assert len(new_script)==len(old_script)
new_rows=list(csv.reader(io.StringIO(script.lstrip('\ufeff'))))
assert len(new_rows)==len(rows)
for old,new in zip(rows,new_rows):
    assert old[:2]==new[:2] and old[3:]==new[3:]
raw=obj.get_raw_data();assert raw.count(old_script)==1
relative=raw.index(old_script);offset=obj.byte_start+relative
assert source[offset:offset+len(old_script)]==old_script
patched=source[:offset]+new_script+source[offset+len(old_script):]
assert len(patched)==len(source)
assert source[:offset]==patched[:offset] and source[offset+len(old_script):]==patched[offset+len(old_script):]
verify=UnityPy.load(patched);objects={o.path_id:o for o in verify.objects}
assert len(objects)==len(env.objects)
for original in env.objects:
    new=objects[original.path_id]
    if original.path_id==209:
        assert new.read().m_Script==script
    else:assert new.get_raw_data()==original.get_raw_data(),original.path_id
OUT=HERE.parent/'outputs'
(HERE/'game_bootstrap_zhcn.resources.assets').write_bytes(patched)
changes_path=OUT/'台服游戏启动文本简体对照.csv'
with changes_path.open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['key','before','after','method']);writer.writeheader();writer.writerows(changes)
manifest=dict(target=str(TARGET),original_sha256=ORIGINAL,patched_sha256=sha(patched),bytes=len(source),object_path_id=209,script_offset=offset,script_bytes=len(old_script),total_rows=len(rows)-1,changed_rows=len(changes),builtin_chs_rows=sum(c['method']=='builtin_chs' for c in changes),converted_rows=sum(c['method']=='t2s' for c in changes),other_objects_byte_identical=True,gameplay_text_covered=False,region_config_changed=False,applied=False)
(HERE/'game_bootstrap_patch.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
bundle=dict(manifest=manifest,offset=offset,before=base64.b64encode(old_script).decode(),after=base64.b64encode(new_script).decode())
(HERE/'game_bootstrap_patch_bundle.json').write_text(json.dumps(bundle,separators=(',',':')),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
