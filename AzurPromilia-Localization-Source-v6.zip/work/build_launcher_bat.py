import base64,gzip,json,struct,sys
from pathlib import Path
from patch_launcher_language import parse,entries,member_data,sha
HERE=Path(__file__).parent;OUT=HERE.parent/'outputs'
original=Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak').read_bytes()
patched=(HERE/'launcher_complete.app.asar').read_bytes()
oh,_,ob=parse(original);ph,_,pb=parse(patched);old=dict(entries(oh));operations=[]
for name,entry in entries(ph):
 if 'offset' not in entry:continue
 data=member_data(patched,entry,pb)
 if name in old and 'offset' in old[name] and member_data(original,old[name],ob)==data:
  operations.append({'offset':ob+int(old[name]['offset']),'length':len(data)})
 else: operations.append({'data':base64.b64encode(data).decode()})
bundle={'header':base64.b64encode(patched[:pb]).decode(),'operations':operations}
payload=base64.b64encode(gzip.compress(json.dumps(bundle,separators=(',',':')).encode(),mtime=0)).decode()
ps=(HERE/'launcher_portable.ps1').read_text('utf-8').replace('__FINAL_HASH__',sha(patched))
# Keep CMD's initial read-ahead region ASCII before the code-page switch.
bat='''@echo off
chcp 65001 >nul
setlocal
set "PSModulePath=%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\Modules"
set "AZUR_PATCH_SELF=%~f0"
set "AZUR_PATCH_HINT=%~1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:AZUR_PATCH_SELF,[Text.Encoding]::UTF8); $s=(($t -split '(?m)^:__SCRIPT__\\r?$',2)[1] -split '(?m)^:__DATA__\\r?$',2)[0]; & ([ScriptBlock]::Create($s))"
set "AZUR_PATCH_RESULT=%errorlevel%"
exit /b %AZUR_PATCH_RESULT%
'''+('rem ASCII bootstrap padding.\n'*400)+'''
:__SCRIPT__
'''+ps+'\n:__DATA__\n'+'\n'.join(payload[i:i+120] for i in range(0,len(payload),120))+'\n'
assert bat.split(':__SCRIPT__\n',1)[0].isascii()
target=OUT/'启动器简体汉化与还原.bat';target.write_bytes(bat.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
print(json.dumps({'bat':str(target),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'patched_sha256':sha(patched)},ensure_ascii=False))
