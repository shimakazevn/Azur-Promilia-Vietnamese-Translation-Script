from pathlib import Path
import sys,json,hashlib,collections,csv,io
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_compare_manifests'),str(BASE/'game_decrypt_paths'),str(BASE/'game_decrypt_bundle'),str(BASE/'analysis_deps'),str(BASE/'font_deps')]
from fontTools.ttLib import TTFont
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
from unity_setup import UnityPy
from parse_language_tables import read_index,read_rows
OUT=Path(__file__).resolve().parent
TW=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');CN=Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data')
def write(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
# ---------- 1. UI direct-text full summary by (object_id, field)
ui=collections.Counter();diffs=[];nocp=[];texts_ui=[]
with open(OUT/'serialized-ui-text-fields.jsonl',encoding='utf8') as f:
 for line in f:
  if not line.strip():continue
  r=json.loads(line);ui['bundles']+=1
  tw=r.get('tw_texts') or [];cn=r.get('cn_texts')
  path=(r.get('paths') or [''])[0]
  if cn is None:
   ui['bundles_without_cn_counterpart']+=1
   for t in tw:ui['fields_without_counterpart']+=1;nocp.append({'path':path,'object_id':t['object_id'],'game_object':t.get('game_object'),'field':t['field'],'text':t['text']});texts_ui.append(t['text'])
   continue
  ref={(t['object_id'],t['field']):t['text'] for t in cn}
  for t in tw:
   ui['fields']+=1;texts_ui.append(t['text']);k=(t['object_id'],t['field'])
   if k not in ref:ui['fields_no_cn_object']+=1;nocp.append({'path':path,'object_id':t['object_id'],'game_object':t.get('game_object'),'field':t['field'],'text':t['text']})
   elif ref[k]!=t['text']:ui['different']+=1;diffs.append({'path':path,'object_id':t['object_id'],'game_object':t.get('game_object'),'field':t['field'],'tw':t['text'],'cn':ref[k]})
   else:ui['identical']+=1
write('serialized-ui-differences.json',diffs);write('serialized-ui-no-counterpart.json',nocp)
# ---------- 2. font impact across all official text sources
old=TTFont(BASE/'game_decrypt_bundle/cn_a00.otf').getBestCmap();new=TTFont(BASE/'font_display_probe/a00_traditional_display_as_simplified.otf').getBestCmap()
remap={chr(cp) for cp in new if cp in old and old[cp]!=new[cp]}
sources=collections.defaultdict(list)
pool=VStringPool(BASE/'official_game_patch_v3/vstring-patched.bin');table=(BASE/'official_game_patch_v3/table-data-patched.bin').read_bytes();_,langs,_=read_index(table)
for name,off in langs['cht'].items():
 for row in read_rows(table,off,pool):
  if row['value']:sources['language_tables'].append((f'{name}:{row["id"]}',row['value']))
def static(root,prefix,ver,lang,poolfile):
 mp=root/f'.res/default_package/ManifestFiles/{prefix}_default_package_{ver}.bytes';m=parse(mp);sp=VStringPool(BASE/'game_mmap/decoded'/poolfile)
 a=next(a for a in m['assets'] if sp[a['path_key']]==f'Assets/ResourcesLang/{lang}/UI/StaticText/ast_staticTextKeyConfig.asset');b=m['bundles'][a['bundle']];pk=m['packs'][b['pack_id']];n=encode_name(pk['name0'],pk['name1']);p=root/'.res/default_package/BundleFiles'/n
 if not p.exists():p=root/'StreamingAssets/.res/default_package'/n
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 env=UnityPy.load(raw);return next(o for o in env.objects if o.type.name=='MonoBehaviour').read_typetree()['list']
tws=static(TW,'0release','3221745','cht','tw_update_v0k2cafcxjxawklow6skg.bin')
for r in tws:
 if r['value']:sources['statictext_installed'].append((r['key'],r['value']))
rows=list(csv.DictReader(io.StringIO((BASE/'game_compare/cn_builtInLangString.txt').read_text(encoding='utf-8-sig'))))
for r in rows:
 if r.get('chs'):sources['startup_csv_official_chs'].append((r['key'],r['chs']))
sources['startup_csv_official_chs'].append(('shader_loading','正在编译着色器'))
for i,t in enumerate(texts_ui):sources['ui_direct_text'].append((str(i),t))
impact={};need=collections.Counter()
for src,items in sources.items():
 hits=[]
 for k,v in items:
  m=sorted(set(v)&remap)
  if m:need.update(m);hits.append({'key':k,'value':v,'mapped':''.join(m)})
 impact[src]={'items':len(items),'affected':len(hits),'samples':hits[:200]}
restore=sorted(need)
write('font-official-wording-impact-full.json',{'remap_size':len(remap),'restore_codepoints':[f'U+{ord(c):04X}' for c in restore],'restore_chars':''.join(restore),'char_counts':dict(need),'by_source':impact})
print(json.dumps({'ui':dict(ui),'ui_diff_samples':diffs[:10],'no_cp_samples':nocp[:10],'remap':len(remap),'restore':''.join(restore),'counts':dict(need),'by_source':{k:(v['items'],v['affected']) for k,v in impact.items()}},ensure_ascii=False,indent=1))