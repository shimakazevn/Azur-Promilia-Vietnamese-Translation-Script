# 公告展示层热更新入口：只读可行性补证

本报告未改动安装目录、代码候选、版本文件、校验逻辑或请求参数。沿用 `../game_decrypt_bundle/announcement-display-report.md` 的展示调用链及SDK边界。

## 已证实

- 安装资源解包后的 `Assembly-CSharp.dll.bytes` 为 43,037,568 字节，CDPH/version 1，非普通PE。配套MV为2,057,820字节，CPMV/version 1。
- 本地runtime存在CDPH工厂RVA `0x1105F10`，其CDPH解析函数RVA `0x1108B10` 会检查magic、version及附加标志，在文件 `0x110` 处读取8个长度前缀且4字节对齐的数据块。
- 8块长度依次为256、128、128、128、16、128、16、16，结束于1120。随后尾部包含metadata开始20,744,204、长度22,293,364和单个区段的raw开始1168、长度43,036,400；区段结束恰等于文件总长。
- metadata起始存在BSJB及5个标准名称的stream header。然而 `#~`、`#Strings` 等内容不是标准可直接读取的ECMA数据。仅有BSJB及名称命中不足以证明特定方法IL可读或可重建。
- 原生 `AssemblyHotfixUtil.LoadDifferentialHybridAssemblyWithBytes` RVA `0x6E29BE0` 直接调用 `RuntimeApi.LoadDifferentialHybridAssemblyWithMetaVersion` RVA `0xB9655B0`，传递current DLL、空符号参数、original MV及current MV。非零返回值被视为失败。因此程序集字节变化与实际使用该IL属于不同问题。
- CPMV解析入口RVA `0x14DB0C0` 检查magic/version。文件结构可完整拆分为16字节头、27,786个8字节记录、4字节第二组数量、229,439个8字节记录，严格到EOF。头部版本字段为10000，各组记录第一uint仅观察到0或10000，第二uint为ID样字段。这里不未经证实命名两组的具体语义。
- 从现有解密global metadata的36字节MethodDef结构，`declaringType=14565` 的 `PageGatewayAnnouncementWindow.FormatSrcString` 对应token `0x06019CCB`（RID105675）。CPMV第二组存在 `(0,105675)`。这是数值关联线索；尚未证实ID编码、方法版本映射以及原始/当前文件比较规则，不能据此判断当前分派为AOT还是解释器。

## 展示层入口与技术可行性

已确认的语义入口为 `PageGatewayAnnouncementWindow.OnGetAnnounceCallback` 调用 `FormatSrcString` 后进行富文本解析及赋值。若可通过受支持的同版本程序集构建流程重建该函数，则理论上可以只替换最终文本节点和已证实的官方标题词组，保持SDK、请求、区服、缓存、HTML标签、URL、日期不变。

当前没有可安装方案。不能将普通Cecil改写、不完整CDPH转PE、修改MV版本号、替换旧Lua资源或修改prefab默认空文本当作已验证方案。

## 尚待补齐的证据

1. 根据本地CDPH解析/读取实现，将类型、方法、签名、RVA及IL流只读恢复，并与native方法token进行交叉验证，明确目标方法是否包含在该差分程序集，而非只在AOT元数据中。
2. 原始MV的实际来源及内容、两组记录的正式语义和ID编码；证明目标方法在原始/当前版本比较后的实际分派结果。
3. 受支持构建工具能生成该游戏兼容的CDPH/MV组合，并通过原有验证；不改变或跳过任何验证步骤。
4. 实际运行选择该程序集与该展示方法的证据；既有C#栈不能单独区分同名AOT/解释器实现。
5. 国服对应公告正文的可验证来源。目前只证实官方标题，无法声称全文逐项与国服一致。

复核脚本：`../game_compare_manifests/probe_cdph.py`、`find_cdph_xrefs.py`。脚本仅读取现有解包文件及本地runtime。
