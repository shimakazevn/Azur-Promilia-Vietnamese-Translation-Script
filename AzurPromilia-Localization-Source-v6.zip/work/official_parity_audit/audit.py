from pathlib import Path
import sys,json,hashlib,collections,re
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_compare_manifests'),str(BASE/'game_decrypt_paths'),str(BASE/'game_decrypt_bundle'),str(BASE/'analysis_deps')]
from parse_language_tables import read_index,read_rows
from vstring_pool import VStringPool
from parse_manifest import parse
from patch_manifest import encode_name
from unity_setup import UnityPy
OUT=Path(__file__).resolve().parent
TW=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');CN=Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data')
def load(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x): (OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
plan=load(BASE/'official_game_patch_v3/deployment-plan.json');baseline=[]
for row in plan['files']:
 if row['relative_path'].endswith(('v0k2cafcxjxawklow6skg.r','3iffxeedh2grvnbn2iag.r')):
  p=TW/row['relative_path'];h=sha(p);assert h==row['target_sha256'];baseline.append({'file':str(p),'installedSha256':h,'matchesV3Candidate':True})
tablepath=BASE/'official_game_patch_v3/table-data-patched.bin';poolpath=BASE/'official_game_patch_v3/vstring-patched.bin';table=tablepath.read_bytes();pool=VStringPool(poolpath);_,langs,_=read_index(table)
cn=load(BASE/'game_decrypt_paths/cn-language-rows.json')['chs'];original=load(BASE/'game_decrypt_paths/tw-language-rows.json')['cht']
counts=collections.Counter();tables=[];mismatch=[];unique=[]
def category(name):
 if re.search('option|choice',name,re.I):return '选项（按表名）'
 if re.search('story|dialog|timeline|talk',name,re.I):return '剧情（按表名）'
 if name=='words':return '通用界面/操作/混合'
 return '界面/配置/其他（未逐项语义标注）'
for name,offset in langs['cht'].items():
 rows=read_rows(table,offset,pool);ref={r['id']:r for r in cn.get(name,[])};orig={r['id']:r for r in original[name]};local=collections.Counter()
 for r in rows:
  local['total']+=1
  if r['id'] not in ref:
   unique.append({'table':name,'category':category(name),'id':r['id'],'originalTW':orig[r['id']]['value'],'current':r['value']});local['taiwanOnly']+=1
  elif r['value']!=ref[r['id']]['value']:
   mismatch.append({'table':name,'category':category(name),'id':r['id'],'current':r['value'],'officialCN':ref[r['id']]['value'],'valueOffset':r['value_offset']});local['mismatch']+=1
  else:local['exactMatch']+=1
 counts.update(local);tables.append({'table':name,'category':category(name),**local})
write('language-table-mismatches.json',mismatch);write('language-table-taiwan-only.json',unique);write('language-table-counts.json',tables)
def static(region):
 root=TW if region=='tw' else CN;ver='3221745' if region=='tw' else '3217420';prefix='0release' if region=='tw' else '00';lang='cht' if region=='tw' else 'chs';mp=root/f'.res/default_package/ManifestFiles/{prefix}_default_package_{ver}.bytes';m=parse(mp)
 sourcepool=VStringPool(BASE/'game_mmap/decoded'/('tw_update_v0k2cafcxjxawklow6skg.bin' if region=='tw' else 'cn_update_bjzqzapbodx6zodmvtrta.bin'))
 a=next(a for a in m['assets'] if sourcepool[a['path_key']]==f'Assets/ResourcesLang/{lang}/UI/StaticText/ast_staticTextKeyConfig.asset');b=m['bundles'][a['bundle']];pack=m['packs'][b['pack_id']];name=encode_name(pack['name0'],pack['name1']);p=root/'.res/default_package/BundleFiles'/name
 if not p.exists():p=root/'StreamingAssets/.res/default_package'/name
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 env=UnityPy.load(raw);obj=next(o for o in env.objects if o.type.name=='MonoBehaviour');d=obj.read_typetree();return d,{'file':str(p),'sha256':sha(p),'manifest':str(mp),'bundleIndex':a['bundle'],'offset':b['offset'],'size':b['size'],'segmentSha256':hashlib.sha256(raw).hexdigest()}
twstatic,tws=static('tw');cnstatic,cns=static('cn');ref={r['key']:r['value'] for r in cnstatic['list']};bytext=collections.defaultdict(list)
for k,v in ref.items():bytext[v].append(k)
oldstatic={r['key']:r['value'] for r in load(BASE/'game_decrypt_bundle/statictext_asset.json')['list']};sm=[];su=[];sc=collections.Counter()
for r in twstatic['list']:
 sc['total']+=1
 if r['key'] not in ref:
  keys=bytext.get(r['value'],[]);su.append({**r,'originalTW':oldstatic.get(r['key']),'sameTextCNKeys':keys,'sameTextAssociationOnly':bool(keys)});sc['taiwanOnly']+=1;sc['taiwanOnlyExactTextAssociated']+=bool(keys)
 elif r['value']!=ref[r['key']]:sm.append({**r,'officialCN':ref[r['key']]});sc['mismatch']+=1
 else:sc['exactMatch']+=1
cnlanguagebytext=collections.defaultdict(list)
for name,rows in cn.items():
 for row in rows:cnlanguagebytext[row['value']].append({'table':name,'id':row['id']})
for row in su:row['sameTextCNLanguageRows']=cnlanguagebytext.get(row['value'],[])
sc['taiwanOnlyExactTextInCNLanguageTables']=sum(bool(r['sameTextCNLanguageRows']) for r in su)
sc['taiwanOnlyExactTextInEitherCNSource']=sum(bool(r['sameTextCNLanguageRows'] or r['sameTextCNKeys']) for r in su)
write('statictext-mismatches.json',sm);write('statictext-taiwan-only.json',su)
summary={'scope':'Static resource text identity audit; not a runtime coverage claim','installedFilesModified':False,'baseline':baseline,'cachedPlaintext':[{'file':str(p),'sha256':sha(p)} for p in [tablepath,poolpath]],'languageTables':len(tables),'languageCounts':dict(counts),'languageMismatchTables':dict(collections.Counter(r['table'] for r in mismatch)),'staticTextCounts':dict(sc),'staticTextSources':{'tw':tws,'cn':cns},'limitations':['Table category derives from names; words is mixed use.','Same text at a different CN key proves text presence only, not semantic equivalence.','Server announcements, native hardcoded strings, embedded images and runtime branch selection are outside this audit.']}
write('summary.json',summary);print(json.dumps(summary,ensure_ascii=True,indent=2));print('MISMATCHES',json.dumps(mismatch,ensure_ascii=True))
