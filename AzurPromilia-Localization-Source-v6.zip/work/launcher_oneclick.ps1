$ErrorActionPreference = 'Stop'
try {
    $action = $env:AZUR_PATCH_ACTION
    if ($action -eq 'q' -or $action -eq 'Q') { exit 0 }
    if ($action -notin @('1', '2')) { throw '请输入 1 或 2，或输入 Q 退出。' }
    $launcherExe = 'E:\AzurPromilia_TC\1.0.1.4\launcher.exe'
    $targetArchive = 'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar'
    $backupArchive = 'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak'
    $originalHash = '30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa'
    $patchedHash = '__FINAL_HASH__'
    $knownHashes = @($originalHash, $patchedHash, '1b9de08cf73e5c44e98b26d06df58b7a0d36d2fb7629c6014b413f35c548c1e3', '67a4704230cc64b328e4945ce032b0417e7a17254e27eb0b7d5f8dc086e1367f')
    function Get-BytesHash([byte[]]$bytes) {
        $hasher = [Security.Cryptography.SHA256]::Create()
        try { return ([BitConverter]::ToString($hasher.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
        finally { $hasher.Dispose() }
    }
    function Get-PathHash([string]$path) { return Get-BytesHash ([IO.File]::ReadAllBytes($path)) }
    if (-not (Test-Path -LiteralPath $targetArchive -PathType Leaf)) { throw "未找到对应版本启动器：$targetArchive" }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'launcher.exe'" | Where-Object { $_.ExecutablePath -eq $launcherExe })
    if ($running.Count -gt 0) { throw '请先完全退出 E 盘台服启动器（包括右下角托盘），再运行本脚本。D 盘简体启动器可以继续下载。' }
    $currentHash = Get-PathHash $targetArchive
    if ($currentHash -notin $knownHashes) { throw '启动器版本或文件已改变，为避免覆盖更新，本次未修改任何文件。此脚本仅适用于台服启动器 1.0.1.4。' }
    if ($action -eq '2' -and $currentHash -eq $originalHash) { Write-Host '当前已经是原版，无需还原。' -ForegroundColor Green; exit 0 }
    if (Test-Path -LiteralPath $backupArchive) {
        if ((Get-PathHash $backupArchive) -ne $originalHash) { throw '原版备份校验失败，操作已停止。' }
    } elseif ($currentHash -eq $originalHash -and $action -eq '1') {
        Copy-Item -LiteralPath $targetArchive -Destination $backupArchive
        if ((Get-PathHash $backupArchive) -ne $originalHash) { throw '备份校验失败，操作已停止。' }
    } else { throw '未找到经过校验的原版备份，操作已停止。' }
    if ($action -eq '1' -and $currentHash -eq $patchedHash) { Write-Host '当前已经是完整简体汉化版本。' -ForegroundColor Green; exit 0 }
    $staging = $targetArchive + '.zhcn-oneclick.tmp'
    if (Test-Path -LiteralPath $staging) { throw "发现上次遗留的临时文件，请先检查：$staging" }
    if ($action -eq '2') {
        Copy-Item -LiteralPath $backupArchive -Destination $staging
        $expectedHash = $originalHash
    } else {
        Write-Host '正在校验并构建完整简体补丁……'
        $selfText = [IO.File]::ReadAllText($env:AZUR_PATCH_SELF)
        $base64 = ($selfText -split '(?m)^#<DATA>\r?$', 2)[1] -replace '\s', ''
        $compressed = [Convert]::FromBase64String($base64)
        $inputStream = New-Object IO.MemoryStream(,$compressed)
        $gzip = New-Object IO.Compression.GZipStream($inputStream, [IO.Compression.CompressionMode]::Decompress)
        $reader = New-Object IO.StreamReader($gzip, [Text.Encoding]::UTF8)
        try { $bundle = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose(); $gzip.Dispose(); $inputStream.Dispose() }
        $sourceBytes = [IO.File]::ReadAllBytes($backupArchive)
        $outputStream = New-Object IO.MemoryStream
        try {
            $header = [Convert]::FromBase64String($bundle.header)
            $outputStream.Write($header, 0, $header.Length)
            foreach ($operation in $bundle.operations) {
                if ($null -ne $operation.data) {
                    $block = [Convert]::FromBase64String($operation.data)
                    $outputStream.Write($block, 0, $block.Length)
                } else {
                    $outputStream.Write($sourceBytes, [int]$operation.offset, [int]$operation.length)
                }
            }
            $patchedBytes = $outputStream.ToArray()
        } finally { $outputStream.Dispose() }
        if ((Get-BytesHash $patchedBytes) -ne $patchedHash) { throw '补丁构建校验失败，未写入启动器。' }
        [IO.File]::WriteAllBytes($staging, $patchedBytes)
        $expectedHash = $patchedHash
    }
    if ((Get-PathHash $staging) -ne $expectedHash) { throw '写入前校验失败，未替换启动器。' }
    Move-Item -LiteralPath $staging -Destination $targetArchive -Force
    if ((Get-PathHash $targetArchive) -ne $expectedHash) { throw '写入后校验失败，请保留原版备份并重试还原。' }
    if ($action -eq '1') { Write-Host '简体汉化完成！现在可以正常打开台服启动器。' -ForegroundColor Green }
    else { Write-Host '已成功还原原版启动器。' -ForegroundColor Green }
    Write-Host "原版备份：$backupArchive"
    exit 0
} catch {
    Write-Host "操作停止：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
