import base64,gzip,json,sys
from pathlib import Path
from patch_launcher_language import parse,entries,member_data,sha
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent
OUT=HERE.parent/'outputs'
sources=[
    ('tw','台服','1.0.1.4','launcher.exe',Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak'),HERE/'launcher_complete.app.asar'),
    ('jp','日服','1.8.1','AZUPRO_JP_Gamelauncher.exe',Path(r'E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar.before-zhcn-20261124.bak'),HERE/'launcher_jp_zhcn.app.asar'),
]
config=[];bundles={}
for order,(key,label,version,exe,source,destination) in enumerate(sources):
    original=source.read_bytes();patched=destination.read_bytes()
    oh,_,ob=parse(original);ph,_,pb=parse(patched);old=dict(entries(oh));operations=[]
    for name,entry in entries(ph):
        if 'offset' not in entry:continue
        data=member_data(patched,entry,pb)
        if name in old and 'offset' in old[name] and member_data(original,old[name],ob)==data:
            operations.append({'offset':ob+int(old[name]['offset']),'length':len(data)})
        else:operations.append({'data':base64.b64encode(data).decode()})
    bundles[key]={'header':base64.b64encode(patched[:pb]).decode(),'operations':operations}
    known=[sha(original),sha(patched)]
    if key=='tw':known+=['1b9de08cf73e5c44e98b26d06df58b7a0d36d2fb7629c6014b413f35c548c1e3','67a4704230cc64b328e4945ce032b0417e7a17254e27eb0b7d5f8dc086e1367f']
    config.append(dict(id=key,label=label,version=version,exe=exe,original=sha(original),patched=sha(patched),known=known,order=order))
ps=(HERE/'launcher_combined.ps1').read_text('utf-8').replace('__REGION_CONFIG__',json.dumps(config,ensure_ascii=False,separators=(',',':')))
payload=base64.b64encode(gzip.compress(json.dumps(bundles,separators=(',',':')).encode(),mtime=0)).decode()
# The ASCII padding protects CMD read-ahead when editors save LF line endings.
stub=(HERE/'build_launcher_bat.py').read_text('utf-8')
start=stub.index("bat='''")+7
end=stub.index("'''+('rem ASCII",start)
bootstrap=stub[start:end].replace('\\\\','\\')
bat=bootstrap+('rem ASCII bootstrap padding.\n'*400)+'\n:__SCRIPT__\n'+ps+'\n:__DATA__\n'+'\n'.join(payload[i:i+120] for i in range(0,len(payload),120))+'\n'
assert bat.split(':__SCRIPT__',1)[0].isascii()
target=OUT/'台服日服启动器汉化与还原.bat'
target.write_bytes(bat.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
(HERE/'combined_bat_build.json').write_text(json.dumps(dict(bat=str(target),bytes=target.stat().st_size,sha256=sha(target.read_bytes()),regions=config),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(bat=str(target),bytes=target.stat().st_size,sha256=sha(target.read_bytes())),ensure_ascii=False))
