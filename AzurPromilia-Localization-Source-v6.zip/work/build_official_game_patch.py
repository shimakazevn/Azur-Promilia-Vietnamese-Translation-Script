"""Build a reversible Taiwan language-resource trial from local official CN data.

Does not write either installed game. Only language table value keys may change.
"""
from pathlib import Path
import sys,json,struct,hashlib,collections
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/game_decrypt_paths'),str(ROOT/'work/game_mmap')]
from vstring_pool import VStringPool
from rebuild_vstring import HashIndex,additions_from_cn,rebuild
from parse_language_tables import read_index,read_rows
from patch_manifest import patch_manifest
from decode_mmap import keystream,decode_file

GAME=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
OUT=ROOT/'work/official_game_patch';OUT.mkdir(exist_ok=True)
DECODED=ROOT/'work/game_mmap/decoded'
LANG=ROOT/'work/game_decrypt_paths'
def digest(b):return hashlib.sha256(b).hexdigest()
def emit(x):print(json.dumps(x,ensure_ascii=True),flush=True)
def load(p):return json.loads(p.read_text('utf8'))

def encode(original,plain):
 header=original[:4120];stream=keystream(header);period=len(stream)
 out=bytearray(header)
 for p in range(0,len(plain),4*1024*1024):
  chunk=plain[p:p+4*1024*1024];offset=(p+4120)%period
  mask=(stream*5)[offset:offset+len(chunk)]
  out.extend((int.from_bytes(chunk,'little')^int.from_bytes(mask,'little')).to_bytes(len(chunk),'little'))
 return bytes(out)

def build():
 tw=VStringPool(DECODED/'tw_update_v0k2cafcxjxawklow6skg.bin')
 cn=VStringPool(DECODED/'cn_update_bjzqzapbodx6zodmvtrta.bin')
 candidates=load(LANG/'official-cn-candidates.json')
 # Region-specific CN registration text does not belong in the Taiwan client.
 excluded={('words',-3683374324947326534)}
 chosen=[r for r in candidates if (r['table'],r['id']) not in excluded]
 missing=load(LANG/'missing-full-pool-search.json')
 cn_keys={r['cn_key'] for r in chosen}
 cn_keys.update(r['cn_pool_keys'][0] for r in missing if r['cn_pool_keys'])
 additions,mapping=additions_from_cn(tw,cn,sorted(cn_keys))
 missing_choices=[]
 for r in missing:
  if r['cn_pool_keys']:
   k=mapping[r['cn_pool_keys'][0]];source='official_cn_same_text'
  elif r['tw_pool_keys']:
   k=r['tw_pool_keys'][0];source='unchanged_text'
  else:
   # Custom hash algorithm must be verified before adding these 15 short labels.
   from vstring_hash import text_hash
   k=tw.count+len(additions);additions.append((r['expected'],text_hash(r['expected'])))
   source='taiwan_only_label_simplified'
  missing_choices.append(dict(table=r['table'],id=r['id'],value=r['expected'],key=k,source=source))
 emit(dict(stage='rebuilding_pool',official_changed=len(chosen),appended=len(additions)))
 rebuilt=rebuild(tw,additions);poolpath=OUT/'vstring-patched.bin';poolpath.write_bytes(rebuilt)
 pool=VStringPool(poolpath)
 # Strong invariant: every existing string and key keeps its exact original value.
 for key in range(tw.count):assert tw[key]==pool[key],key
 hindex=HashIndex(pool)
 for i,(text,h) in enumerate(additions):assert pool[tw.count+i]==text and hindex.lookup(h,text) is not None
 original=(LANG/'tw-update-table-data.bin').read_bytes();table=bytearray(original)
 expected={}
 for r in chosen:
  assert struct.unpack_from('<I',table,r['tw_offset'])[0]==r['tw_key']
  struct.pack_into('<I',table,r['tw_offset'],mapping[r['cn_key']]);expected[(r['table'],r['id'])]=r['cn']
 base,langs,end=read_index(original)
 missing_by={(r['table'],r['id']):r for r in missing_choices}
 for name,off in langs['cht'].items():
  for r in read_rows(original,off,tw):
   token=(name,r['id'])
   if token in missing_by:
    replacement=missing_by[token];struct.pack_into('<I',table,r['value_offset'],replacement['key']);expected[token]=replacement['value']
 # Byte-scope verification: zero differences outside the chosen four-byte keys.
 allowed=bytearray(len(original))
 for name,off in langs['cht'].items():
  oldrows=read_rows(original,off,tw);newrows=read_rows(table,off,pool)
  for a,b in zip(oldrows,newrows):
   token=(name,a['id']);assert a['id']==b['id']
   assert b['value']==expected.get(token,a['value']),token
   if token in expected:allowed[a['value_offset']:a['value_offset']+4]=b'\1'*4
 assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(original,table)))
 # Every English row is unchanged as a consequence of preserved original keys.
 for name,off in langs['en'].items():assert read_rows(original,off,tw)==read_rows(table,off,pool)
 (OUT/'table-data-patched.bin').write_bytes(table)
 emit(dict(stage='plaintext_verified',original_keys_preserved=tw.count,language_rows=470989))
 manifest_changes=[];file_plan=[]
 for package,filename,plain,plainoriginal in [
  ('raw_base_package','v0k2cafcxjxawklow6skg.r',rebuilt,tw.data),
  ('raw_streaming_package','3iffxeedh2grvnbn2iag.r',bytes(table),original),
 ]:
  rel=Path('.res')/package/'BundleFiles'/filename;src=GAME/rel;old=src.read_bytes()
  # Verify the installed source matches the decoded analysis before constructing.
  baselinecheck=OUT/(filename+'.baseline.bin');decode_file(src,baselinecheck)
  assert baselinecheck.read_bytes()==plainoriginal,str(src)
  encrypted=encode(old,plain);target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encrypted)
  check=OUT/(filename+'.roundtrip.bin');decode_file(target,check);assert check.read_bytes()==plain
  mp=Path('.res')/package/'ManifestFiles'/f'0release_{package}_3221745.bytes';mf=GAME/mp
  originalmanifest=mf.read_bytes();newmanifest,newhash,report=patch_manifest(originalmanifest,src,encrypted,old)
  hp=mp.with_suffix('.hash');assert (GAME/hp).read_bytes()==hashlib.md5(originalmanifest).hexdigest().encode()
  for r,newdata in [(rel,encrypted),(mp,newmanifest),(hp,newhash)]:
   p=OUT/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(newdata)
   file_plan.append(dict(relative_path=r.as_posix(),source_sha256=digest((GAME/r).read_bytes()),target_sha256=digest(newdata),size=len(newdata),candidate=str(p)))
  manifest_changes.append(report)
 report=dict(game_root=str(GAME.parent),data_root=str(GAME),scope='official_CN_text_by_table_and_id',official_changed_rows=len(chosen),matched_rows=470963,total_cht_rows=470989,excluded_region_text=[dict(table=t,id=i) for t,i in excluded],missing_choices=missing_choices,appended_strings=len(additions),old_pool_keys_preserved=tw.count,all_other_table_bytes_preserved=True,english_unchanged=True,mmap_roundtrip=True,manifest_changes=manifest_changes,files=file_plan)
 (OUT/'text-build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
 emit(dict(stage='text_build_complete',files=len(file_plan),appended_strings=len(additions)))

if __name__=='__main__':build()
