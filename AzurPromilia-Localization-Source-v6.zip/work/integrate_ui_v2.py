"""Stage the UI omissions fix on top of installed V1; do not install files."""
from pathlib import Path
from collections import defaultdict
import copy, hashlib, json, sys, datetime

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'work/official_game_patch_v2'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'work/game_compare_manifests'))
from patch_manifest import replace_pack_segments, patch_manifest

def sha(b): return hashlib.sha256(b).hexdigest()
def read_json(p): return json.loads(p.read_text('utf8'))
def save_json(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2), 'utf8')

old = read_json(ROOT / 'work/official_game_patch/deployment-plan.json')
assert old.get('patch_revision', 1) == 1, 'Build from stable V1 only'
plan = copy.deepcopy(old)
data = Path(plan['data_root'])
for f in old['files']:
    assert sha((data / f['relative_path']).read_bytes()) == f['target_sha256'], f['relative_path']

groups = defaultdict(lambda: {'segments': defaultdict(dict), 'sha': None})
for item in read_json(ROOT / 'work/font_display_probe/segment-plan.json'):
    p = Path(item['sourcePack']); g = groups[p]
    assert g['sha'] in (None, item['currentSHA256'])
    g['sha'] = item['currentSHA256']
    segment = Path(item['segmentCandidate']).read_bytes()
    assert len(segment) == item['candidateSize'] and sha(segment) == item['candidateSHA256']
    for m in item['manifests']:
        assert m['sourceSizeMatches']
        g['segments'][Path(m['manifestPath'])][m['bundleIndex']] = segment
for item in read_json(ROOT / 'work/game_decrypt_bundle/ui-v2-changes.json')['packs']:
    p = Path(item['installedPath']); g = groups[p]
    assert g['sha'] in (None, item['currentSHA'])
    g['sha'] = item['currentSHA']
    assert sha(Path(item['candidatePath']).read_bytes()) == item['candidateSHA']
    for m in item['manifestPaths']:
        for s in item['segmentReplacements']:
            assert s['bundleIndex'] not in g['segments'][Path(m)]
            g['segments'][Path(m)][s['bundleIndex']] = Path(s['candidateSegmentPath']).read_bytes()

manifests = {}
staged = {}
reports = []
for pack, group in groups.items():
    original = pack.read_bytes()
    assert sha(original) == group['sha'], str(pack)
    unified = None
    for manifest, replacements in group['segments'].items():
        if manifest not in manifests:
            manifests[manifest] = manifest.read_bytes()
            assert manifest.with_suffix('.hash').read_bytes() == hashlib.md5(manifests[manifest]).hexdigest().encode('ascii')
        packed, new_m, _, report = replace_pack_segments(manifests[manifest], pack, replacements, original)
        if unified is None: unified = packed
        else: assert unified == packed, 'Shared manifests disagree on rebuilt pack'
        manifests[manifest] = new_m
        reports.append(dict(pack=str(pack), manifest=str(manifest), **report))
        print('Staged', pack.name, 'in', manifest.name, flush=True)
    dest = OUT / pack.relative_to(data)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(unified)
    staged[pack] = dest

# Verify final metadata after every pack has updated shared manifest offsets.
for manifest, payload in manifests.items():
    for pack, group in groups.items():
        if manifest in group['segments']:
            candidate = staged[pack].read_bytes()
            _, _, result = patch_manifest(payload, pack, candidate, candidate)
            assert result['original_validated']
    dest = OUT / manifest.relative_to(data)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(payload)
    dest.with_suffix('.hash').write_bytes(hashlib.md5(payload).hexdigest().encode('ascii'))
    staged[manifest] = dest
    staged[manifest.with_suffix('.hash')] = dest.with_suffix('.hash')

by_rel = {f['relative_path']: f for f in plan['files']}
for installed, candidate in staged.items():
    rel = installed.relative_to(data).as_posix()
    new_hash = sha(candidate.read_bytes())
    if rel in by_rel:
        f = by_rel[rel]
        previous = set(f.get('previous_sha256', []))
        previous.add(f['target_sha256'])
        f['previous_sha256'] = sorted(previous)
        f.update(target_sha256=new_hash, size=candidate.stat().st_size, candidate=str(candidate))
    else:
        f = dict(relative_path=rel, source_sha256=sha(installed.read_bytes()), target_sha256=new_hash,
                 size=candidate.stat().st_size, candidate=str(candidate), previous_sha256=[])
        plan['files'].append(f)
        by_rel[rel] = f

plan.update(patch_revision=2, runtime_tested=False,
    ui_v2=dict(static_text_entries=3232, static_text_changed=2390, official_key_matched=2642,
               taiwan_only_simplified=590, startup_csv_changed=101,
               warning_texture_and_sprite='official_CN_same_object_IDs',
               remote_text='traditional_codepoint_to_simplified_glyph_display_only',
               unresolved=['登入成功 / 切換帳號来源仍未定位，未确认覆盖']))
save_json(OUT / 'deployment-plan.json', plan)
save_json(OUT / 'integration-report.json', dict(created_at=datetime.datetime.now().astimezone().isoformat(),
    installed_modified=False, files=len(plan['files']), upgraded_files=len(staged),
    final_pack_crc_valid=True, manifests=reports, v1_candidates_preserved=True))
(OUT / 'Apply-OfficialZH.ps1').write_text((ROOT / 'work/deploy_official_patch.ps1').read_text('utf8'), 'utf-8-sig')
print(json.dumps(dict(files=len(plan['files']), upgraded_files=len(staged), patch_bytes=sum(f['size'] for f in plan['files']))), flush=True)
