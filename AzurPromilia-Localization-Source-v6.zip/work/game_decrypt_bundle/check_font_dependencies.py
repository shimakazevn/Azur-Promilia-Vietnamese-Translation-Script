from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
specs=[('update',base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes','tw_update_v0k2cafcxjxawklow6skg.bin'),('builtin',base/'StreamingAssets/.res/default_package/0release_default_package_3060618.bytes','tw_builtin_mjsd3ojqtcpsyxkepjq6tw.bin')]
report=[]
for layer,p,poolname in specs:
 m=parse(p);pool=VStringPool(HERE.parent/'game_mmap/decoded'/poolname)
 names={}
 for a in m['assets']:
  path=pool[a['path_key']]
  if '/cht/UI/Font' in path:
   b=m['bundles'][a['bundle']];names[path]={'asset':a,'bundle':b,'bundleIndex':a['bundle'],'assetDependencies':m['asset_depend_pool'][a['depend_start']:a['depend_start']+a['depend_count']],'bundleReferences':m['bundle_reference_pool'][b['reference_offset']:b['reference_offset']+b['reference_count']]}
 target=names['Assets/ResourcesLang/cht/UI/FontAsset/sdf_a00_b.asset'];fallbacks=[names['Assets/ResourcesLang/cht/UI/FontAsset/fallback_sdf_a00.asset'],names['Assets/ResourcesLang/cht/UI/FontAsset/fallback_sdf_c00.asset']]
 for path,r in names.items():
  b=r['bundle'];pack=m['packs'][b['pack_id']];r['packName']=encode_name(pack['name0'],pack['name1'])
 closure=sorted(set(target['assetDependencies']+[r['bundleIndex'] for r in fallbacks]+[i for r in fallbacks for i in r['assetDependencies']]))
 report.append({'layer':layer,'manifest':str(p),'target':target,'fallbacks':fallbacks,'neededDirectDependencyIndices':[r['bundleIndex'] for r in fallbacks],'missingFromTargetAssetDependencies':[r['bundleIndex'] for r in fallbacks if r['bundleIndex'] not in target['assetDependencies']],'recommendedDependencyClosure':closure,'additionalDependencyClosure':sorted(set(closure)-set(target['assetDependencies'])),'referencePoolInterpretation':'Reverse references: entries point to consumer bundles. Verify against fallback use by sdf_a00/b00/c00; do not use as outbound load dependencies.','fontAssets':names})
(HERE/'font_dependencies.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps([{k:v for k,v in r.items() if k!='fontAssets'} for r in report],ensure_ascii=True))
