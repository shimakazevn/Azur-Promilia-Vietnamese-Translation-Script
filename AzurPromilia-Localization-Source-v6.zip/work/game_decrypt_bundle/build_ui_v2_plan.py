from unity_setup import *
import json,hashlib
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import replace_pack_segments
from vstring_pool import VStringPool
r=json.loads((HERE/'statictext_v2_candidate.json').read_text(encoding='utf8'));mp=Path(r['twManifest']);p=Path(r['twPack']);raw=p.read_bytes();seg=Path(r['candidateSegment']);idx=r['twAsset']['bundle'];m=parse(mp)
pack,manifest,mhash,report=replace_pack_segments(mp.read_bytes(),p,{idx:seg.read_bytes()},raw)
out=HERE/'tw_statictext_fontpack_v2.r';out.write_bytes(pack);mo=HERE/'tw_statictext_fontpack_v2_manifest.bytes';mo.write_bytes(manifest);mo.with_suffix('.hash').write_bytes(mhash);m2=parse(manifest);untouched=[]
for i,b in enumerate(m['bundles']):
 if b['pack_id']!=r['twBundle']['pack_id'] or i==idx:continue
 b2=m2['bundles'][i];assert raw[b['offset']:b['offset']+b['size']]==pack[b2['offset']:b2['offset']+b2['size']];untouched.append(i)
sha=lambda x:hashlib.sha256(x).hexdigest()
plan={'packs':[{'installedPath':str(p),'currentSHA':sha(raw),'candidatePath':str(out),'candidateSHA':sha(pack),'segmentReplacements':[{'bundleIndex':idx,'candidateSegmentPath':str(seg)}],'manifestPaths':[str(mp)],'candidateManifestPath':str(mo),'unchangedSegments':untouched}], 'installedModified':False}
(HERE/'ui-v2-changes.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(plan,ensure_ascii=True))
pool=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');paths=[]
for a in m['assets']:
 path=pool[a['path_key']]
 if '/cht/' in path and any(x in path.lower() for x in ('warning','jkzg','splash','login','welcome','health')):paths.append(dict(a,path=path))
(HERE/'cht_startup_paths_v2.json').write_text(json.dumps(paths,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(paths,ensure_ascii=True))
