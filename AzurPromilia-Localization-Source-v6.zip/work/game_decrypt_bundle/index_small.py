from unity_setup import *
import json,time
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package')
files=sorted(base.glob('*.r'),key=lambda p:p.stat().st_size)[:150]
out=HERE/'small_bundle_index.jsonl'
with out.open('w',encoding='utf8') as f:
 for i,p in enumerate(files):
  try:
   env=UnityPy.load(str(p));objs=list(env.objects)
   row={'file':p.name,'size':p.stat().st_size,'objects':len(objs),'container':list(env.container),'textAssets':[]}
   for obj in objs:
    if obj.type.name=='TextAsset':
     data=obj.read();row['textAssets'].append({'id':obj.path_id,'name':data.m_Name,'bytes':len(data.m_Script)})
   f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
   print(i,p.name,len(objs),len(row['textAssets']),flush=True)
  except Exception as e:
   f.write(json.dumps({'file':p.name,'error':repr(e)})+'\n');f.flush()
