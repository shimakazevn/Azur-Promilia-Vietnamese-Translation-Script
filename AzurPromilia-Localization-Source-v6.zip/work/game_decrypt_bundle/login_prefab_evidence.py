from unity_setup import *
import json,re
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');m=parse(base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes');pool=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');out=[]
for a in m['assets']:
 path=pool[a['path_key']]
 if not ('/UI/' in path and path.endswith('.prefab') and re.search('login|startgame',path,re.I)):continue
 b=m['bundles'][a['bundle']];p=m['packs'][b['pack_id']];name=encode_name(p['name0'],p['name1']);pp=base/'.res/default_package/BundleFiles'/name
 if not pp.exists():pp=base/'StreamingAssets/.res/default_package'/name
 with pp.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 e=UnityPy.load(raw);items=[]
 for o in e.objects:
  if o.type.name not in ('MonoBehaviour','GameObject','Sprite'):continue
  try:t=o.read_typetree()
  except Exception:continue
  if o.type.name=='MonoBehaviour':items.append({'id':o.path_id,'tree':t})
  elif t.get('m_Name'):items.append({'id':o.path_id,'type':o.type.name,'name':t['m_Name']})
 out.append({'path':path,'bundle':a['bundle'],'pack':str(pp),'items':items})
(HERE/'login_prefabs_evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8');print([(x['path'],len(x['items'])) for x in out])
