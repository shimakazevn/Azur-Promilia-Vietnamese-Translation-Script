from unity_setup import *
import json,hashlib,zlib,copy
P=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package\a66pm5ie1rrjguuzlsyq.r')
sha=lambda b:hashlib.sha256(b).hexdigest()
env=UnityPy.load(str(P));bundle=next(iter(env.files.values()))
objects=list(env.objects);font=next(o for o in objects if o.type.name=='Font')
before={str(o.path_id):sha(o.get_raw_data()) for o in objects}
origTree=font.read_typetree();newTree=copy.deepcopy(origTree)
fontBytes=(HERE/'cn_a00.otf').read_bytes();newTree['m_FontData']=list(fontBytes)
font.save_typetree(newTree)
plain=bundle.save(packer='lz4');dest=HERE/'tw_a00_cn_font_plain.r';dest.write_bytes(plain)
newEnv=UnityPy.load(str(dest));newBundle=next(iter(newEnv.files.values()));newObjects=list(newEnv.objects)
after={str(o.path_id):sha(o.get_raw_data()) for o in newObjects}
newFont=next(o for o in newObjects if o.type.name=='Font');check=newFont.read_typetree()
assert bytes(check['m_FontData'])==fontBytes
assert {k:v for k,v in origTree.items() if k!='m_FontData'}=={k:v for k,v in check.items() if k!='m_FontData'}
changed=[pid for pid in before if before[pid]!=after[pid]]
assert changed==[str(font.path_id)]
def resource_nodes(b):
 return {name:sha(f.bytes) for name,f in b.files.items() if hasattr(f,'bytes')}
assert resource_nodes(bundle)==resource_nodes(newBundle)
orig=P.read_bytes()
report={'source':str(P),'fontPathId':font.path_id,'unchangedFontFields':True,'changedObjectIds':changed,'allOtherObjectRawBytesUnchanged':True,'resourceNodeBytesUnchanged':True,'objectCount':len(objects),'containerUnchanged':list(env.container)==list(newEnv.container),'original':{'bytes':len(orig),'sha256':sha(orig),'crc32':f'{zlib.crc32(orig):08x}','flags':int(bundle.dataflags)},'plainCandidate':{'path':str(dest),'bytes':len(plain),'sha256':sha(plain),'crc32':f'{zlib.crc32(plain):08x}','flags':int(newBundle.dataflags),'encryptionPreserved':False},'fontDataSha256':sha(fontBytes),'fontDataBytes':len(fontBytes)}
(HERE/'font_candidate_validation.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report))
