from unity_setup import *
import struct,json,re
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
needles=['關閉','開啟','恢復默認設定','警告','詳細閱讀','登入成功','切換帳號','正在檢查更新']
specs=[]
for p in (base/'StreamingAssets/.res/static_package').glob('*.r'):specs.append((p,0,p.stat().st_size))
p=base/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r';raw=p.read_bytes();off=0
while off<len(raw):
 size=struct.unpack_from('>Q',raw,off+24)[0]
 if 3780000<off<3890000:specs.append((p,off,size))
 off+=size
report=[]
for p,off,size in specs:
 with p.open('rb') as f:f.seek(off);raw=f.read(size)
 env=UnityPy.load(raw)
 for o in env.objects:
  data=o.get_raw_data();hits=[s for s in needles if s.encode() in data]
  if not hits:continue
  texts=[]
  def walk(v,path=''):
   if isinstance(v,str) and any(s in v for s in needles):texts.append({'field':path,'text':v})
   elif isinstance(v,dict):
    for k,x in v.items():walk(x,path+'.'+k)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+f'[{i}]')
  try:walk(o.read_typetree())
  except Exception:pass
  report.append({'pack':str(p),'offset':off,'size':size,'id':o.path_id,'type':o.type.name,'hits':hits,'texts':texts})
(HERE/'static_text_hits.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=True))
