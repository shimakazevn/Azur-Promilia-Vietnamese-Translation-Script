from unity_setup import *
from reencrypt_bundle import wrap
import copy,json,hashlib,zlib
tw=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package\qagwbpouz9gmykhtik1ldw.r')
cn=Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data\StreamingAssets\.res\default_package\gk4v2yw2irn82uxwnvxw.r')
sha=lambda b:hashlib.sha256(b).hexdigest()
ce=UnityPy.load(str(cn));cf=next(o for o in ce.objects if o.type.name=='Font').read_typetree();fontBytes=bytes(cf['m_FontData'])
(HERE/'cn_b00.otf').write_bytes(fontBytes)
te=UnityPy.load(str(tw));bundle=next(iter(te.files.values()));objects=list(te.objects);font=next(o for o in objects if o.type.name=='Font');origTree=font.read_typetree();tree=copy.deepcopy(origTree);tree['m_FontData']=list(fontBytes)
before={o.path_id:o.get_raw_data() for o in objects};font.save_typetree(tree)
plain=bundle.save(packer='lz4');encrypted,n=wrap(plain,tw.read_bytes());out=HERE/'tw_b00_cn_font_unitycn.r';out.write_bytes(encrypted)
check=UnityPy.load(str(out));after={o.path_id:o.get_raw_data() for o in check.objects};changed=[str(i) for i in before if before[i]!=after[i]];assert changed==[str(font.path_id)]
loaded=next(o for o in check.objects if o.type.name=='Font').read_typetree();assert bytes(loaded['m_FontData'])==fontBytes;assert {k:v for k,v in loaded.items() if k!='m_FontData'}=={k:v for k,v in origTree.items() if k!='m_FontData'}
original=tw.read_bytes()
report={'twSource':str(tw),'cnSource':str(cn),'fontPathId':font.path_id,'twFontNames':origTree['m_FontNames'],'cnFontNames':cf['m_FontNames'],'changedObjectIds':changed,'allOtherObjectRawBytesUnchanged':True,'allOtherFontFieldsUnchanged':True,'containerUnchanged':list(check.container)==list(te.container),'fontBytes':len(fontBytes),'fontSha256':sha(fontBytes),'blocksRoundtripValidated':n,'original':{'bytes':len(original),'sha256':sha(original),'crc32':f'{zlib.crc32(original):08x}'},'encryptedCandidate':{'path':str(out),'bytes':len(encrypted),'sha256':sha(encrypted),'crc32':f'{zlib.crc32(encrypted):08x}','flags':int(next(iter(check.files.values())).dataflags),'encryptionHeaderMatchesOriginal':encrypted[44:114]==original[44:114]},'runtimeAcceptanceTested':False}
(HERE/'b00_font_candidate_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False))
