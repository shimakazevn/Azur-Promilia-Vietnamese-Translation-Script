from fast_serialized import *
import json
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package')
rows=[json.loads(s) for s in (HERE/'all_bundle_index.jsonl').read_text(encoding='utf8').splitlines()]
files=[r for r in rows if any('FontAsset/' in c and c.endswith('.asset') for c in r['container'])]
out=[]
for row in files:
 env=load_serialized(base/row['file'])
 for o in env.objects:
  if o.type.name!='MonoBehaviour':continue
  try:
   tree=o.read_typetree()
   if 'm_AtlasPopulationMode' not in tree and not any('font' in k.lower() for k in tree):continue
   info={k:v for k,v in tree.items() if any(q in k.lower() for q in ['name','sourcefont','population','atlaswidth','atlasheight','multiatlas','fallback','dynamic','clear','atlastexture','material'])}
   info.update(file=row['file'],id=o.path_id,keys=list(tree),externals=[{'path':x.path,'guid':str(x.guid)} for x in o.assets_file.externals])
   out.append(info)
  except Exception as e:out.append({'file':row['file'],'id':o.path_id,'error':repr(e)})
(HERE/'sdf_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(out,ensure_ascii=False))
