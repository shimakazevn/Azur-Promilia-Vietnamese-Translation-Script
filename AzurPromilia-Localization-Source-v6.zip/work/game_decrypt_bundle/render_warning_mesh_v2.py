from unity_setup import *
from PIL import Image,ImageDraw
import json,struct
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\static_package\nkewfips4anrz2bqfjhpg.r');e=UnityPy.load(p.read_bytes());o=next(o for o in e.objects if o.path_id==3251021402728481676);t=o.read_typetree();v=t['m_RD']['m_VertexData'];print({k:x for k,x in v.items() if k!='m_DataSize'});print(len(v['m_DataSize']),len(t['m_RD']['m_IndexBuffer']))
data=v['m_DataSize'];n=v['m_VertexCount'];stride=len(data)//n;verts=[struct.unpack_from('<3f',data,i*12) for i in range(n)];im=Image.new('RGB',(1706,504),'black');d=ImageDraw.Draw(im);idx=t['m_RD']['m_IndexBuffer'];idx=struct.unpack('<'+'H'*(len(idx)//2),bytes(idx))
for a,b,c in zip(idx[::3],idx[1::3],idx[2::3]):d.polygon([(verts[k][0]*100+853,252-verts[k][1]*100) for k in (a,b,c)],fill='white')
im.save(HERE/'warning_mesh_tw_v2.png')

