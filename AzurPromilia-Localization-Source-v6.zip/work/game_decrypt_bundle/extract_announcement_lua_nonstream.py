from unity_setup import *
import json
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');m=parse(base/'.res/raw_nostreaming_package/ManifestFiles/0release_raw_nostreaming_package_3221745.bytes');pool=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');out=[];folder=HERE/'announcement_lua';folder.mkdir(exist_ok=True)
for a in m['assets']:
 path=pool[a['path_key']]
 if '/Lua/' not in path or not ('announcement' in path.lower() or 'pageGatewayAnnouncementWindow' in path):continue
 b=m['bundles'][a['bundle']];pk=m['packs'][b['pack_id']];name=encode_name(pk['name0'],pk['name1']);p=base/'.res/raw_nostreaming_package/BundleFiles'/name
 if not p.exists():p=base/'StreamingAssets/.res/raw_nostreaming_package'/name
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 print('raw_candidate',path,raw[:12].hex(),len(raw),flush=True); e=UnityPy.load(raw)
 for o in e.objects:
  if o.type.name!='TextAsset':continue
  t=o.read_typetree();s=t['m_Script'];s=s.encode('utf8',errors='surrogateescape') if isinstance(s,str) else s;dest=folder/(Path(path).name);dest.write_bytes(s);out.append({'path':path,'bundle':a['bundle'],'objectId':o.path_id,'output':str(dest),'prefix':s[:16].hex(),'size':len(s)})
(folder/'index.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(out,ensure_ascii=True))
