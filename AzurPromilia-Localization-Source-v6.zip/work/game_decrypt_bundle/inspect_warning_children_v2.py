from unity_setup import *
import json
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\static_package\nkewfips4anrz2bqfjhpg.r');e=UnityPy.load(p.read_bytes());objs={o.path_id:o for o in e.objects};trees={i:o.read_typetree() for i,o in objs.items() if o.type.name not in ('Texture2D','Mesh','Font','Shader')}
root=next(i for i,t in trees.items() if t.get('m_Name')=='ScreenWarning');todo=[root];out=[]
while todo:
 i=todo.pop();t=trees[i];parts=[]
 for c in t.get('m_Component',[]):
  k=c['component']['m_PathID'];ct=trees[k];parts.append({'id':k,'type':objs[k].type.name,'tree':ct})
  for ch in ct.get('m_Children',[]):todo.append(trees[ch['m_PathID']]['m_GameObject']['m_PathID'])
 out.append({'id':i,'name':t.get('m_Name'),'components':parts})
(HERE/'warning_children_v2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8');print(json.dumps(out,ensure_ascii=True))
