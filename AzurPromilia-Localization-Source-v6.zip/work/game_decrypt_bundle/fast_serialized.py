from unity_setup import *
from UnityPy.streams import EndianBinaryReader
from UnityPy.files import BundleFile
import struct

def load_serialized(p,prefix_only=False):
 with p.open('rb') as f:
  h=f.read(256);r=EndianBinaryReader(h)
  assert r.read_string_to_null()=='UnityFS'
  version=r.read_u_int();r.read_string_to_null();r.read_string_to_null()
  size=r.read_long();cs=r.read_u_int();us=r.read_u_int();flags=r.read_u_int()
  decryptor=asm.ArchiveStorageDecryptor(r) if flags&0x400 else None
  r.align_stream(16);dataoff=r.Position
  f.seek(size-cs if flags&0x80 else dataoff);ci=f.read(cs)
  tool=BundleFile.__new__(BundleFile);tool.decryptor=decryptor
  info=EndianBinaryReader(tool.decompress_data(ci,us,flags))
  info.read_bytes(16);blocks=[(info.read_u_int(),info.read_u_int(),info.read_u_short()) for _ in range(info.read_int())]
  nodes=[(info.read_long(),info.read_long(),info.read_u_int(),info.read_string_to_null()) for _ in range(info.read_int())]
  wanted=[x for x in nodes if not x[3].endswith(('.resS','.resource'))]
  end=max(o+n for o,n,_,_ in wanted)
  f.seek(dataoff if flags&0x80 else dataoff+cs)
  if flags&0x200:f.seek((f.tell()+15)//16*16)
  raw=bytearray()
  blockpos=0
  for i,(u,c,fl) in enumerate(blocks):
   if prefix_only=='edges':
    if i==0 or any(blockpos+u>o+n-131072 and blockpos<o+n for o,n,_,_ in wanted):
     raw.extend(tool.decompress_data(f.read(c),u,fl,i))
    else:f.seek(c,1)
    blockpos+=u
    continue
   if len(raw)>=end:break
   raw.extend(tool.decompress_data(f.read(c),u,fl,i))
   if prefix_only:return bytes(raw)
  if prefix_only=='edges':return bytes(raw)
  env=UnityPy.Environment()
  for o,n,_,name in wanted:env.load_file(bytes(raw[o:o+n]),name=name)
  return env
