from unity_setup import *
import struct,json,re
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
mp=base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes';m=parse(mp)
pool=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin')
targets={}
for a in m['assets']:
 path=pool[a['path_key']]
 if re.search(r'/UI/.*(setting|option|warning|notice|login|alert|switch|toggle)',path,re.I) and path.lower().endswith(('.prefab','.asset')):
  targets.setdefault(a['bundle'],[]).append(path)
needles=['關閉','開啟','恢復默認設定','警告','詳細閱讀','登入成功','切換帳號','正在檢查更新']
report=[]
for idx,paths in targets.items():
 b=m['bundles'][idx];pack=m['packs'][b['pack_id']];name=encode_name(pack['name0'],pack['name1']);p=base/'.res/default_package/BundleFiles'/name
 if not p.exists():p=base/'StreamingAssets/.res/default_package'/name
 if not p.exists():continue
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 try:env=UnityPy.load(raw)
 except Exception:continue
 for o in env.objects:
  data=o.get_raw_data();hits=[s for s in needles if s.encode() in data]
  if not hits:continue
  try:tree=o.read_typetree()
  except Exception:tree={}
  texts=[]
  def walk(v,path=''):
   if isinstance(v,str) and any(s in v for s in needles):texts.append({'field':path,'text':v})
   elif isinstance(v,dict):
    for k,x in v.items():walk(x,path+'.'+k)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+f'[{i}]')
  walk(tree)
  report.append({'manifest':str(mp),'bundleIndex':idx,'pack':str(p),'offset':b['offset'],'size':b['size'],'paths':paths,'objectId':o.path_id,'type':o.type.name,'hits':hits,'texts':texts})
  print(idx,p.name,o.path_id,hits,flush=True)
(HERE/'hardcoded_ui_hits.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('targetBundles',len(targets),'hitObjects',len(report))
