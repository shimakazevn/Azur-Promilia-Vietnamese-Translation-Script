from unity_setup import *
from reencrypt_bundle import wrap
import struct,copy,json,hashlib,zlib
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package')
reports=[]
def build(name,fontData=None,addFallback=False):
 p=base/name;original=p.read_bytes();firstSize=struct.unpack_from('>Q',original,24)[0];env=UnityPy.load(original[:firstSize]);bundle=next(iter(env.files.values()));before={o.path_id:o.get_raw_data() for o in env.objects}
 if fontData is not None:
  obj=next(o for o in env.objects if o.type.name=='Font');tree=obj.read_typetree();tree['m_FontData']=list(fontData)
 else:
  obj=next(o for o in env.objects if o.type.name=='MonoBehaviour');tree=obj.read_typetree()
  assert tree['m_Name']=='sdf_a00_b' and tree['m_FallbackFontAssetTable']==[]
  # Reuse existing TW dynamic fallback by its original CAB identity.
  from UnityPy.files.SerializedFile import FileIdentifier
  ext=copy.deepcopy(obj.assets_file.externals[0]);ext.path='archive:/CAB-39f70eba48e7e7ec0ea0eb8c4af19772/CAB-39f70eba48e7e7ec0ea0eb8c4af19772';obj.assets_file.externals.append(ext)
  tree['m_FallbackFontAssetTable']=[{'m_FileID':len(obj.assets_file.externals),'m_PathID':8831872156787389739}]
  ext2=copy.deepcopy(obj.assets_file.externals[0]);ext2.path='archive:/CAB-626abf0da0d71eb698c00dbb37dcfecd/CAB-626abf0da0d71eb698c00dbb37dcfecd';obj.assets_file.externals.append(ext2)
  tree['m_FallbackFontAssetTable'].append({'m_FileID':len(obj.assets_file.externals),'m_PathID':-3529508352733840601})
 obj.save_typetree(tree);plain=bundle.save(packer='lz4');encrypted,n=wrap(plain,original[:firstSize]);out=HERE/('tw_c00_cn_font_unitycn.r' if fontData is not None else 'tw_sdf_a00_b_fallback_unitycn.r');final=encrypted+original[firstSize:];out.write_bytes(final)
 check=UnityPy.load(encrypted);after={o.path_id:o.get_raw_data() for o in check.objects};changed=[str(i) for i in before if before[i]!=after[i]];assert changed==[str(obj.path_id)]
 if fontData is not None:assert bytes(next(o for o in check.objects if o.type.name=='Font').read_typetree()['m_FontData'])==fontData
 else:assert next(o for o in check.objects if o.path_id==obj.path_id).read_typetree()['m_FallbackFontAssetTable']==tree['m_FallbackFontAssetTable']
 sha=lambda x:hashlib.sha256(x).hexdigest()
 reports.append({'source':str(p),'candidate':str(out),'changedObjectId':obj.path_id,'allOtherObjectRawBytesUnchanged':True,'containerUnchanged':list(env.container)==list(check.container),'original':{'bytes':len(original),'sha256':sha(original),'crc32':f'{zlib.crc32(original):08x}'},'new':{'bytes':len(final),'sha256':sha(final),'crc32':f'{zlib.crc32(final):08x}','flags':1603},'tailBytesPreserved':len(original)-firstSize,'blockRoundtrips':n,'fallbackAddition':tree.get('m_FallbackFontAssetTable') if addFallback else None})
build('p4hifvtlpthiunufa1lslg.r',(HERE/'official_chs_c00.otf').read_bytes())
build('db0aboccfhk0ruhzeueydq.r',addFallback=True)
(HERE/'c00_sdf_candidate_validation.json').write_text(json.dumps(reports,indent=2),encoding='utf8');print(json.dumps(reports))
