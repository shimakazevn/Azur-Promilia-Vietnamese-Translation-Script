from unity_setup import *
import struct,json
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\.res\default_package\BundleFiles\owmxh3bjdhcwjoabqv67q.r')
raw=p.read_bytes();off=0;rows=[]
while off<len(raw):
 size=struct.unpack_from('>Q',raw,off+24)[0];env=UnityPy.load(raw[off:off+size])
 for o in env.objects:
  if o.type.name!='MonoBehaviour':continue
  d=o.read_typetree()
  if 'm_AtlasPopulationMode' not in d:continue
  row={'offset':off,'size':size,'id':o.path_id,'name':d['m_Name'],'mode':d['m_AtlasPopulationMode'],'source':d['m_SourceFontFile'],'fallback':d['m_FallbackFontAssetTable'],'chars':len(d['m_CharacterTable']),'externals':[x.path for x in o.assets_file.externals]};rows.append(row)
 off+=size
(HERE/'cht_pack_sdf.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(rows,ensure_ascii=False))
