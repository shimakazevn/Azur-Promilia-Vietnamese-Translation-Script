from unity_setup import *
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\static_package\nkewfips4anrz2bqfjhpg.r');e=UnityPy.load(p.read_bytes())
for o in e.objects:
 if o.type.name=='Texture2D':
  t=o.read()
  if t.m_Name in ('tex_login_word_jkzg','tex_welcome_word_xq'):
   out=HERE/(t.m_Name+'_tw_v2.png');t.image.save(out);print(out,t.m_Width,t.m_Height)
