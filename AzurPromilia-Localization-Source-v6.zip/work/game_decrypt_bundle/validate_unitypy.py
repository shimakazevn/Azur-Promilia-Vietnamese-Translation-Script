import sys,json,traceback,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'analysis_deps'))
import UnityPy
UnityPy.config.FALLBACK_UNITY_VERSION='2022.3.62f3'
from UnityPy.helpers import ArchiveStorageManager as asm
asm.UNITY3D_SIGNATURE=b'#$manjuuunity*!@'
def decrypt_key(key,data,keybytes):
    js="const c=require('crypto').createCipheriv('aes-128-ecb',Buffer.from(process.argv[1],'hex'),null);c.setAutoPadding(false);process.stdout.write(Buffer.concat([c.update(Buffer.from(process.argv[2],'hex')),c.final()]).toString('hex'))"
    enc=bytes.fromhex(subprocess.check_output(['node','-e',js,keybytes.hex(),key.hex()],text=True))
    return bytes(a^b for a,b in zip(data,enc))
asm.decrypt_key=decrypt_key
UnityPy.set_assetbundle_decrypt_key((HERE/'local_bundle_key.bin').read_bytes())
report=[]
for row in json.loads((HERE/'source_key_probe.json').read_text()):
    base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game') if row['region']=='tw' else Path(r'D:\AzurPromilia\AzurPromilia_Game')
    p=base/'AzurPromilia_Data/StreamingAssets/.res/static_package'/row['name']
    try:
        env=UnityPy.load(str(p))
        objs=list(env.objects)
        report.append({'region':row['region'],'file':row['name'],'ok':True,'objects':len(objs),'types':sorted(set(o.type.name for o in objs)),'container':list(env.container)[:20]})
        for obj in objs:
            if obj.type.name=='TextAsset':
                data=obj.read()
                out=HERE/'decoded'/row['region'];out.mkdir(parents=True,exist_ok=True)
                (out/(str(obj.path_id)+'_'+data.m_Name.replace('/','_')+'.bin')).write_bytes(data.m_Script.encode('utf8','surrogateescape') if isinstance(data.m_Script,str) else data.m_Script)
    except Exception as e:
        report.append({'region':row['region'],'file':row['name'],'ok':False,'error':repr(e),'trace':traceback.format_exc()})
(HERE/'unitypy_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
