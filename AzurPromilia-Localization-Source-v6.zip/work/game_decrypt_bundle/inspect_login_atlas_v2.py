from unity_setup import *
import json
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');m=parse(base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes');b=m['bundles'][369080];pk=m['packs'][b['pack_id']];p=base/'.res/default_package/BundleFiles'/encode_name(pk['name0'],pk['name1'])
if not p.exists():p=base/'StreamingAssets/.res/default_package'/p.name
with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
e=UnityPy.load(raw)
for o in e.objects:
 if o.type.name in ('Texture2D','Sprite','SpriteAtlas'):
  t=o.read_typetree();print(o.path_id,o.type.name,t.get('m_Name'),t.get('m_PackedSpriteNamesToIndex'))
  if o.type.name=='Texture2D':o.read().image.save(HERE/f'login_atlas_{o.path_id}_v2.png')
