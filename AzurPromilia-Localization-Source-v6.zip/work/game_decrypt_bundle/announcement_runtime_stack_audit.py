from pathlib import Path
import re,json
out=[]
for p in Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\PersistentDataPath\Log').glob('*.log'):
 ls=p.read_text(encoding='utf8',errors='replace').splitlines()
 for i,s in enumerate(ls):
  if 'pageGatewayAnnouncementWindow' not in s and 'PageGatewayAnnouncementWindow' not in s:continue
  if len(s)>600 or re.search(r'token|ticket|account|https?://|email',s,re.I):continue
  # Keep only stack symbols or a narrow page label, no neighboring user records.
  safe=s if re.match(r'^[A-Za-z_.<>`]+[:.]',s) else ('pageGatewayAnnouncementWindow' if 'pageGatewayAnnouncementWindow' in s else 'PageGatewayAnnouncementWindow')
  out.append({'file':p.name,'line':i+1,'symbol':safe})
Path('work/game_decrypt_bundle/announcement-runtime-symbols.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(out[-50:],ensure_ascii=True))
