from unity_setup import *
from fast_serialized import load_serialized
import json,time
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\.res\default_package\BundleFiles')
files=sorted(base.glob('*.r'),key=lambda p:p.stat().st_size)
out=HERE/'update_bundle_index.jsonl'
done={json.loads(s)['file'] for s in out.read_text(encoding='utf8').splitlines()} if out.exists() else set()
with out.open('a',encoding='utf8') as f:
 for i,p in enumerate(files):
  if p.name in done:continue
  try:
   env=load_serialized(p);objs=list(env.objects)
   row={'file':p.name,'size':p.stat().st_size,'objects':len(objs),'container':list(env.container),'textAssets':[]}
   for obj in objs:
    if obj.type.name=='TextAsset':
     data=obj.read();row['textAssets'].append({'id':obj.path_id,'name':data.m_Name,'bytes':len(data.m_Script)})
   f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
   print(i,p.name,len(objs),len(row['textAssets']),flush=True) if i%100==0 or row['textAssets'] else None
  except Exception as e:
   f.write(json.dumps({'file':p.name,'error':repr(e)})+'\n');f.flush()


