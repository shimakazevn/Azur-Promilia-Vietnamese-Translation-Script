from unity_setup import *
import json,re
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
mp=base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes';m=parse(mp)
pool=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin')
targets=[]
for a in m['assets']:
 p=pool[a['path_key']]
 if re.search(r'(warning|health|agewarn|sdklogin|login_success|loginsuccess)',p,re.I):targets.append(dict(a,path=p))
(HERE/'ui_image_paths.json').write_text(json.dumps(targets,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(targets,ensure_ascii=True))
for a in targets:
 if not a['path'].lower().endswith(('.prefab','.asset')):continue
 b=m['bundles'][a['bundle']];pk=m['packs'][b['pack_id']];name=encode_name(pk['name0'],pk['name1']);p=base/'.res/default_package/BundleFiles'/name
 if not p.exists():p=base/'StreamingAssets/.res/default_package'/name
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 e=UnityPy.load(raw);items=[]
 for o in e.objects:
  try:t=o.read_typetree()
  except Exception:continue
  items.append({'id':o.path_id,'type':o.type.name,'tree':t})
 (HERE/f"ui_prefab_{a['bundle']}.json").write_text(json.dumps({'path':a['path'],'objects':items},ensure_ascii=False,indent=2),encoding='utf8')
