import sys,subprocess,functools
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'analysis_deps'))
import UnityPy
from UnityPy.helpers import ArchiveStorageManager as asm
UnityPy.config.FALLBACK_UNITY_VERSION='2022.3.62f3'
asm.UNITY3D_SIGNATURE=b'#$manjuuunity*!@'
@functools.lru_cache(maxsize=4096)
def decrypt_key(key,data,keybytes):
    js="const fs=require('fs'),x=JSON.parse(fs.readFileSync(0,'utf8')),c=require('crypto').createCipheriv('aes-128-ecb',Buffer.from(x[0],'hex'),null);c.setAutoPadding(false);process.stdout.write(Buffer.concat([c.update(Buffer.from(x[1],'hex')),c.final()]).toString('hex'))"
    import json
    enc=bytes.fromhex(subprocess.check_output(['node','-e',js],input=json.dumps([keybytes.hex(),key.hex()]),text=True))
    return bytes(a^b for a,b in zip(data,enc))
asm.decrypt_key=decrypt_key
UnityPy.set_assetbundle_decrypt_key((HERE/'local_bundle_key.bin').read_bytes())
