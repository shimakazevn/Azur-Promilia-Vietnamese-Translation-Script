from fast_serialized import *
import json,re
base=Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data\StreamingAssets\.res\default_package')
out=HERE/'cn_font_candidates.jsonl'
files=sorted(base.glob('*.r'),key=lambda p:abs(p.stat().st_size-3114015))
with out.open('w',encoding='utf8') as f:
 for i,p in enumerate(files):
  try:
   raw=load_serialized(p,prefix_only='edges')
   matches=re.findall(rb'Assets/ResourcesLang/[^\x00-\x1f]{1,160}',raw)
   matches=[m.decode('utf8','replace') for m in matches]
   if matches:
    row={'file':p.name,'size':p.stat().st_size,'matches':matches}
    f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush();print(json.dumps(row,ensure_ascii=False),flush=True)
   if any('/Font/a00.otf' in m for m in matches):break
   if i%500==0:print('scanned',i,flush=True)
  except Exception as e:print('error',p.name,repr(e),flush=True)
