# UnityCN bundle static decryption validation

2026-11-24. No game binaries or installed assets modified. No game process executed or attached.

Primary reference source downloaded from EIHRTeam/EndfieldStudio, `AnimeStudio/BundleFile.cs` and `AnimeStudio/Crypto/UnityCN.cs`.

The AzurPromilia CBT2 branch supplies an AES key and accepts a Manjuu-specific 16-byte verification signature. The previous probe assumed the standard UnityCN signature, so a correct key would have been rejected even if among the candidates. Its character filter also omitted punctuation.

The supplied source key is valid for current TW and CN samples. It is stored only in local_bundle_key.bin; do not include its contents in reports. `source_key_probe.json` validates the independent signature vectors in all 3 TW and 2 CN static bundles. All headers show UnityFS version8, encryption+compression flags1603, encryption header offset44. `unitypy_validation.json` additionally records successful actual block decryption, LZ4 decompression, serialized object indexing, and original virtual asset paths. TW object counts49,2,1849; CN1850,49.

`unity_setup.py` applies runtime changes only: fallback Unity version2022.3.62f3, alternate verification signature, Node builtin AES bridge because Python Crypto is absent. Import this module before using UnityPy. AES bridge uses stdin, not command arguments, and caches repeated vectors.

150 smallest TW default_package bundles were also successfully decrypted. Only one TextAsset was found, empty hx.txt; these samples predominantly contain meshes, materials and prefab objects. This is not evidence of absence of language tables elsewhere.

Full container/TextAsset indexing can run via index_all.py (read-only), writing all_bundle_index.jsonl incrementally. TW default package comprises9265 bundles,52,860,008,424bytes. The key opens this package too. Bundle rebuild and in-game acceptance remain untested; successful decryption alone does not establish a working localization patch.

## Fonts and missing glyphs

TW bundle `a66pm5ie1rrjguuzlsyq.r` maps to `Assets/ResourcesLang/cht/UI/Font/a00.otf`, Font object pathID5773017908170298912. The embedded FontData is3,430,152bytes, named MiSans TC. Parsing the actual sfnt cmap tables yields15,068 glyphs. Basic Simplified Chinese test characters absent include `戏设开继续载简认国发这还龙剑语剧汉`. Therefore merely converting text while retaining this font would produce missing glyphs. See font_coverage.json and check_font.py. Exported font only in workspace tw_a00.otf.

CN equivalent bundle `8x9p6gjcxiiwn2fhqzya.r` maps to `Assets/ResourcesLang/chs/UI/Font/a00.otf`, Font object pathID-1787419980166199311. FontData6,550,784bytes, names MiSans and Noto Sans S Chinese,29,571glyphs. Both Simplified and Traditional Chinese test sets fully covered (no missing test characters). Workspace export cn_a00.otf; cn_font_info.json and cn_font_coverage.json record validation. This provides an official font candidate for updating only TW FontData while retaining TW asset identity, path and references. Actual rebuild/runtime acceptance remains untested.

The user saw blank UI after setting appConfig language to chs. The TW default container inventory has cht-specific font and atlas paths. This supports a missing language resource path as an explanation, but does not by itself establish the exact runtime failure.

## Font patch candidates (workspace only)

build_font_candidate.py produces a TW a00 candidate modifying only FontData. Complete reload verifies4 objects, unchanged object IDs and container, all other objects' raw data byte-identical, all other Font typetree fields identical, and external resource node bytes identical. UnityPy save emits an unencrypted candidate (flags194), so this alone was unsuitable for proving original encryption compatibility.

reencrypt_bundle.py implements the inverse UnityCN LZ4-token nibble mapping. It creates `tw_a00_cn_font_unitycn.r`, preserving original flags1603 and the original70-byte encryption header. All51 compressed blocks roundtrip through the original decryptor identically, and a complete reload verifies all objects match the plain candidate. New size6,136,171bytes, SHA256e65d778508b8d04c44c843cd1de28d43d82712a90f60f0b1f2e06283473ec372, CRC329950669d. Original size3,114,015bytes, SHA25663e71f27e39018a52e8f83d3fc838bfd50a26cf188fc5756ca94186320a082c5, CRC32b409d783. Detailed machine-readable evidence in font_candidate_validation.json. No installed files modified; actual game acceptance and manifest updates remain untested.

Raw package magic inventory (package_magic_inventory.json) found no UnityFS files in raw_nostreaming or raw_streaming. raw_base contains one UnityFS file `er7xoolkavfru9mijeg.r`, successfully parsed as a mouse icon Texture2D, not a text table.

## Final pack correction and deployment plan

Important correction: many .r files contain concatenated independent UnityFS bundles. `all_bundle_index.jsonl` and `update_bundle_index.jsonl` indexed only the first UnityFS in each pack; they are not a complete asset inventory. Negative conclusions about missing language/font resources based on these inventories alone are invalid. In particular TW includes both cht and chs font resources, and all cht main SDF assets are later bundles of the b00 pack.

Current update b00 pack is owmxh3bjdhcwjoabqv67q.r (45 bundles). Candidate `tw_update_b00_cn_font_pack.r` changes only its first bundle's FontData and preserves the remaining44 bundles byte-identically. The earlier standalone b00 candidate is a segment, not a safe complete pack replacement. Use `b00_replacement_segment.r` with replace_pack_segments; plan records every manifest bundle offset/size and new offset. Never overwrite a shared pack with only its first UnityFS bundle.

All installed files remain unchanged. `font-deployment-plan.json` is the final machine-readable plan for a00, current update b00, c00, and sdf_a00_b. It includes exact installed paths, source hashes, current/builtin matching manifest paths, pack and bundle indices, offsets and lengths, replacement segments, and candidate hashes. All manifest sizes match installed originals. The complete update b00 tail is preserved.

Actual cht SDF main a00/b00/c00 assets use static atlases plus existing dynamic fallback_sdf_a00/b00/c00. Their sourceFont pointers already reference the original TW a00/b00/c00 object IDs, so replacing FontData preserves the original loader chain. `cht_pack_sdf.json` records each pointer and CAB identity. Independent sdf_a00_b had no fallback; final `tw_sdf_a00_b_fallback_unitycn.r` adds two external references and two fallback table entries to existing TW dynamic a00 and c00 resources, retaining all atlas/material/object identities. Latest candidate SHA256d9d7214b39a8266f2fbc31f16568a7866907a162e47bf61da7b2eaf360eeb3ae,6,728,067bytes,CRC3207bb7c99. It supersedes the previous single-fallback candidate.

FontTools best-cmap coverage across131,440 official-cn-candidates.json rows requires3,868 unique visible Unicode codepoints after rich markup/control/format/whitespace removal. a00 and b00 each cover all but U+25B6,U+266A,U+30FB,U+FF65. Official c00 covers all3,868. Main a00/b00 existing fallback tables include dynamic c00; new sdf_a00_b also includes c00. Union missing count0. This establishes static glyph availability; actual runtime acceptance remains untested.
