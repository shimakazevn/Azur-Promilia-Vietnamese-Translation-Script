from unity_setup import *
import json,re
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from vstring_pool import VStringPool
p=VStringPool(HERE.parent/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');hits=[]
for i in range(len(p)):
 s=p[i]
 if s and (('登' in s and ('成功' in s or '入' in s or '錄' in s)) or s in ('成功','登入','登錄','已登入','登录成功')):hits.append({'key':i,'value':s})
(HERE/'login_composition_pool.json').write_text(json.dumps(hits,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(hits[-100:],ensure_ascii=True))
