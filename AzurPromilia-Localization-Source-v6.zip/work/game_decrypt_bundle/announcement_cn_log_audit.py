from pathlib import Path
import json,re
out=[]
root=Path(r'D:\AzurPromilia\AzurPromilia_Game\PersistentDataPath\Log')
for p in root.glob('*.log'):
 for ln,line in enumerate(p.read_text(encoding='utf8',errors='replace').splitlines(),1):
  if not ('gateway' in line.lower() and '"data"' in line):continue
  start=line.find('{')
  if start<0:continue
  try:o=json.JSONDecoder().raw_decode(line[start:])[0]
  except Exception:continue
  def walk(v,path='root'):
   if isinstance(v,dict):
    for k,x in v.items():
     if k in ('title','content','body','text') and isinstance(x,str):
      clean=re.sub(r'https?://[^\s"<>]+','[URL]',x);clean=re.sub(r'[\w.+-]+@[\w.-]+','[EMAIL]',clean)
      out.append({'file':p.name,'line':ln,'jsonPath':path+'.'+k,'text':clean[:2500],'truncated':len(clean)>2500})
     elif isinstance(x,(dict,list)):walk(x,path+'.'+k)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+f'[{i}]')
  walk(o)
Path('work/game_decrypt_bundle/cn_announcement_display_evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(out,ensure_ascii=True))
