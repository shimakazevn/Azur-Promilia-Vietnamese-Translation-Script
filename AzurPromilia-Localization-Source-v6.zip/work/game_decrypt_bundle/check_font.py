from pathlib import Path
import struct,json
p=Path(__file__).with_name('tw_a00.otf');b=p.read_bytes()
u16=lambda o:struct.unpack_from('>H',b,o)[0]
u32=lambda o:struct.unpack_from('>I',b,o)[0]
tables={b[o:o+4].decode(): (u32(o+8),u32(o+12)) for o in range(12,12+u16(4)*16,16)}
cmap=tables['cmap'][0];glyphs=set()
for i in range(u16(cmap+2)):
 off=cmap+u32(cmap+4+i*8+4);fmt=u16(off)
 if fmt==12:
  for j in range(u32(off+12)):
   start,end,g=u32(off+16+12*j),u32(off+20+12*j),u32(off+24+12*j)
   glyphs.update(range(start+(g==0),end+1))
 if fmt==4:
  n=u16(off+6)//2
  for j in range(n):
   end=u16(off+14+2*j);start=u16(off+16+2*n+2*j);delta=u16(off+16+4*n+2*j);ro=off+16+6*n+2*j;value=u16(ro)
   for cp in range(start,min(end,0xfffe)+1):
    gid=((cp+delta)&65535) if not value else u16(ro+value+2*(cp-start))
    if gid:glyphs.add(cp)
tests='游戏设置开始继续下载简体中文确认返回体国发后这还龙剑魔语言剧情道具技能汉化測試繁體設定開始繼續下載確認返回國發後這還龍劍魔語言劇情'
report={'font':'MiSans TC','glyphCount':len(glyphs),'testPresent':''.join(c for c in tests if ord(c) in glyphs),'testMissing':''.join(c for c in tests if ord(c) not in glyphs)}
p.with_name('font_coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False))
