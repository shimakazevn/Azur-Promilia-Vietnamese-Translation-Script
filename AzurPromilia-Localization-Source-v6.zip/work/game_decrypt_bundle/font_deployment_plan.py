from pathlib import Path
import sys,json,hashlib,struct,re,unicodedata
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'));sys.path.insert(0,str(HERE.parent/'font_deps'))
from parse_manifest import parse
from patch_manifest import encode_name
from fontTools.ttLib import TTFont
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
manifests=[base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes',base/'StreamingAssets/.res/default_package/0release_default_package_3060618.bytes']
maps=[]
for m in manifests:
 d=parse(m);maps.append((m,d,{encode_name(p['name0'],p['name1']):i for i,p in enumerate(d['packs'])}))
specs=[('a00','a66pm5ie1rrjguuzlsyq.r','tw_a00_cn_font_unitycn.r','builtin'),('b00','owmxh3bjdhcwjoabqv67q.r','tw_update_b00_cn_font_pack.r','update'),('c00','p4hifvtlpthiunufa1lslg.r','tw_c00_cn_font_unitycn.r','builtin'),('sdf_a00_b','db0aboccfhk0ruhzeueydq.r','tw_sdf_a00_b_fallback_unitycn.r','builtin')]
plans=[]
for label,name,candidate,layer in specs:
 install=base/('.res/default_package/BundleFiles' if layer=='update' else 'StreamingAssets/.res/default_package')/name
 original=install.read_bytes();new=(HERE/candidate).read_bytes();oldFirst=struct.unpack_from('>Q',original,24)[0];newFirst=struct.unpack_from('>Q',new,24)[0]
 replacement=HERE/(label+'_replacement_segment.r');replacement.write_bytes(new[:newFirst])
 matches=[]
 for m,d,names in maps:
  if name not in names:continue
  pi=names[name];pack=d['packs'][pi];segments=[dict(index=i,offset=b['offset'],size=b['size'],crc32=f"{b['crc']:08x}",newOffset=0 if b['offset']==0 else b['offset']+newFirst-oldFirst,newSize=newFirst if b['offset']==0 else b['size']) for i,b in enumerate(d['bundles']) if b['pack_id']==pi]
  matches.append({'manifest':str(m),'packIndex':pi,'manifestPackSize':pack['size'],'installedSizeAgrees':pack['size']==len(original),'bundles':segments})
 plans.append({'name':label,'installPath':str(install),'installedSha256':hashlib.sha256(original).hexdigest(),'candidatePath':str(HERE/candidate),'candidateSha256':hashlib.sha256(new).hexdigest(),'replacementSegmentPath':str(replacement),'oldFirstBundleSize':oldFirst,'newFirstBundleSize':newFirst,'preservedTailBytes':len(original)-oldFirst,'manifests':matches})
candidates=json.loads((HERE.parent/'game_decrypt_paths/official-cn-candidates.json').read_text(encoding='utf8'))
chars=set()
for row in candidates:
 text=re.sub(r'<[^>]*>','',row['cn'])
 chars.update(c for c in text if not unicodedata.category(c).startswith('C') and not c.isspace())
fontFiles={'a00':HERE/'cn_a00.otf','b00':HERE/'cn_b00.otf','c00':HERE/'official_chs_c00.otf'}
coverage={};sets={}
for label,p in fontFiles.items():
 font=TTFont(p,lazy=True);cmap=font.getBestCmap();sets[label]=set(cmap)
 missing=sorted(c for c in chars if ord(c) not in cmap)
 coverage[label]={'font':str(p),'cmapGlyphs':len(cmap),'requiredUnique':len(chars),'missingCount':len(missing),'missingCharacters':''.join(missing),'missingCodepoints':[f'U+{ord(c):04X}' for c in missing]}
combined=set.union(*sets.values());missing=sorted(c for c in chars if ord(c) not in combined)
report={'installedFilesModified':False,'plans':plans,'coverage':{'source':str(HERE.parent/'game_decrypt_paths/official-cn-candidates.json'),'rows':len(candidates),'policy':'Removed rich markup <...>, Unicode category C control/format/unassigned/surrogate and all whitespace. All remaining literal codepoints required. Dynamic TMP fallback rendering not runtime tested.','requiredUnique':len(chars),'fonts':coverage,'combinedMissingCount':len(missing),'combinedMissingCharacters':''.join(missing),'combinedMissingCodepoints':[f'U+{ord(c):04X}' for c in missing]}}
(HERE/'font-deployment-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'plans':[(p['name'],[(m['manifest'],m['packIndex'],len(m['bundles']),m['installedSizeAgrees']) for m in p['manifests']]) for p in plans],'coverage':report['coverage']},ensure_ascii=True))
