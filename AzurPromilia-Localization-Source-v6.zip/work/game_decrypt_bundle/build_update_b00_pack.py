from unity_setup import *
from reencrypt_bundle import wrap
import struct,copy,json,hashlib,zlib
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\.res\default_package\BundleFiles\owmxh3bjdhcwjoabqv67q.r')
original=p.read_bytes();oldSize=struct.unpack_from('>Q',original,24)[0];first=original[:oldSize];tail=original[oldSize:]
env=UnityPy.load(first);font=next(o for o in env.objects if o.type.name=='Font');before={o.path_id:o.get_raw_data() for o in env.objects};tree=font.read_typetree();old=copy.deepcopy(tree);tree['m_FontData']=list((HERE/'cn_b00.otf').read_bytes());font.save_typetree(tree)
plain=next(iter(env.files.values())).save(packer='lz4');encrypted,n=wrap(plain,first);full=encrypted+tail;out=HERE/'tw_update_b00_cn_font_pack.r';out.write_bytes(full)
check=UnityPy.load(encrypted);changed=[str(o.path_id) for o in check.objects if o.get_raw_data()!=before[o.path_id]];assert changed==[str(font.path_id)]
assert full[len(encrypted):]==tail
offsets=[];o=0
while o<len(original):
 assert original[o:o+8]==b'UnityFS\0';size=struct.unpack_from('>Q',original,o+24)[0];offsets.append({'oldOffset':o,'newOffset':0 if o==0 else o+len(encrypted)-oldSize,'oldSize':size,'newSize':len(encrypted) if o==0 else size});o+=size
assert o==len(original)
sha=lambda b:hashlib.sha256(b).hexdigest()
report={'source':str(p),'candidate':str(out),'originalBytes':len(original),'newBytes':len(full),'originalSha256':sha(original),'newSha256':sha(full),'originalCrc32':f'{zlib.crc32(original):08x}','newCrc32':f'{zlib.crc32(full):08x}','tailBytes':len(tail),'tailSha256':sha(tail),'tailByteIdentical':True,'shift':len(encrypted)-oldSize,'bundles':offsets,'changedObjectIds':changed,'allOtherFirstBundleObjectsUnchanged':True,'fontOtherFieldsUnchanged':{k:v for k,v in old.items() if k!='m_FontData'}=={k:v for k,v in next(o for o in check.objects if o.type.name=='Font').read_typetree().items() if k!='m_FontData'},'encryptionFlags':1603,'runtimeAcceptanceTested':False}
(HERE/'update_b00_pack_validation.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in report.items() if k!='bundles'}))
