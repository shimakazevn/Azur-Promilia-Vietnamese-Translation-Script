from unity_setup import *
from reencrypt_bundle import wrap
import csv,io,json,hashlib,zlib,struct
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
p=base/'StreamingAssets/.res/static_package/nkewfips4anrz2bqfjhpg.r';original=p.read_bytes();size=struct.unpack_from('>Q',original,24)[0];assert size==len(original)
env=UnityPy.load(original);objects=list(env.objects);before={o.path_id:hashlib.sha256(o.get_raw_data()).hexdigest() for o in objects};obj=next(o for o in objects if o.path_id==-7652933866689782301);tree=obj.read_typetree();text=tree['m_Script'];text=text.decode('utf8') if isinstance(text,bytes) else text
rows=list(csv.reader(io.StringIO(text)));header=[x.lstrip('\ufeff') for x in rows[0]];chs=header.index('chs');cht=header.index('cht');changed=[]
for row in rows[1:]:
 if len(row)>max(chs,cht) and row[chs] and row[cht]!=row[chs]:changed.append({'key':row[0],'before':row[cht],'after':row[chs]});row[cht]=row[chs]
s=io.StringIO(newline='');writer=csv.writer(s,lineterminator='\n');writer.writerows(rows);output=s.getvalue();tree['m_Script']=output;obj.save_typetree(tree)
bundle=next(iter(env.files.values()));plain=bundle.save(packer='lz4');encrypted,n=wrap(plain,original);dest=HERE/'tw_static_csv_zhcn_unitycn.r';dest.write_bytes(encrypted)
check=UnityPy.load(encrypted);after={o.path_id:hashlib.sha256(o.get_raw_data()).hexdigest() for o in check.objects};assert [k for k in before if before[k]!=after[k]]==[obj.path_id]
newtext=next(o for o in check.objects if o.path_id==obj.path_id).read_typetree()['m_Script'];newtext=newtext.decode('utf8') if isinstance(newtext,bytes) else newtext;assert newtext==output
sha=lambda b:hashlib.sha256(b).hexdigest()
report={'source':str(p),'sourceBytes':len(original),'sourceSha256':sha(original),'sourceCrc32':f'{zlib.crc32(original):08x}','candidate':str(dest),'candidateBytes':len(encrypted),'candidateSha256':sha(encrypted),'candidateCrc32':f'{zlib.crc32(encrypted):08x}','textAssetName':tree.get('m_Name'),'objectId':obj.path_id,'objectCount':len(objects),'onlyThisObjectRawChanged':True,'containerUnchanged':list(env.container)==list(check.container),'blocksRoundtrip':n,'changedRows':changed,'changedRowCount':len(changed),'flags':1603,'installedModified':False}
(HERE/'static_csv_candidate.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in report.items() if k!='changedRows'},ensure_ascii=True))
