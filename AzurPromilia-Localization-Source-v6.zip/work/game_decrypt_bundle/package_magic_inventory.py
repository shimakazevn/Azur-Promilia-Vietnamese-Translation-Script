from pathlib import Path
import json,collections
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res')
report={}
for package in base.iterdir():
 if not package.is_dir(): continue
 counts=collections.Counter();unity=[]
 for p in package.glob('*.r'):
  with p.open('rb') as f:b=f.read(8)
  counts[b.hex()]+=1
  if b.startswith(b'UnityFS'):unity.append(p.name)
 report[package.name]={'headerCounts':counts,'unityFsCount':len(unity),'unityFsExamples':unity[:10]}
Path(__file__).with_name('package_magic_inventory.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps({k:{'unityFs':v['unityFsCount'],'headers':len(v['headerCounts'])} for k,v in report.items()}))
