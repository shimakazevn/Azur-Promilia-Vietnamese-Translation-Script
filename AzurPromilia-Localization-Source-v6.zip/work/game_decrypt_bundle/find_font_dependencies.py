from fast_serialized import *
import json
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
targets=[]
for layer,folder in [('builtin',base/'StreamingAssets/.res/default_package'),('update',base/'.res/default_package/BundleFiles')]:
 for p in folder.glob('*.r'):targets.append((layer,p))
rows=[]
for i,(layer,p) in enumerate(targets):
 try:
  raw=load_serialized(p,'edges')
  if not any(s in raw for s in [b'sdf_a00',b'sdf_b00',b'sdf_c00',b'fallback_sdf']):continue
  env=load_serialized(p)
  for o in env.objects:
   if o.type.name!='MonoBehaviour':continue
   d=o.read_typetree()
   if 'm_AtlasPopulationMode' not in d:continue
   row={'layer':layer,'file':p.name,'id':o.path_id,'name':d.get('m_Name'),'source':d.get('m_SourceFontFile'),'mode':d['m_AtlasPopulationMode'],'fallback':d.get('m_FallbackFontAssetTable'),'characters':len(d.get('m_CharacterTable',[])),'externals':[x.path for x in o.assets_file.externals]}
   rows.append(row);print(json.dumps(row),flush=True)
 except Exception as e:pass
 if i%1000==0:print('scan',i,flush=True)
(HERE/'font_dependencies.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
