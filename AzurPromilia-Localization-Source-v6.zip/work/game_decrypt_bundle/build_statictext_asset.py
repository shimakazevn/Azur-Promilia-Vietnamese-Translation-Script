from unity_setup import *
from reencrypt_bundle import wrap
import sys,json,hashlib,zlib,copy
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
from opencc import OpenCC
converter=OpenCC('t2s')
def locate(region):
 base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data') if region=='tw' else Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data')
 version='3221745' if region=='tw' else '3217420';prefix='0release' if region=='tw' else '00';lang='cht' if region=='tw' else 'chs'
 mp=base/f'.res/default_package/ManifestFiles/{prefix}_default_package_{version}.bytes';m=parse(mp)
 pool=VStringPool(HERE.parent/'game_mmap/decoded'/('tw_update_v0k2cafcxjxawklow6skg.bin' if region=='tw' else 'cn_update_bjzqzapbodx6zodmvtrta.bin'))
 target=f'Assets/ResourcesLang/{lang}/UI/StaticText/ast_staticTextKeyConfig.asset'
 a=next(a for a in m['assets'] if pool[a['path_key']]==target);b=m['bundles'][a['bundle']];pack=m['packs'][b['pack_id']];name=encode_name(pack['name0'],pack['name1']);p=base/'.res/default_package/BundleFiles'/name
 if not p.exists():p=base/'StreamingAssets/.res/default_package'/name
 with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
 e=UnityPy.load(raw);o=next(o for o in e.objects if o.type.name=='MonoBehaviour')
 return mp,p,a,b,raw,e,o
tm,tp,ta,tb,tr,te,to=locate('tw');cm,cp,ca,cb,cr,ce,co=locate('cn')
tt=to.read_typetree();ct=co.read_typetree();lookup={x['key']:x['value'] for x in ct['list']};tree=copy.deepcopy(tt);changes=[];unmatched=[]
for row in tree['list']:
 if row['key'] in lookup:
  if row['value']!=lookup[row['key']]:changes.append({'key':row['key'],'tw':row['value'],'cn':lookup[row['key']]});row['value']=lookup[row['key']]
 else:
  unmatched.append(copy.deepcopy(row))
  simplified=converter.convert(row['value'])
  if simplified!=row['value']:changes.append({'key':row['key'],'tw':row['value'],'cn':simplified,'source':'OpenCC t2s'});row['value']=simplified
before={o.path_id:o.get_raw_data() for o in te.objects};to.save_typetree(tree);plain=next(iter(te.files.values())).save(packer='lz4');enc,n=wrap(plain,tr);out=HERE/'tw_statictext_official_cn_v2_segment.r';out.write_bytes(enc)
check=UnityPy.load(enc);after={o.path_id:o.get_raw_data() for o in check.objects};assert [i for i in before if before[i]!=after[i]]==[to.path_id];loaded=next(o for o in check.objects if o.path_id==to.path_id).read_typetree();assert loaded==tree
sha=lambda b:hashlib.sha256(b).hexdigest()
report={'twManifest':str(tm),'twPack':str(tp),'twPackSourceSha256':sha(tp.read_bytes()),'twAsset':ta,'twBundle':tb,'cnManifest':str(cm),'cnPack':str(cp),'cnAsset':ca,'cnBundle':cb,'candidateSegment':str(out),'candidateSha256':sha(enc),'candidateBytes':len(enc),'candidateCrc32':f'{zlib.crc32(enc):08x}','originalSegmentSha256':sha(tr),'objectId':to.path_id,'onlyThisObjectRawChanged':True,'containerUnchanged':list(check.container)==list(te.container),'versionRetained':tree['version'],'rowCount':len(tt['list']),'matchedKeys':len(tt['list'])-len(unmatched),'changedRows':len(changes),'unmatched':unmatched,'changes':changes,'blockRoundtripCount':n,'installedModified':False}
(HERE/'statictext_v2_candidate.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in report.items() if k not in ('changes','unmatched')},ensure_ascii=True))
