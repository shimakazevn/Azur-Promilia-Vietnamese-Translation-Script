from unity_setup import *
from reencrypt_bundle import wrap
import json,hashlib,csv,io,copy
sys.path.insert(0,str(HERE.parent/'game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import replace_pack_segments
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');sha=lambda b:hashlib.sha256(b).hexdigest();plan={'packs':[],'evidence':[],'installedModified':False}
specs=[('static',base/'StreamingAssets/.res/static_package/nkewfips4anrz2bqfjhpg.r',base/'StreamingAssets/.res/static_package/0release_static_package_3060618.bytes',1,-7652933866689782301),('statictext',base/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r',base/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes',369116,-7302953340476202124)]
for label,p,mp,bi,oid in specs:
 original=p.read_bytes();m=parse(mp);b=m['bundles'][bi];segment=original[b['offset']:b['offset']+b['size']];e=UnityPy.load(segment);objs={o.path_id:o for o in e.objects};before={i:o.get_raw_data() for i,o in objs.items()};obj=objs[oid];t=obj.read_typetree();changes=[]
 if label=='static':
  old=t['m_Script'];old=old.decode('utf8') if isinstance(old,bytes) else old;rows=list(csv.reader(io.StringIO(old)));head=[x.lstrip('\ufeff') for x in rows[0]];cht=head.index('cht');chs=head.index('chs')
  for row in rows[1:]:
   if row[0]=='shader_loading':
    plan['evidence'].append({'location':label,'key':row[0],'chs':row[chs],'cht':row[cht]})
    assert not row[chs];assert row[cht]=='正在編譯著色器';changes.append({'key':row[0],'before':row[cht],'after':'正在编译着色器'});row[cht]='正在编译着色器'
   if any(x in str(row) for x in ('未入駐','不能切換')):plan['evidence'].append({'location':label,'row':row})
  s=io.StringIO(newline='');csv.writer(s,lineterminator='\n').writerows(rows);t['m_Script']=s.getvalue()
 else:
  for row in t['list']:
   if any(x in row['value'] for x in ('未入','不能切','闇星')):plan['evidence'].append({'location':label,**row})
   replacements={'未入駐':'未入驻','当前状态不能切換':'当前状态不能切换','當前狀態不能切換':'当前状态不能切换'}
   if row['value'] in replacements:changes.append({'key':row['key'],'before':row['value'],'after':replacements[row['value']]});row['value']=replacements[row['value']]
 if not changes:continue
 obj.save_typetree(t);plain=next(iter(e.files.values())).save(packer='lz4');enc,n=wrap(plain,segment);check=UnityPy.load(enc);after={o.path_id:o.get_raw_data() for o in check.objects};assert [i for i in before if before[i]!=after[i]]==[oid];assert next(o for o in check.objects if o.path_id==oid).read_typetree()==t
 segpath=HERE/f'tw_{label}_v3_segment.r';segpath.write_bytes(enc);pack,manifest,mhash,rep=replace_pack_segments(mp.read_bytes(),p,{bi:enc},original);out=HERE/f'tw_{label}_v3_pack.r';out.write_bytes(pack);mo=HERE/f'tw_{label}_v3_manifest.bytes';mo.write_bytes(manifest);mo.with_suffix('.hash').write_bytes(mhash);nm=parse(manifest)
 for i,bb in enumerate(m['bundles']):
  if bb['pack_id']!=b['pack_id'] or i==bi:continue
  nb=nm['bundles'][i];assert original[bb['offset']:bb['offset']+bb['size']]==pack[nb['offset']:nb['offset']+nb['size']]
 plan['packs'].append({'installedPath':str(p),'currentSHA':sha(original),'candidatePath':str(out),'candidateSHA':sha(pack),'segmentReplacements':[{'bundleIndex':bi,'candidateSegmentPath':str(segpath)}],'manifestPaths':[str(mp)],'candidateManifestPath':str(mo),'changes':changes,'blocksRoundtrip':n,'onlyChangedObjectId':oid,'unchangedObjects':len(before)-1})
 print(label,changes,flush=True)
# Only report matching resources.assets rows. Never modify it.
e=UnityPy.load(str(base/'resources.assets'))
for o in e.objects:
 if o.type.name!='TextAsset':continue
 t=o.read_typetree();s=t.get('m_Script','');s=s.decode('utf8',errors='replace') if isinstance(s,bytes) else s
 if 'shader_loading' in s:plan['evidence'].append({'location':'resources.assets','objectId':o.path_id,'name':t.get('m_Name'),'rows':[r for r in s.splitlines() if 'shader_loading' in r]})
(HERE/'ui-v3-changes.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(plan,ensure_ascii=True))
