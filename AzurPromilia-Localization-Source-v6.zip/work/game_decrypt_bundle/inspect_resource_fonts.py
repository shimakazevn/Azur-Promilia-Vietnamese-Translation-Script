from unity_setup import *
import json
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\resources.assets')
env=UnityPy.load(str(p));rows=[]
for o in env.objects:
 if o.type.name!='MonoBehaviour':continue
 try:
  d=o.read_typetree()
  if 'm_AtlasPopulationMode' not in d:continue
  row={k:v for k,v in d.items() if any(q in k.lower() for q in ['name','sourcefont','population','atlaswidth','atlasheight','multiatlas','fallback','dynamic'])}
  row['id']=o.path_id;row['characters']=len(d.get('m_CharacterTable',[]));row['externals']=[x.path for x in o.assets_file.externals];rows.append(row)
 except Exception:pass
(HERE/'resource_sdf_inspection.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(rows,ensure_ascii=False))
