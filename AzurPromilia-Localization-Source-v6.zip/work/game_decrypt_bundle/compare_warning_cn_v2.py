from unity_setup import *
import json,struct,hashlib
items=[]
base=Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data\StreamingAssets\.res\static_package')
for p in base.glob('*.r'):
 data=p.read_bytes();off=0
 while off<len(data):
  size=struct.unpack_from('>Q',data,off+24)[0];e=UnityPy.load(data[off:off+size]);off+=size
  for o in e.objects:
   if o.type.name not in ('Texture2D','Sprite'):continue
   t=o.read_typetree()
   if t.get('m_Name') in ('tex_welcome_word_xq','tex_login_word_jkzg'):
    item={'pack':str(p),'offset':off-size,'size':size,'id':o.path_id,'type':o.type.name,'tree':t};items.append(item)
    if o.type.name=='Texture2D':o.read().image.save(HERE/(t['m_Name']+'_cn_v2.png'))
(HERE/'cn_warning_images_v2.json').write_text(json.dumps(items,ensure_ascii=False,indent=2,default=str),encoding='utf8');print([(x['pack'],x['id'],x['type']) for x in items])
