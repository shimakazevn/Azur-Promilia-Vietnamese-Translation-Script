from pathlib import Path
import sys,json,hashlib,re
sys.path.insert(0,'work/game_compare_manifests')
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data');v=VStringPool('work/game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');folder=Path('work/game_decrypt_bundle/display_code');folder.mkdir(exist_ok=True);out=[]
for package in ('raw_base_package','raw_nostreaming_package'):
 mp=base/f'.res/{package}/ManifestFiles/0release_{package}_3221745.bytes';m=parse(mp)
 for a in m['assets']:
  path=v[a['path_key']]
  if not ('HotfixDlls/' in path and 'Assembly-CSharp' in path or '/Lua/' in path and ('announcement' in path.lower() or 'pageGatewayAnnouncementWindow' in path)):continue
  b=m['bundles'][a['bundle']];pk=m['packs'][b['pack_id']];name=encode_name(pk['name0'],pk['name1']);p=base/f'.res/{package}/BundleFiles'/name
  if not p.exists():p=base/f'StreamingAssets/.res/{package}'/name
  with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
  decoded=raw[128:].translate(bytes(x^64 for x in range(256))) if package=='raw_nostreaming_package' else raw
  dest=folder/Path(path).name;dest.write_bytes(decoded)
  constants=[s.decode('utf8',errors='replace') for s in re.findall(rb'[\x20-\x7e]{5,}',decoded)] if package=='raw_nostreaming_package' else []
  out.append({'path':path,'source':str(p),'bundleIndex':a['bundle'],'bytes':len(raw),'sourceSHA':hashlib.sha256(raw).hexdigest(),'decodedPrefix':decoded[:16].hex(),'output':str(dest),'asciiStrings':constants})
(folder/'index.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps([{k:v for k,v in x.items() if k!='asciiStrings'} for x in out],ensure_ascii=True))
