from unity_setup import *
import json,re
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\static_package\nkewfips4anrz2bqfjhpg.r')
e=UnityPy.load(p.read_bytes());items=[]
for o in e.objects:
 try:t=o.read_typetree()
 except Exception:continue
 name=t.get('m_Name','')
 if o.type.name in ('Texture2D','Sprite') or re.search('warning|health|login',name,re.I):
  items.append({'id':o.path_id,'type':o.type.name,'name':name,'tree':t if o.type.name not in ('Texture2D',) else {k:v for k,v in t.items() if k not in ('image data',)}})
(HERE/'startup_image_objects_v2.json').write_text(json.dumps(items,ensure_ascii=False,indent=2,default=lambda x:f'<bytes {len(x)}>' if isinstance(x,bytes) else str(x)),encoding='utf8')
print(json.dumps([{'id':i['id'],'type':i['type'],'name':i['name']} for i in items],ensure_ascii=True))
