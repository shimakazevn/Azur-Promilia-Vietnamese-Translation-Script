from unity_setup import *
import struct,json,re
roots=[Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\default_package'),Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\.res\default_package\BundleFiles')]
out=HERE/'packed_font_index.jsonl'
with out.open('w',encoding='utf8') as fw:
 for root in roots:
  for i,p in enumerate(root.glob('*.r')):
   with p.open('rb') as f:
    off=0
    while off<p.stat().st_size:
     f.seek(off);h=f.read(256)
     if not h.startswith(b'UnityFS\0'):break
     pos=h.index(0,12)+1;pos=h.index(0,pos)+1;size=struct.unpack_from('>Q',h,pos)[0]
     if size<50 or off+size>p.stat().st_size:break
     # Fonts are tiny-to-medium standalone bundles; skip large leading art blocks.
     if size<500000:
      f.seek(off);raw=f.read(size)
      env=UnityPy.load(raw)
      for o in env.objects:
       if o.type.name not in ('Font','MonoBehaviour'):continue
       try:
        d=o.read_typetree()
        if o.type.name=='MonoBehaviour' and 'm_AtlasPopulationMode' not in d:continue
        row={'layer':'update' if 'BundleFiles' in str(root) else 'builtin','file':p.name,'bundleOffset':off,'bundleSize':size,'id':o.path_id,'type':o.type.name,'name':d.get('m_Name'),'container':list(env.container)}
        if o.type.name=='Font':row.update(fontBytes=len(d['m_FontData']),fontNames=d['m_FontNames'])
        else:row.update(source=d.get('m_SourceFontFile'),mode=d['m_AtlasPopulationMode'],fallback=d.get('m_FallbackFontAssetTable'),characters=len(d.get('m_CharacterTable',[])),externals=[x.path for x in o.assets_file.externals])
        fw.write(json.dumps(row,ensure_ascii=False)+'\n');fw.flush();print(row['layer'],p.name,off,row['name'],flush=True)
       except Exception:pass
     off+=size
   if i%500==0:print('pack',i,flush=True)
