from unity_setup import *
import json
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\static_package\nkewfips4anrz2bqfjhpg.r');e=UnityPy.load(p.read_bytes());objs={o.path_id:o for o in e.objects};trees={i:o.read_typetree() for i,o in objs.items() if o.type.name not in ('Texture2D','Mesh','Font','Shader')}
root=next(i for i,t in trees.items() if t.get('m_Name')=='ScreenWarning');selected={root};todo=[root]
while todo:
 i=todo.pop();t=trees.get(i,{})
 def walk(v):
  if isinstance(v,dict):
   if v.get('m_FileID')==0 and v.get('m_PathID') in trees:
    k=v['m_PathID']
    if k not in selected:selected.add(k);todo.append(k)
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(t)
out=[{'id':i,'type':objs[i].type.name,'tree':trees[i]} for i in selected]
(HERE/'warning_refs_v2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8');print(len(out))
