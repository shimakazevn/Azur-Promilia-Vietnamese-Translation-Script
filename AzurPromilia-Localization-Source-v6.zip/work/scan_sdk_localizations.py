from pathlib import Path
import json,zlib,hashlib,re
ROOT=Path(__file__).resolve().parent.parent
base=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\Plugins\mj_sdk')
targets=['登入成功','切換帳號','登录成功','切换账号','伺服器尚未開放','星躍始動']
patterns={}
for s in targets:
 for enc in ['utf8','utf-16-le','utf-16-be']:patterns[s,enc]=s.encode(enc)
 patterns[s,'json_escaped']=s.encode('unicode_escape').replace(b'\\u',b'\\u')
report=[]
for p in [base/'union_pcsdk.dll',base/'sdkbrowser.exe']:
 data=p.read_bytes();count=0
 for match in re.finditer(b'\x78[\x01\x9c\xda]',data):
  pos=match.start()
  try:
   dec=zlib.decompressobj();out=dec.decompress(data[pos:],32*1024*1024)
   if not dec.eof:continue
  except zlib.error:continue
  count+=1;hits=[]
  for (s,enc),n in patterns.items():
   if n in out:hits.append(dict(text=s,encoding=enc,offset=out.find(n)))
  if hits:
   dest=ROOT/'work/sdk-locale-analysis'/f'{p.stem}-{pos:x}.bin';dest.parent.mkdir(exist_ok=True);dest.write_bytes(out)
   report.append(dict(file=str(p),compressed_offset=pos,decoded_bytes=len(out),sha256=hashlib.sha256(out).hexdigest(),hits=hits,extracted=str(dest)))
 print(json.dumps(dict(file=p.name,zlib_resources=count,matching_resources=len([x for x in report if x['file']==str(p)]))),flush=True)
(ROOT/'work/sdk-locale-analysis').mkdir(exist_ok=True)
(ROOT/'work/sdk-locale-analysis/report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=True),flush=True)
