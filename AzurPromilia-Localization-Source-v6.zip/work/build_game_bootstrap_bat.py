import base64,json,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent
m=json.loads((HERE/'game_bootstrap_patch.json').read_text('utf-8'))
ps=(HERE/'game_bootstrap_portable.ps1').read_text('utf-8').replace('__ORIGINAL_HASH__',m['original_sha256']).replace('__PATCHED_HASH__',m['patched_sha256'])
bundle=json.loads((HERE/'game_bootstrap_patch_bundle.json').read_text('utf-8'));bundle.pop('manifest')
payload=base64.b64encode(json.dumps(bundle,separators=(',',':')).encode()).decode()
bootstrap=(HERE.parent/'outputs/台服日服启动器汉化与还原.bat').read_text('utf-8').split('\n:__SCRIPT__\n',1)[0]
bat=bootstrap+'\n:__SCRIPT__\n'+ps+'\n:__DATA__\n'+'\n'.join(payload[i:i+120] for i in range(0,len(payload),120))+'\n'
target=HERE.parent/'outputs/台服游戏启动文本简体试验版.bat'
target.write_bytes(bat.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
print(json.dumps(dict(file=str(target),bytes=target.stat().st_size),ensure_ascii=False))
