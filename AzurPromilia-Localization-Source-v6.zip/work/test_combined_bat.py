import base64,ctypes,gzip,hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent
root=HERE/'combined_bat_qa'/'游戏 测试 & 路径'
root.mkdir(parents=True,exist_ok=True)
build=json.loads((HERE/'combined_bat_build.json').read_text('utf-8'))
regions={r['id']:r for r in build['regions']}
source_bat=Path(build['bat']);bat=root/'台日 合并工具 & 测试.bat'
shutil.copy2(source_bat,bat)
folders={
    'tw':root/'台服'/'AzurPromilia_TC'/'1.0.1.4',
    'jp':root/'日服'/'YostarGames'/'AZUPRO_JP_Gamelauncher',
}
originals={
    'tw':Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak'),
    'jp':Path(r'E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar.before-zhcn-20261124.bak'),
}
archives={};backups={}
for key,folder in folders.items():
    (folder/'resources').mkdir(parents=True,exist_ok=True)
    shutil.copy2(Path('C:/Windows/System32/cmd.exe'),folder/regions[key]['exe'])
    archives[key]=folder/'resources'/'app.asar'
    backups[key]=archives[key].with_name('app.asar.before-zhcn-20261124.bak')
    shutil.copy2(originals[key],archives[key])
    if backups[key].exists():
        assert hashlib.sha256(backups[key].read_bytes()).hexdigest()==regions[key]['original']
        backups[key].unlink()
checks=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(tw='original',jp='original'):
    for key,value in [('tw',tw),('jp',jp)]:assert digest(archives[key])==regions[key][value],(key,value)
def run(name,answers,expect,success=True,hint=root,tool=None):
    tool=tool or bat
    command=f'cmd.exe /d /s /c ""{tool}"'+(f' "{hint}"' if hint is not None else '')+'"'
    start=time.monotonic()
    r=subprocess.run(command,input=answers+'\n\n',encoding='utf-8',errors='replace',capture_output=True,cwd=root,timeout=90)
    output=r.stdout+r.stderr
    assert (r.returncode==0)==success,(name,r.returncode,output)
    assert 'is not recognized' not in output and '�' not in output,(name,output)
    for text in ([expect] if isinstance(expect,str) else expect):assert text in output,(name,text,output)
    checks.append(dict(name=name,returncode=r.returncode,seconds=round(time.monotonic()-start,2),output=output))
    print(name,'PASS',flush=True)
    return output
run('scan_and_exit','Q',['[台服 / 原版]','[日服 / 原版]','1. 台服汉化','2. 日服汉化','3. 全部汉化','4. 还原'])
state()
run('apply_tw_only','1','[台服] 简体汉化完成！');state('patched','original')
run('restore_tw_only','4\n1','[台服] 已成功还原原版启动器。');state()
run('apply_jp_only','2','[日服] 简体汉化完成！');state('original','patched')
run('restore_jp_only','4\n2','[日服] 已成功还原原版启动器。');state()
run('apply_both','3',['[台服] 简体汉化完成！','[日服] 简体汉化完成！']);state('patched','patched')
run('repeat_apply','3',['[台服] 当前已经是完整简体汉化版本。','[日服] 当前已经是完整简体汉化版本。']);state('patched','patched')
run('restore_both','4\n3',['[台服] 已成功还原原版启动器。','[日服] 已成功还原原版启动器。']);state()
run('repeat_restore','4\n3','当前已经是原版，无需还原。');state()
run('missing_region','2','没有找到该区服支持版本的启动器。',False,hint=root/'台服');state()
run('single_region_restore','4','当前已经是原版，无需还原。',hint=root/'日服');state()
unknown=root/'其他版本';(unknown/'resources').mkdir(parents=True,exist_ok=True)
shutil.copy2(Path('C:/Windows/System32/cmd.exe'),unknown/'launcher.exe')
(unknown/'resources'/'app.asar').write_bytes(b'Unsupported archive; must not modify.')
run('reject_unknown','Q','未找到支持版本',hint=unknown)
assert (unknown/'resources'/'app.asar').read_bytes()==b'Unsupported archive; must not modify.'
run('reject_cn','Q','未找到支持版本',hint=r'D:\AzurPromilia')
state()
shutil.copy2(originals['tw'],backups['jp'])
run('bad_backup_preflight','3','原版备份校验失败',False);state()
shutil.copy2(originals['jp'],backups['jp'])
active=subprocess.Popen([str(folders['jp']/regions['jp']['exe']),'/d','/q','/k'],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
try:
    run('running_jp_blocks_all','3','请先完全退出日服启动器',False);state()
    run('running_jp_allows_tw','1','[台服] 简体汉化完成！');state('patched','original')
finally:
    active.terminate();active.wait(timeout=10)
run('reset_after_running_test','4\n1','[台服] 已成功还原原版启动器。');state()
# Corrupt only JP patch data; TW must remain unchanged after its staging succeeds.
text=bat.read_text('utf-8');prefix,payload=text.split('\n:__DATA__\n',1)
bundle=json.loads(gzip.decompress(base64.b64decode(payload)))
operation=next(op for op in bundle['jp']['operations'] if 'data' in op)
operation['data']=base64.b64encode(base64.b64decode(operation['data'])+b'\ncorrupt fixture').decode()
bad=root/'corrupt_payload.bat'
bad.write_bytes((prefix+'\n:__DATA__\n'+base64.b64encode(gzip.compress(json.dumps(bundle).encode())).decode()+'\n').replace('\n','\r\n').encode('utf-8'))
run('second_patch_staging_failure','3','补丁构建校验失败',False,tool=bad);state()
assert not list(root.rglob('*.zhcn-combined.tmp'))
# A read handle permits hash validation but blocks replacing JP, exercising TW rollback.
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
kernel.CreateFileW.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p]
handle=kernel.CreateFileW(str(archives['jp']),0x80000000,1,None,3,0x80,None)
assert handle!=ctypes.c_void_p(-1).value,ctypes.get_last_error()
try:
    output=run('second_replace_failure_rolls_back_tw','3','操作停止',False)
    assert '自动回退失败' not in output,output
finally:kernel.CloseHandle(handle)
state()
assert not list(root.rglob('*.zhcn-combined.tmp'))
assert not list(root.rglob('*.zhcn-combined.rollback'))
# Multiple copies of one region require a directory selection.
extra=root/'台服副本'/'AzurPromilia_TC'/'1.0.1.4'
(extra/'resources').mkdir(parents=True,exist_ok=True)
shutil.copy2(folders['tw']/'launcher.exe',extra/'launcher.exe')
shutil.copy2(originals['tw'],extra/'resources'/'app.asar')
output=run('choose_one_of_same_region','1\n2','同一区服找到多个安装位置')
all_tw=[archives['tw'],extra/'resources'/'app.asar']
assert sorted(digest(p) for p in all_tw)==sorted([regions['tw']['original'],regions['tw']['patched']])
assert digest(archives['jp'])==regions['jp']['original']
run('restore_same_region_copies','4\n1\nA','已成功还原原版启动器。')
assert all(digest(p)==regions['tw']['original'] for p in all_tw)
run('apply_same_region_copies','1\nA','简体汉化完成！')
assert all(digest(p)==regions['tw']['patched'] for p in all_tw)
run('restore_every_copy','4\n3','已成功还原原版启动器。');state()
run('manual_scan_fallback',str(root)+'\nQ','扫描结果：',hint=unknown);state()
lf=root/'LF 换行 & 测试.bat';lf.write_bytes(bat.read_bytes().replace(b'\r\n',b'\n'))
run('lf_menu','Q','4. 还原',tool=lf);state()
for key in regions:assert digest(backups[key])==regions[key]['original']
(HERE/'combined_bat_validation.json').write_text(json.dumps(dict(passed=True,cases=len(checks),checks=checks),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=True,cases=len(checks),auto_detect_both=True,apply_and_restore_both=True,chinese_space_ampersand_path=True,transaction_rollback=True),ensure_ascii=False),flush=True)
