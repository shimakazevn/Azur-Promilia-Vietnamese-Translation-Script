import copy,json,struct,sys
from pathlib import Path
from patch_launcher_language import parse,entries,member_data,sha
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent
TARGET=Path(r'E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar')
ORIGINAL='4f013026736f6afa819a37f299caa9577140e88254ef4097b4d4589fa47f0818'
original=TARGET.read_bytes()
assert sha(original)==ORIGINAL
h,_,base=parse(original)
old={n:member_data(original,e,base) for n,e in entries(h) if 'offset' in e}
updates={}
for name in ['out/main/index.js','out/renderer/assets/windowDrag-fc7999b5.js']:
    text=old[name].decode('utf-8')
    source='const langConfig = "ja"?.replace("-", "_")?.toLowerCase();'
    assert text.count(source)==1
    text=text.replace(source,'const langConfig = "zh_cn";')
    source='const locale = Object.keys(resources).includes(systemLocale) ? systemLocale : langConfig || "en";'
    assert text.count(source)==1
    text=text.replace(source,'const locale = "zh_cn";')
    if name=='out/main/index.js':
        assert text.count('tray.setToolTip("アズールプロミリア")')==1
        text=text.replace('tray.setToolTip("アズールプロミリア")','tray.setToolTip("蓝色星原：旅谣（日服）")')
    updates[name]=text.encode()
for name in ['out/renderer/main/index.html','out/renderer/update/index.html']:
    text=old[name].decode('utf-8')
    assert text.count('<title>アズールプロミリア</title>')==1
    text=text.replace('<title>アズールプロミリア</title>','<title>蓝色星原：旅谣（日服）</title>')
    text=text.replace('<html lang="en">','<html lang="zh-CN">')
    updates[name]=text.encode()
payload=bytearray();h=copy.deepcopy(h)
for name,e in entries(h):
    if 'offset' not in e:continue
    data=updates.get(name,old[name]);e['offset']=str(len(payload));e['size']=len(data)
    size=e.get('integrity',{}).get('blockSize',4194304)
    e['integrity']={'algorithm':'SHA256','hash':sha(data),'blockSize':size,'blocks':[sha(data[i:i+size]) for i in range(0,len(data),size)]}
    payload.extend(data)
header=json.dumps(h,ensure_ascii=False,separators=(',',':')).encode()
padding=(-len(header))%4
headerpickle=struct.pack('<II',4+len(header)+padding,len(header))+header+b'\0'*padding
result=struct.pack('<II',4,len(headerpickle))+headerpickle+payload
nh,_,nb=parse(result)
for name,e in entries(nh):
    if 'offset' not in e:continue
    data=member_data(result,e,nb)
    assert data==updates.get(name,old[name]),name
    assert sha(data)==e['integrity']['hash'],name
for name,data in updates.items():
    p=HERE/'launcher_jp_patched'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(HERE/'launcher_jp_zhcn.app.asar').write_bytes(result)
manifest={'target':str(TARGET),'version':'1.8.1','original_sha256':ORIGINAL,'patched_sha256':sha(result),'changed_members':list(updates),'builtin_translation_keys':104,'region_configuration_changed':False,'images_changed':False,'unchanged_members':len(old)-len(updates),'applied':False}
(HERE/'launcher_jp_patch.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
