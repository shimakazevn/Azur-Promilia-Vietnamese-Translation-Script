@echo off
chcp 65001 >nul
setlocal
set "PSModulePath=%SystemRoot%\System32\WindowsPowerShell\v1.0\Modules"
set "AZUR_PATCH_SELF=%~f0"
set "AZUR_PATCH_HINT=%~1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:AZUR_PATCH_SELF,[Text.Encoding]::UTF8); $s=(($t -split '(?m)^:__SCRIPT__\r?$',2)[1] -split '(?m)^:__DATA__\r?$',2)[0]; & ([ScriptBlock]::Create($s))"
set "AZUR_PATCH_RESULT=%errorlevel%"
exit /b %AZUR_PATCH_RESULT%
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.
rem ASCII bootstrap padding.

:__SCRIPT__
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$originalHash = 'f96fc1afe1675cdabd3c3d54008b539e89e3e65399511aa23cfc864b91c74d9f'
$patchedHash = '5c1af532a79dbae32a297418c0782447960142e8c95d28bbfb099b5301206b25'
$script:found = @{}
function Get-Hash([byte[]]$bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $h.Dispose() }
}
function Read-Answer([string]$prompt) {
    Write-Host $prompt -NoNewline
    $answer = [Console]::ReadLine()
    if ($null -eq $answer) { return '' }
    return $answer.Trim().Trim('"')
}
function Add-Game([string]$hint) {
    if (-not $hint) { return }
    try {
        $path = [IO.Path]::GetFullPath($hint.Trim().Trim('"'))
        if ([IO.File]::Exists($path)) { $path = [IO.Path]::GetDirectoryName($path) }
        if ([IO.Path]::GetFileName($path) -eq 'AzurPromilia_Data') { $path = [IO.Path]::GetDirectoryName($path) }
        $roots = @($path, (Join-Path $path 'AzurPromilia_TC_game'))
        foreach ($game in $roots) {
            $archive = Join-Path $game 'AzurPromilia_Data\resources.assets'
            if ([IO.File]::Exists((Join-Path $game 'AzurPromilia.exe')) -and [IO.File]::Exists($archive) -and -not $script:found.ContainsKey($archive)) {
                $hash = Get-Hash ([IO.File]::ReadAllBytes($archive))
                if ($hash -in @($originalHash, $patchedHash)) {
                    $script:found[$archive] = [PSCustomObject]@{ Root = $game; Archive = $archive; Hash = $hash }
                }
            }
        }
    } catch { }
}
function Invoke-Patch {
    try { [Console]::Title = '台服游戏启动文本 - 简体试验补丁' } catch { }
    # 菜单文字：这里只覆盖启动文本，尚不覆盖剧情、道具、技能与完整游戏界面。
    Write-Host '=================================================='
    Write-Host '        台服游戏启动文本简体补丁（试验版）'
    Write-Host '=================================================='
    Write-Host '仅处理启动、更新、下载和早期错误提示。'
    Write-Host '剧情、道具、技能等完整文本尚未汉化。'
    Write-Host '请先退出台服游戏。'
    Write-Host ''
    Write-Host '  1. 应用启动文本简体补丁'
    Write-Host '  2. 还原游戏原文件'
    Write-Host '  Q. 退出'
    $action = Read-Answer '请选择：'
    if ($action -eq 'q') { return }
    if ($action -notin @('1', '2')) { throw '请输入 1、2 或 Q。' }
    if ($env:AZUR_PATCH_HINT) { Add-Game $env:AZUR_PATCH_HINT }
    else {
        $nearby = [IO.Path]::GetDirectoryName($env:AZUR_PATCH_SELF)
        for ($level = 0; $level -lt 3 -and $nearby; $level++) {
            Add-Game $nearby
            $parent = [IO.Directory]::GetParent($nearby)
            if ($null -eq $parent) { break }
            $nearby = $parent.FullName
        }
        foreach ($drive in [IO.DriveInfo]::GetDrives()) {
            if (-not $drive.IsReady -or $drive.DriveType -notin @([IO.DriveType]::Fixed, [IO.DriveType]::Removable)) { continue }
            Add-Game (Join-Path $drive.RootDirectory.FullName 'AzurPromilia_TC')
            Add-Game (Join-Path $drive.RootDirectory.FullName 'Games\AzurPromilia_TC')
        }
    }
    if ($script:found.Count -eq 0 -and -not $env:AZUR_PATCH_HINT) {
        Add-Game (Read-Answer '未自动找到，请输入台服游戏目录（Q 退出）：')
    }
    $found = @($script:found.Values | Sort-Object Root)
    if ($found.Count -eq 0) { throw '没有找到匹配的台服游戏原文件或本工具已修改的文件。' }
    $game = $found[0]
    if ($found.Count -gt 1) {
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i + 1), $found[$i].Root) }
        $answer = Read-Answer '请选择游戏目录编号：'
        $index = 0
        if (-not [int]::TryParse($answer, [ref]$index) -or $index -lt 1 -or $index -gt $found.Count) { throw '目录编号无效。' }
        $game = $found[$index - 1]
    }
    Write-Host ('目标：' + $game.Root) -ForegroundColor Cyan
    $bytes = [IO.File]::ReadAllBytes($game.Archive)
    $current = Get-Hash $bytes
    if ($current -notin @($originalHash, $patchedHash)) { throw '游戏文件已变化。' }
    $expected = $(if ($action -eq '1') { $patchedHash } else { $originalHash })
    if ($current -eq $expected) { Write-Host $(if ($action -eq '1') { '当前已经应用启动文本补丁。' } else { '当前已经是原文件。' }) -ForegroundColor Green; return }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'" | Where-Object { -not $_.ExecutablePath -or $_.ExecutablePath -eq (Join-Path $game.Root 'AzurPromilia.exe') })
    if ($running.Count) { throw '请先退出台服游戏，再运行本工具。' }
    $backup = $game.Archive + '.before-game-zhcn-20261124.bak'
    if ([IO.File]::Exists($backup)) {
        if ((Get-Hash ([IO.File]::ReadAllBytes($backup))) -ne $originalHash) { throw '原版备份校验失败。' }
    } elseif ($action -eq '1' -and $current -eq $originalHash) {
        [IO.File]::Copy($game.Archive, $backup, $false)
    } else { throw '缺少有效原版备份。' }
    if ((Get-Hash ([IO.File]::ReadAllBytes($backup))) -ne $originalHash) { throw '原版备份校验失败。' }
    if ($action -eq '2') { $result = [IO.File]::ReadAllBytes($backup) }
    else {
        $text = [IO.File]::ReadAllText($env:AZUR_PATCH_SELF, [Text.Encoding]::UTF8)
        $payload = [Convert]::FromBase64String((($text -split '(?m)^:__DATA__\r?$', 2)[1] -replace '\s', ''))
        $bundle = [Text.Encoding]::UTF8.GetString($payload) | ConvertFrom-Json
        $before = [Convert]::FromBase64String($bundle.before)
        $after = [Convert]::FromBase64String($bundle.after)
        $offset = [int]$bundle.offset
        if ($before.Length -ne $after.Length -or $offset -lt 0 -or $offset + $before.Length -gt $bytes.Length) { throw '补丁数据无效。' }
        $slice = New-Object byte[] $before.Length
        [Array]::Copy($bytes, $offset, $slice, 0, $before.Length)
        if ((Get-Hash $slice) -ne (Get-Hash $before)) { throw '原文校验失败。' }
        $result = $bytes.Clone()
        [Array]::Copy($after, 0, $result, $offset, $after.Length)
    }
    if ((Get-Hash $result) -ne $expected) { throw '结果校验失败。' }
    $staging = $game.Archive + '.game-zhcn.tmp'
    $rollback = $game.Archive + '.game-zhcn.rollback'
    if ([IO.File]::Exists($staging) -or [IO.File]::Exists($rollback)) { throw '存在上次临时文件，请先检查资源目录。' }
    try {
        [IO.File]::WriteAllBytes($staging, $result)
        if ((Get-Hash ([IO.File]::ReadAllBytes($staging))) -ne $expected) { throw '写入校验失败。' }
        $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'" | Where-Object { -not $_.ExecutablePath -or $_.ExecutablePath -eq (Join-Path $game.Root 'AzurPromilia.exe') })
        if ($running.Count) { throw '请先退出台服游戏，再运行本工具。' }
        if ((Get-Hash ([IO.File]::ReadAllBytes($game.Archive))) -ne $current) { throw '操作期间游戏文件已变化。' }
        [IO.File]::Replace($staging, $game.Archive, $rollback)
        if ((Get-Hash ([IO.File]::ReadAllBytes($game.Archive))) -ne $expected) {
            [IO.File]::Replace($rollback, $game.Archive, $staging)
            throw '替换后校验失败，已回退。'
        }
        [IO.File]::Delete($rollback)
    } finally { if ([IO.File]::Exists($staging)) { [IO.File]::Delete($staging) } }
    Write-Host $(if ($action -eq '1') { '启动文本简体补丁已应用。游戏实际显示效果待验证。' } else { '游戏原文件已还原。' }) -ForegroundColor Green
    Write-Host ('原版备份：' + $backup)
}
$exitCode = 0
try { Invoke-Patch }
catch { Write-Host ('操作停止：' + $_.Exception.Message) -ForegroundColor Red; $exitCode = 1 }
$null = Read-Answer '按回车关闭窗口……'
exit $exitCode

:__DATA__
eyJvZmZzZXQiOjc2OTQ3NiwiYmVmb3JlIjoiNzd1L2EyVjVMR05vY3l4amFIUXNaVzRzYW5Bc2EzSUtZV3hsY25SZmRHbDBiR1VzNW8rUTZZYVNMT2FQa09t
R2tpeEJiR1Z5ZEN6b3JhYmxrWW9zNnJLOTZyT2dDbU52Ym1acGNtMHM1Nkd1NWE2YUxPZWl1dVd1bWl4RGIyNW1hWEp0TE9laXV1aXFqU3p0bVpYc25iZ0tZ
MkZ1WTJWc0xPV1BsdWEyaUN6bGo1Ym10b2dzUTJGdVkyVnNMT09DcmVPRG8rT0RzK09DdStPRHF5enN0NmpzaG93S2NtVjBjbmtzNlllTjZLK1ZMT21IamVp
cHBpeFNaWFJ5ZVN6bGhvM29xYWJvb1l3c0l1dUxwT3lMbkNEc2k1enJqNFFpQ25GMWFYUXM2WUNBNVllNkxPbUFnT1dIdWl4UmRXbDBMT2UxZ3VTNmh1T0Jt
ZU9DaXl6c29vWHJvNHdLYVc1cGRHbGhiR2w2YVc1bkxPYXRvK1djcU9XSW5lV25pK1dNbHVLQXBpem1yYVBsbktqbGlKM2xwNHZsakpiaWdLWXNTVzVwZEds
aGJHbDZhVzVuNG9DbUxPV0luZWFjbitXTWx1UzRyZUtBcGl3aTdMU0k2cml3N1ptVUlPeWtrZUtBcGlJS2NtVnhkV1Z6ZEdsdVoxOXBibVp2TE9hdG8rV2Nx
T2lPdCtXUGx1ZUppT2Fjck9TL29lYUJyK0tBcGl6bXJhUGxuS2puamJMbGo1Ym5pWWptbkt6a3Y2SG1nYS9pZ0tZc0lsSmxjWFZsYzNScGJtY2dhVzVtYitL
QXBpSXM1b09GNWFDeDQ0S1M1WStXNWI2WDQ0R1g0NEdtNDRHRTQ0Rys0NEdaNG9DbUxDTHNvSlhyczdUcnBid2c2ckNBN0tDNDdKaWs2NHFVSU95a2tlS0Fw
aUlLWTJobFkydHBibWRmZFhCa1lYUmxMT2F0bytXY3FPYWpnT2FmcGVhYnRPYVdzT0tBcGl6bXJhUGxuS2ptcXFMbW42WG1tN1RtbHJEaWdLWXNJa05vWldO
cmFXNW5JSFZ3WkdGMFplS0FwaUlzNXB1MDVwYXc0NEtTNTZLNjZLcU41TGl0NG9DbUxDTHNsNFhyamJEc25iVHRpcmdnN1ptVjdKMjRJT3lra2VLQXBpSUta
RzkzYm14dllXUmZhVzVtYnl6cG5JRG9wb0htbTdUbWxyQjdNSDNubW9UbXVMam1pSS9vdFlUbXVwQXM2WnlBNkthQjVwdTA1cGF3ZXpCOTU1cUU2WUdLNW9p
eTZMT0g1cnFRTENKN01IMGdiMllnWjJGdFpTQnlaWE52ZFhKalpYTWdibVZsWkNCMGJ5QmlaU0JrYjNkdWJHOWhaR1ZrSWl4N01IM2pnYTdqZ3JMamc3empn
NkRqZzZyamdyM2pnN3pqZ3JuamdwTGpnNERqZ3Fiamc3UGpnNjNqZzd6amc0bmpnWm5qZ292bHY0WG9wb0hqZ1l6amdZTGpnb3JqZ2I3amdaa3NJbnN3ZmV5
ZG1DRHFzb3pzbm9RZzY2YXM3SWFNN0lxazY2VzhJT3VMcE95YXRPdWhuT3VUbk8yVnRPeVZ2Q0R0bGFucmk0anJpNlFpQ21SdmQyNXNiMkZrWDJsdVptOWZa
R1YwWVdsc0xIc3dmZVdmdXVlaGdPaTFoT2E2a0N0N01YM3BvcDNscEpib3RZVG11cEFzZXpCOTVaKzY1NlNPNkxPSDVycVFLM3N4ZmVtaGplV2tsdWl6aCth
NmtDd2llekI5SUc5bUlFSmhjMmxqSUNzZ2V6RjlJRzltSUVGa1pHbDBhVzl1WVd3aUxIc3dmZVdmdXVla2ppdDdNWDNvdjczbGlxQXNJbnN3ZlNEcXVMRHN0
SWdnSUNzZ2V6RjlJT3kybE9xd2dDSUtaRzkzYm14dllXUnBibWNzNXB1MDVwYXc1TGl0TE9hYnRPYVdzT1M0clN4RWIzZHViRzloWkdsdVp5empnNERqZ3Fi
amc3UGpnNjNqZzd6amc0bmt1SzBzSXV1THBPeWF0T3Vobk91VG5DRHNwSkVpQ21SdmQyNXNiMkZrWDNOd1pXVmtYM05zYjNjczVMaUw2TDI5NkwrSDVvV2k3
N3lNNksrMzVxT0E1cCtsNTcyUjU3dWNMT1M0aStpOGllbUJqdWFGb3UrOGpPaXJpK2Fxb3VhZnBlZTJzdWUxb1N3aVJHOTNibXh2WVdRZ2RHOXZJSE5zYjNj
c0lIQnNaV0Z6WlNCamFHVmpheUIwYUdVZ2JtVjBkMjl5YXlJczQ0T0E0NEttNDRPejQ0T3Q0NE84NDRPSjQ0R002WUdGNDRHWjQ0R080NEcrNDRHWjQ0Q0I0
NE9ONDRPRDQ0T0k0NE92NDRPODQ0S3Y0NEtTNTZLNjZLcU40NEdYNDRHbTQ0R1A0NEdnNDRHVjQ0R0VMQ0xyaTZUc21yVHJvWnpyazV6cXNJQWc2NFNJNjZ5
MElPdUtrT3VtdmV1TGlPdUxwQ3dnNjRTazdZcTQ3SnVNN1lHczY2VzhJTzJabGV5ZHVPMlZ0T3lqdk95RXVPeWFsQ0lLWlc1MFpYSnBibWRmWjJGdFpTem1t
N1RtbHJEbHJvem1yNVh2dkl6bGpiUGxzSWJvdjV2bGhhWG11TGptaUkvdnZJRXM1cHUwNXBhdzVhNk01NVdpNzd5TTVZMno1YkNINllDeTVZV2w2WUdLNW9p
eTc3eUJMQ0pWY0dSaGRHVWdZMjl0Y0d4bGRHVXVJRVZ1ZEdWeWFXNW5JU0lzNXB1MDVwYXc1YTZNNUxxRzQ0Q0I1WVdsNDRLSzQ0Rys0NEdaNzd5QkxDTHNs
NFhyamJEc25iVHRpcmdnN0ptRTY2T01MQ0RzcDRUc25vWHRsYW5yaTRqcmk2UWhJZ3BqYjI1dVpXTjBYMlpoYVd4bFpDem52WkhudTV6b3Y1N21qcVhscExI
b3RLVXM1N2F5NkxldjZZQ2o1bzZsNWFTeDVwV1hMQ0pPWlhSM2IzSnJJR052Ym01bFkzUnBiMjRnWm1GcGJHVmtJaXpqZzQzamc0UGpnNGpqZzYvamc3empn
cS9tanFYbnRwcmpnYXZscExIbWxaZmpnWmZqZ2I3amdaZmpnWjhzSXV1RXBPMkt1T3liak8yQnJDRHNsN0Rxc3JEc2w1QWc3SXVrN1l5bzdaYUk3SXExNjR1
STY0dWtJZ3BsY25KdmNsOHRNU3pudlpIbnU1em92NTdtanFYbHZJTGx1TGp2dkl6b3I3ZmxzSjNvcjVYb3Y1N21qcVhudlpIbnU1enZ2SXpsdWJicGg0M2xr
Sy9tdUxqbWlJL3Z2SUVzNTdheTU3V2g2WUNqNW82bDVieUM1Ymk0Nzd5TTZLdUw1WmlYNkttbTZZQ2o1bzZsNTdheTU3V2g3N3lNNUxpbTZZZU41WldUNllH
SzVvaXk3N3lCTENKT1pYUjNiM0pySUdOdmJtNWxZM1JwYjI0Z1pYSnliM0lzSUhCc1pXRnpaU0IwY25rZ2RHOGdZMjl1Ym1WamRDQjBieUIwYUdVZ2JtVjBk
Mjl5YXlCaGJtUWdjbVZ6ZEdGeWRDQjBhR1VnWjJGdFpTRWlMT09EamVPRGcrT0RpT09EcitPRHZPT0NyK2FPcGVlMm11T0NxT09EcWVPRHZPT0FnZU9EamVP
RGcrT0RpT09EcitPRHZPT0NyK09CcSthT3BlZTJtdU9CbCtPQWdlT0NzdU9Edk9PRG9PT0NrdVdHamVpMXQrV0xsZU9CbCtPQnB1T0JqK09Cb09PQmxlT0Jo
Tys4Z1N3aTY0U2s3WXE0N0p1TTdZR3NJT3lYc09xeXNDRHNtS1RycFpnc0lPdUVwTzJLdU95YmpPMkJyT3lYa0NEc2w3RHFzckR0bFpqcXM2QWc2cktNN0o2
RTdKMkVJT3VMcE95TG5DRHNpNXpzbnBIdGxaanNpNjNzaTV6c21LUWhJZ3BsY25KdmNsOHhNREF3TE9hSWtPV0tueXptaUpEbGlwOHNVM1ZqWTJWemN5em1p
SkRsaXA4czdJU3g2ck8xQ21WeWNtOXlYekV3TURFczU3Tzc1N3VmNlpTWjZLK3ZMT2V6dStlMXNlbU1yK2lxcEN3aVUzbHpkR1Z0SUdWeWNtOXlJaXpqZ3Jm
amdybmpnNGJqZzZEamdxampnNm5qZzd3c0l1eUxuT3lLcE8yRm5DRHNtS1RycFpnaUNtVnljbTl5WHpFd01ESXNTVkRvb3F2bnBvSG1yYUlzU1ZEb29xdm5w
b0htcmFJc0lrbFFJR2x6SUdKaGJtNWxaQ0lzU1ZEamdZem5wb0htcmFMamdaWGpnb3pqZ2FiamdZVGpnYjdqZ1prc0lrbFE2ckNBSU9xNGlPeW5nT3VRbU95
WGlPeUt0ZXVMaU91THBDSUtaWEp5YjNKZk1UQXdNeXptbkkzbGlxSGxtYWpudTdUbWlxVGt1SzBzNTZlQjVweU41Wm1vNTdhdDZLMjM1TGl0TENKVFpYSjJa
WElnYVhNZ2RXNWtaWElnYldGcGJuUmxibUZ1WTJVaUxPT0N0ZU9Edk9PRGtPT0R2T09CcitPRG9lT0RzK09EaHVPRGl1T0RzK09DdWVTNHJlT0JwK09CbVN3
aTdJU2M2N0tFNnJDQUlPeWNvT3luZ0NEcXRJRHJwcXdnN0tTUjdKNkY2NHVJNjR1a0lncGxjbkp2Y2w4eE1EQTBMT2V0dnVXUWplbVVtZWl2cnl6bnNMM2xr
STNwaksvb3FxUXNJbE5wWjI1aGRIVnlaU0JsY25KdmNpSXM1NzJ5NVpDTjQ0S280NE9wNDRPOExDTHNoSnpycW9VZzdKaWs2NldZSWdwbGNuSnZjbDh4TURB
MUxPV1BndWFWc09tVW1laXZyeXpsajRQbWxianBqSy9vcXFRc0lsQmhjbUZ0WlhSbGNpQmxjbkp2Y2lJczQ0T1I0NE9wNDRPaDQ0Tzg0NEsvNDRPODQ0S280
NE9wNDRPOExDTHJwNlRxc0p3ZzY3T0E3SWlZSU95WXBPdWxtQ0lLZFhCa1lYUmxYMkZzWlhKMFgyMWxjM05oWjJVczZaeUE2S2FCNUxpTDZMMjk2TFdFNXJx
UTVaQ081b21ONVkrdjVMdWw2TCtiNVlXbExPbWNnT2ltZ2VTNGkraThpZWl6aCthNmtPV1FqdWFKamVXUHIrUzdwZW1Bc3VXRnBTd2lXVzkxSUc1bFpXUWdk
RzhnWkc5M2JteHZZV1FnZEdobElISmxjMjkxY21ObElHSmxabTl5WlNCNWIzVWdZMkZ1SUdGalkyVnpjeUJwZENJczQ0S2k0NEt2NDRLNzQ0SzU0NEdaNDRL
TDVZbU40NEdyNDRPcTQ0Szk0NE84NDRLNTQ0S1M0NE9BNDRLbTQ0T3o0NE90NDRPODQ0T0o0NEdaNDRLTDViK0Y2S2FCNDRHTTQ0R0M0NEtLNDRHKzQ0R1pM
Q0xycHF6c2hvenNpcVRzbDVBZzdKV2g3SVM0N0lxazdaV1k2NkNrNjZtMElPdW92T3lnZ0NEcnBxenNob3pzaXFUcnBid2c2NHVrN0pxMDY2R2M2NU9jN1pX
MDdKVzhJTzJWcWV1TGlPdUxwQ0lLZFhCa1lYUmxYMkZzWlhKMFgzUnZaMmRzWlY5bWRXeHNYM1JwZEd4bExDTGxyb3ptbGJUb3RZVG11cEFnS0hzd2ZTa2lM
Q0xscm96bWxiVG9zNGZtdXBBZ0tIc3dmU2tpTENKR2RXeHNJRkpsYzI5MWNtTmxjeUFvZXpCOUtTSXNJdVd1ak9XRnFPT0JxdU9EcXVPQ3ZlT0R2T09DdVNB
b2V6QjlLU0lzSXV5Z2hPeXl0Q0RycHF6c2hvenNpcVFnS0hzd2ZTa2lDblZ3WkdGMFpWOWhiR1Z5ZEY5MGIyZG5iR1ZmWm5Wc2JGOXpkV0owYVhSc1pTemxq
SVhsa0t2bXVMam1pSS9ubW9UbGhhanBnNmpvdFlUbXVwQXM1WXlGNVpDcjZZR0s1b2l5NTVxRTVZV282WU9vNkxPSDVycVFMQ0pKYm1Oc2RXUmxjeUJoYkd3
Z2RHaGxJR0Z6YzJWMGN5QnZaaUIwYUdVZ1oyRnRaU0lzNDRLeTQ0Tzg0NE9nNDRHdTQ0R1o0NEc1NDRHbTQ0R3U0NEtpNDRLNzQ0T0Q0NE9JNDRHTTVaQ3I0
NEcrNDRLTTQ0R200NEdFNDRHKzQ0R1pMQ0xxc296c25vVHNuWmdnNjZxbzY1T2dJT3lla095Q3NPeWRoQ0R0ajZ6dGxhanRsYW5yaTRqcmk2UXVJZ3AxY0dS
aGRHVmZZV3hsY25SZmRHOW5aMnhsWDJKaGMybGpYM1JwZEd4bExDTGxuN3Jub1lEb3RZVG11cEFnS0hzd2ZTa2lMQ0xsbjdybnBJN29zNGZtdXBBZ0tIc3dm
U2tpTENKQ1lYTnBZeUJTWlhOdmRYSmpaWE1nS0hzd2ZTa2lMQ0xqZzVuamc3empncm5qZzZyamdyM2pnN3pqZ3JrZ0tIc3dmU2tpTENMc25xenJpNmdnN0o2
UTY2T01JQ2g3TUgwcElncDFjR1JoZEdWZllXeGxjblJmZEc5bloyeGxYMkpoYzJsalgzTjFZblJwZEd4bExPUzdoZVdNaGVXUXErYTR1T2FJaitpL2tPaWhq
T2VhaE9XZnV1ZWhnT2kxaE9hNmtPKzhqT1dGdHVXdWcraTFoT2E2a09XUHIrV2NxT2E0dU9hSWoraXV2dWU5cnVTNHJlUzRpK2k5dlN6bGc0WGxqSVhsa0t2
cGdZcm1pTExwZ1l2b29Zem5tb1RsbjdybnBJN29zNGZtdXBEdnZJemxoYmJscm9Qb3M0Zm11cERsajYvbG5LanBnWXJtaUxMb3FLM2xycHJrdUsza3VJdm92
SWtzSWs5dWJIa2dZbUZ6YVdNZ2NtVnpiM1Z5WTJWeklHWnZjaUJuWVcxbElHRnlaU0JwYm1Oc2RXUmxaQzRnVDNSb1pYSWdjbVZ6YjNWeVkyVnpJR05oYmlC
aVpTQmtiM2R1Ykc5aFpHVmtJR2x1SUdkaGJXVWdjMlYwZEdsdVozTXVJaXpqZ3JMamc3empnNkRscnAvb29ZempnYTdqZ1ovamdvSGpnYTdsbjdybW5Lempn
NnJqZ3Izamc3empncm5qZ2E3amdiL2pnWXpsa0t2amdiN2pnb3pqZ0lIamdaM2pnYTdrdTViamdhN2pnNnJqZ3Izamc3empncm5qZ2EvamdyTGpnN3pqZzZE
b3FLM2xycHJqZ1l2amdvbmpnNERqZ3Fiamc3UGpnNjNqZzd6amc0bmpnYWZqZ1kzamdiN2pnWmtzSXVxeWpPeWVoQ0RzaTZUdGxvbnNuWVFnN0p5RTdaV2NJ
T3E0c091enVDRHJwcXpzaG96c2lxVHJwNHdnN1krczdaV29MQ0RxdUxEdGc0QWc2NmFzN0lhTTdJcWs2NHFVSU9xeWpPeWVoQ0RzaEtUc29KWHNsNURzaEp3
ZzY0dWs3SnEwNjZHYzY1T2NJT3F3Z091S3BTSUtibVYwZDI5eWExOWhiR1Z5ZEY5MGFYQnpMQ0xsdlpQbGlZM2t1THJwblo1WFNVWko1NDZ2NWFLRDc3eU01
cGl2NVpDbTVMMi81NVNvNXJXQjZZZVA1TGlMNkwyOVB5QWlMT2VicnVXSmplZUN1dW1kbmxkSlJrbm5rckRsb29QdnZJem1tSy9sa0tia3ZiL25sS2ptdFlI
cGg0L2t1SXZvdklrL0xDSlVhR2x6SUdseklHRWdibTl1TFZkSlJra2daVzUyYVhKdmJtMWxiblF1SUVSdklIbHZkU0IzWVc1MElIUnZJSFZ6WlNCMGNtRm1a
bWxqSUhSdklHUnZkMjVzYjJGa1B5SXNJdU9CaytPQ2pPT0JyK21kbmlCWFNVWkpJT2VTc09XaWcrT0JwK09CbWVPQWd1T0RnT09DcHVPRHMrT0RyZU9Edk9P
RGllT0JxK09EaU9PRHFlT0RsZU9DbytPRGcrT0NyK09Da3VTOXYrZVVxT09CbCtPQnZ1T0JtZU9CaXo4aUxDSlhTVVpKNnJDQUlPeVZoT3VMakNEdG1aanFz
cjNzbDVEc2hKd2c2NHVrN0pxMDY2R2M2NU9jNjZXOElPeWNoTzJWdENEdGlyanJucGp0bEwzc25ZUWc3SUtzN0pxcDdaV1k3SXVjNnJLZzdJcTE2NHVJNnJt
TVB5SUtjbVZ6YjNWeVkyVmZkbVZ5YVdaNWFXNW5YM1JwY0hNc0lpRG1yYVBsbktqbW9LSHBxb3pvdFlUbXVwRGlnS1lpTE9hdG8rV2NxT2Fnb2VtcGwraXpo
K2E2a09LQXBpd2lWbVZ5YVdaNWFXNW5JSEpsYzI5MWNtTmxjeTR1TGlJczQ0T3E0NEs5NDRPODQ0SzU0NEtTNTZLNjZLcU40NEdYNDRHbTQ0R0U0NEcrNDRH
WjRvQ21MQ0xycHF6c2hvenNpcVFnN1ptVjdKMjRJT3lra2VLQXBpSUtjbVZ6YjNWeVkyVmZiRzloWkdsdVoxOTBhWEJ6TE9hdG8rV2NxT1dLb09pOXZlUzRy
ZUtBcGl6bXJhUGxuS2psaXFEb3ZJbmt1SzNpZ0tZc1RHOWhaR2x1Wnk0dUxpem9xcTNqZ2Ivb3ZyempnYi9rdUszaWdLWXNJdXVobk91VG5DRHNwSkhpZ0tZ
aUNuUnBjRjkwYVhSc1pTem1qNURucExvczVvK1E1NlM2TEN6amc1TGpnN1BqZzRnc0NtOXViSGxmYkdGMWJtTm9aWElzNksrMzVMMi81NVNvNVpDdjVZcW81
Wm1vNVpDdjVZcW81cmk0NW9pUExPaXJpK1M5ditlVXFPV1ZuK1dMbGVXWnFPV1ZuK1dMbGVtQml1YUlzaXdzNDRLeTQ0Tzg0NE9nNDRLUzZMVzM1WXVWNDRH
WjQ0S0w0NEdyNDRHdjQ0T3A0NE96NDRPQjQ0T2o0NE84NDRLUzQ0R1U1WWlwNTVTbzQ0R1A0NEdnNDRHVjQ0R0VMQXB2ZFhSZmIyWmZaR2x6YTE5emNHRmpM
T1c5aytXSmplV0pxZVM5bWVlamdlZWJtT1drcCtXd2orUzRqZWkyc3l6bm02N2xpWTNsaWFucHBKam5vNEhub3AvbHBLZmxzSS9rdUkzb3RyTXNMT09EaCtP
Q28rT0N1ZU9DcitPQnJ1ZXB1dU9CamVXdXVlbUhqK1M0amVpMnN5d0tiM1YwWDI5bVgyUnBjMnRmYzNCaFkxOXphWHBsTE9pdXZ1V2toK1dHaGVXdG1PUzRq
ZWkycysrOGpPbWNnT2ltZ1hzd2ZlZXB1dW1YdE9hSmplV1ByK2U3cCtlN3JlUzRpK2k5dmVPQWdpem9xSzNsZ3BubnFicnBscFBrdUkzb3RyUHZ2SXpwbklE
b3BvRjdNSDNucWJycGxwUG1pWTNsajYvbnViem51b3prdUl2b3ZJbmpnSUlzTE9TN2l1V2JudU9CcnVhYnRPYVdzTys4aUhzd2ZlKzhpZU9CcStXL2hlaW1n
ZU9CcXVPQ3N1T0R2T09Eb09PRGgrT0R2T09DditPQ2t1T0NwT09EcytPQ3VlT0RpT09Edk9PRHErT0JtZU9DaStPQm4rT0NnZU9CcnVlcHV1T0JqZVd1dWVt
SGorT0JqT1M0amVpMnMrT0JsK09CcHVPQmhPT0J2dU9CbVN3S1pHOTNibXh2WVdSZlptRnBiQ3ptbzREbXRZdmxpTERsclpqbG5Lamt1SXZvdmIzbHBMSG90
S1hubW9UbWxvZmt1N1lzNXFxaTVyaXM1WWl3NWEyWTVaeW81TGlMNkx5SjVhU3g1cFdYNTVxRTVwYUg1THUyTEN6a3VJRHBnNmpqZ2E3amc1WGpncUhqZ3FU
amc2dmpnYTdqZzREamdxYmpnN1BqZzYzamc3empnNG5qZ2F2bHBMSG1sWmZqZ1pmamdiN2pnWmZqZ1o4c0NtbHVhWFJmWm1GcGJDemxpSjNscDR2bGpKYmxw
TEhvdEtVczVZaWQ1YWVMNVl5VzVhU3g1cFdYTEN6bGlKM21uSi9sakpiamdhdmxwTEhtbFpmamdaZmpnYjdqZ1pmamdaOHNDbWRsZEY5c2IyTmhiRjlzYVhO
MFgyWmhhV3dzNkk2MzVZK1c1cHlzNVp5dzZMV0U1cnFRNXJpRjVZMlY1YVN4NkxTbExPZU5zdVdQbHVhY3JPV2NzT2l6aCthNmtPYTRoZVdXcnVXa3NlYVZs
eXdzNDRPdDQ0Tzg0NEtyNDRPcjQ0R3U0NE9xNDRLOTQ0Tzg0NEs1NW9PRjVhQ3g0NEtTNVkrVzViNlg0NEduNDRHTjQ0Rys0NEdiNDRLVDQ0R240NEdYNDRH
ZkxBcG5aWFJmYkc5allXeGZkbVZ5YzJsdmJsOW1ZV2xzTE9pT3QrV1BsdWFjck9XY3NPZUppT2Fjck9XUHQrV2tzZWkwcFN6bmpiTGxqNWJtbkt6bG5MRG5p
WWptbkt6b21aL2xwTEhtbFpjc0xPT0RyZU9Edk9PQ3ErT0RxK09CcnVPRGtPT0R2T09DdU9PRHArT0RzK2FEaGVXZ3NlT0NrdVdQbHVXK2wrT0JwK09CamVP
QnZ1T0JtK09DaytPQnArT0JsK09Cbnl3S2IzQmxibDl6ZEdGeWRGOTJhV1YzWDJaaGFXd3M1WkN2NVlxbzU1V002WjJpNW9tVDVieUE1YVN4NkxTbExPV1Zu
K1dMbGVTN2krbWRvdWFKayttV2krV2tzZWFWbHl3czZMVzM1WXVWNTVTNzZaMmk0NEd1NktxdDQ0Ry82TDY4NDRHLzQ0R3I1YVN4NXBXWDQ0R1g0NEcrNDRH
WDQ0R2ZMQXB2Y0dWdVgyaHZkSFZ3WkdGMFpWOTJhV1YzWDJaaGFXd3M1NE90NXB1MDU1V002WjJpNW9tVDVieUE1YVN4NkxTbExPZUdzZWFidE9TN2krbWRv
dWFKayttV2krV2tzZWFWbHl3czQ0S2k0NE9ENDRPWDQ0T0g0NE84NDRPSTU1Uzc2WjJpNDRHdTZLcXQ0NEcvNkw2ODQ0Ry80NEdyNWFTeDVwV1g0NEdYNDRH
KzQ0R1g0NEdmTEFwblpYUmZjMlZ5ZG1WeVgyeHBjM1JmWm1GcGJDem9qcmZsajVibW5JRG1sckRvdFlUbXVwRG11SVhsalpYbHBMSG90S1VzNTQyeTVZK1c1
cHlBNXBhdzZMT0g1cnFRNXJpRjVaYXU1YVN4NXBXWExDem1uSURtbHJEamdhN2pnNnJqZ3Izamc3empncm5tZzRYbG9MSGpncExsajVibHZwZmpnYWZqZ1kz
amdiN2pnWnZqZ3BQamdhZmpnWmZqZ1o4c0NtZGxkRjl6WlhKMlpYSmZkbVZ5YzJsdmJsOW1ZV2xzTE9pT3QrV1BsdWFjZ09hV3NPZUppT2Fjck9Xa3NlaTBw
U3puamJMbGo1Ym1uSURtbHJEbmlZam1uS3pscExIbWxaY3NMT2FjZ09hV3NPT0JydU9Ea09PRHZPT0N1T09EcCtPRHMrYURoZVdnc2VPQ2t1V1BsdVcrbCtP
QnArT0JqZU9CdnVPQm0rT0NrK09CcCtPQmwrT0JueXdLYkc5aFpGOXNiMkZrWlhKZlpHeHNYMlpoYVd3czVZcWc2TDI5NUx1ajU2Q0I1YVN4NkxTbExPaXVn
T1dQbHVTN28rZWl2T1drc2VhVmx5d3M0NEt6NDRPODQ0T0o0NEd1NktxdDQ0Ry82TDY4NDRHLzQ0R3I1YVN4NXBXWDQ0R1g0NEcrNDRHWDQ0R2ZMQXB6Wkd0
ZmFXNXBkRjltWVdsc0xGTkVTK1dJbmVXbmkrV01sdVdrc2VpMHBlKzhqT2FZcitXUXB1bUhqZWFXc09XSW5lV25pK1dNbGl4VFJFdmxpSjNscDR2bGpKYmxw
TEhtbFpmdnZJem1tSy9sa0ticGg0M21sckRsaUozbHA0dmxqSllzTEN3S2NHVnlabTl5YldGdVkyVmZZMmhsWTJ0ZlptRnBiQ3ptajVEbnBMcnZ2SnJtbzRE
bXRZdmxpTERsdlpQbGlZM29ycjdscElma3ZZN2t1bzdtbklEa3ZZN3BoWTNudmE3b3BvSG1zWUx2dkl6bXVMam1pSS9vdjRmbnFJdmt1SzNsajYvb2c3M2t2
SnJsaDdybmpyRGxqYUhwb2IvamdJSHBsNnJwZ0lEbnJZbm1nNFhsaHJVczVvK1E1NlM2Nzd5YTVxcWk1cmlzNVlpdzU1dXU1WW1ONktpdDVZS1o1TDJPNXBh
ODVweUE1TDJPNllXTjU3MnU2S2FCNXJHQzc3eU02WUdLNW9peTZZR081NmlMNUxpdDVZK3Y2SU85NXB5RDVZZTY1NCsrNVkyaDZhQ1Q0NENCNlphRDZZQ0E1
NjJKNW9PRjVyT0JMQ3dzQ21WeWNtOXlYM05sY25abGNsOHhMT2FKcCtpaGpPbVVtZWl2cnl6bG43Zm9vWXpwaksvb3FxUXNMQ3dLWlhKeWIzSmZjMlZ5ZG1W
eVh6RXdNREF3TE9hY2plV0tvZVdacU9lNWdlVy9tU3prdkxybW5JM2xtYWpudVlIbHY1a3NMQ3dLWlhKeWIzSmZjMlZ5ZG1WeVh6RXdNREF4TE9lSmlPYWNy
T1Mvb2VhQnIrUzRqZVd0bU9XY3FDem5pWWptbkt6b3M0Zm9xSXJrdUkzbHJaamxuS2dzTEN3S1pYSnliM0pmYzJWeWRtVnlYekV3TURBeUxPYXlvZWFjaWVh
SnZ1V0lzT2E0b09tQmsrUy9vZWFCcnl6bXNwTG1uSW5taWI3bGlMRG5ycUhwZ1pQb3M0Zm9xSW9zTEN3S1pYSnliM0pmYzJWeWRtVnlYekV3TURBekxPYXlv
ZWFjaWVhSnZ1V0lzT2E0dU9hSWowbEVMT2F5a3VhY2llYUp2dVdJc09tQml1YUlza2xFTEN3c0NtVnljbTl5WDNObGNuWmxjbDh4TURBd05Dem1uSTNsaXFI
bG1hanBsSm5vcjY4czVMeTY1cHlONVptbzZZeXY2S3FrTEN3c0NtVnljbTl5WDNObGNuWmxjbDh4TURBd05TeEpVT2lpcStXd2dlZW1nU3hKVU9paXErV3dn
ZWVtZ1N3c0xBcGxjbkp2Y2w5elpYSjJaWEpmTVRBd01EWXM2TFNtNVkrMzZLS3I1YkNCNTZhQkxPVzRzK2labitpaXErV3dnZWVtZ1N3c0xBcGxjbkp2Y2w5
elpYSjJaWEpmTVRBd01EY3M1cHlONVlxaDVabW81TGlONVkrdjU1U29MT1M4dXVhY2plV1pxT1M0amVXUHIrZVVxQ3dzTEFwbGNuSnZjbDl6WlhKMlpYSmZN
VEF3TURnczVvS282WnlBNkthQjVwdTA1cGF3NW9LbzU1cUU1YTZpNW9pMzU2dXY1NG1JNXB5c0tPYTRvT21CaytlSmlPYWNyT1M0amVXTXVlbUZqU2tzNW9L
bzZaeUE2S2FCNXB1MDVwYXc1b0tvNTVxRTVhNmk1b2kyNTZ1djU0bUk1cHlzS09ldW9lbUJrK2VKaU9hY3JPUzRqZVdNdWVtRmpTa3NMQ3dLWlhKeWIzSmZj
MlZ5ZG1WeVh6RXdNREE1TE9hWHR1bVh0T2FJcythZ29lbXFqT1dIdXVtVW1Tem1tWUxwbHBQbWlMUG1vS0hwcVpmbGg3cnBqSzhzTEN3S1pYSnliM0pmYzJW
eWRtVnlYekV3TURFd0xFTmtidWl2dCtheGd1V1BndWFWc09tVW1laXZyeXhEWkc3b3E0dm1zWUxsajRQbWxianBqSy9vcXFRc0xDd0taWEp5YjNKZmMyVnlk
bVZ5WHpFMU1EQXdNU3dpU1c1MllXeHBaQ0JUWlhOemFXOXVTVVFpTENKSmJuWmhiR2xrSUZObGMzTnBiMjVKUkNJc0xDd0taWEp5YjNKZmMyVnlkbVZ5WHpF
MU1EQXdNaXpucmI3bGtJM3BsSm5vcjY4czU3Qzk1WkNONll5djZLcWtMQ3dzQ21WeWNtOXlYM05sY25abGNsOHhOVEF3TURNczZLKzM1ckdDNXBXdzVvMnU1
YnlDNWJpNDc3eUk1cFd3NW8ydTZaU1o2Syt2Nzd5TTZLKzM1ckdDNXBXdzVvMnU1cUM4NWJ5UDZaU1o2Syt2Nzd5SkxDTG9xNHZtc1lMbWxiam1rNXJubGJE
bHVMZ2dLT2FWdU9hVG11bU1yK2lxcE8rOGpPaXJpK2F4Z3VhVnVPYVRtdWFndk9XOGorbU1yK2lxcENraUxDd3NDbVZ5Y205eVgzTmxjblpsY2w4eE5UQXdN
RFFzNksrMzVyR0M1cFd3NW8ydTVieUM1Ymk0Nzd5STVvbW42S0dNNWJ5QzViaTQ3N3lNNUw2TDVhYUM1cGUyNlplMDVvaXo1TGlONWErNTc3eUpMQ0xvcTR2
bXNZTG1sYmptazVybmxiRGx1TGdnS09XZnQraWhqT2VWc09XNHVDemt2b3ZscG9MbW1ZTHBscFBtaUxQa3VJM2xzSTBwSWl3c0xBcGxjbkp2Y2w5elpYSjJa
WEpmWkdWbVlYVnNkQ3ptbkkzbGlxSGxtYWpuaXJibWdJSG51WUhsdjVrczVMeTY1cHlONVptbzU0dUE1b1dMNTdtQjViK1pMQ3dzQ25CaFkydGhaMlZmYm1W
bFpGOTFjR1JoZEdVc0l1bWNnT2ltZ2VhYnRPYVdzQ3dnNksrMzVMaUw2TDI5NXB5QTVwYXc1NG1JNXB5czU1cUU1YTZKNktPRjVZeUY2TCtiNVlXbDVyaTQ1
b2lQSWl6cG5JRG9wb0htbTdUbWxyRHZ2SXpvcTR2a3VJdm92SW5tbklEbWxyRG5pWWptbkt6bm1vVGxyb25vbzUzbXFwVG1vWWpwZ0xMbGhhWHBnWXJtaUxJ
c0xDd0tjMmhoWkdWeVgyeHZZV1JwYm1jczVxMmo1WnlvNTd5VzZLK1I1NTJBNklteTVabW9MT2F0bytXY3FPZTNxT2l0citpUmwraUpzdVdacUN3c0xBcHph
R0ZrWlhKZmQyRnBkR2x1WjE5a1pXWjFiSFJmZEdsd2N5em52SmJvcjVIbm5ZRG9pYkxsbWFqb2dKZm1sN2Jvdm9QcGxiL3Z2SXpvcjdmbW1KL2t1TFRvZ0lY
b2dKRGx2NFBucllubHZvVXM1N2VvNksydjZKR1g2SW15NVptbzZJQ1g1cG1DNkx5RDZaVzM3N3lNNkt1TDVwaWY2SWVvNklDRjZJQ1E1YitENTYySjViNkZM
Q3dzQ25Ob1lXUmxjbDkzWVdsMGFXNW5YMmx2YzE5MGFYQnpMQ0xudkpib3I1SG5uWURvaWJMbG1ham9nSmZtbDdib3ZvUHBsYjhzNUxpNjVvK1E1WTJINXBX
STU0Nkg3N3lNNVlxbzU1Uzc1cHFDNVlHYzVwS3Q1cFMrNzd5TTZLKzM1cGlmNUxpMDZJQ0Y2SUNRNWIrRDU2Mko1YjZGSWl6bnQ2am9yYS9va1pmb2liTGxt
YWpvZ0pmbW1ZTG92SVBwbGJmdnZJem5ncnJtajVEbGpZZm1sWWpuam9mdnZJemxpNVhubGF2bW1xdmxnWnpta3EzbWxMN3Z2SXpvcTR2bW1KL29oNmpvZ0lY
b2dKRGx2NFBucllubHZvVXNMQ3dLY0dGamEyRm5aVjl1WldWa1gzVndaR0YwWlY5cGJtNWxjaXdpNVlhRjU3MlI1YTJZNVp5bzVwYXc1NXFFNWE2SjZLT0Y1
WXlGTENEbGo2L3BnSW5taTZua3VJdm92YjNtbklEbWxyRGxyb25vbzRYbGpJVXNJT2VDdWVXSHUrZWhydVd1bXVpL20rV0ZwZWE0dU9hSWp5SXM1WTJBNVor
ZjU3YXk2TGV2NXB5SjVwYXc1NXFFNWE2SjZLT2Q1cXFVNXFHSTc3eU01WSt2NllHNDVwT0g1TGlMNkx5SjVweUE1cGF3NWE2SjZLT2Q1cXFVNXFHSTc3eU02
YnVlNllHNDU2SzY1YTZhNllDeTVZV2w2WUdLNW9peUxDd3NDbkYxYVhSZloyRnRaVjkwYVhSc1pTenBnSURsaDdybXVMam1pSThzNllDQTVZZTY2WUdLNW9p
eUxDd3NDbkYxYVhSZloyRnRaVjlqYjI1MFpXNTBMT2FZcitXUXB1ZWhydWl1cE9pbWdlbUFnT1dIdXVhNHVPYUlqKys4bnl6bW1LL2xrS2Jub3Jyb3FvM29w
b0hwZ0lEbGg3cnBnWXJtaUxMdnZKOHNMQ3dLY1hWcGRGOW5ZVzFsWDNabGNuTnBiMjVmYm05MFgyMWhkR05vTENMbXVMam1pSS9sdlpQbGlZM25pWWptbkt6
bHBJVGt1bzdudTdUbWlxVGt1SzBzSU9lb2plV1FqdW1IamVpdmxTNGlMT21CaXVhSXN1ZWJydVdKamVlSmlPYWNyT2F0bytXY3FPZTJyZWl0dCtTNHJlKzhq
T2lyaStlb2plVytqT1dHamVpcHB1T0FnaXdzTEFwbGNuSnZjbDl6WlhKMlpYSmZNVEF3TVRJczVhNmk1b2kzNTZ1djZLKzM1ckdDNVkrQzVwV3c1TGlONVl5
NTZZV05MT1d1b3VhSXR1ZXJyK2lyaStheGd1V1BnK2FWdU9TNGplV011ZW1GalN3c0xBcGxjbkp2Y2w5elpYSjJaWEpmTVRBd01UTXM1cHlxNW9tKzVZaXc2
SyszNXJHQ1EyUnU1TCtoNW9HdkxPYWNxdWFKdnVXSXNPaXJpK2F4Z2tOa2J1aW9pdWFCcnl3c0xBcGxjbkp2Y2w5elpYSjJaWEpmTVRBd01UUXM1cHlxNW9t
KzVZaXc2SyszNXJHQzZZQ2E1cHlONWFTbjVZeTY1TCtoNW9HdkxPYWNxdWFKdnVXSXNPaXJpK2F4Z3VtQW11YWNqZVdrcCtXTmdPaW9pdWFCcnl3c0xBcGxj
bkp2Y2w5elpYSjJaWEpmTVRBd01UVXM1cHlxNW9tKzVZaXc2SyszNXJHQzVwNkU1YnU2U205aTU0bUk1cHlzNUwraDVvR3ZMT2FjcXVhSnZ1V0lzT2lyaSth
eGd1YW5pK1c3dWtwdll1ZUppT2Fjck9pemgraW9paXdzTEFwbGNuSnZjbDl6WlhKMlpYSmZNVEF3TVRZczVweXE1b20rNVlpdzZLKzM1ckdDNWE2SjZLT0Y1
WXlGNTRtSTVweXM1TCtoNW9HdkxPYWNxdWFKdnVXSXNPaXJpK2F4Z3VXdWllaWpuZVdNaGVlSmlPYWNyT2l6aCtpb2lpd3NMQXBsY25KdmNsOXpaWEoyWlhK
Zk1UQXdNVGNzNXB5cTVvbSs1WWl3NksrMzVyR0M1NE90NXB1MDU0bUk1cHlzNUwraDVvR3ZMT2FjcXVhSnZ1V0lzT2lyaStheGd1ZUdzZWFidE9lSmlPYWNy
T2l6aCtpb2lpd3NMQXB3WVdOcllXZGxYMjVsWldSZmRYQmtZWFJsWDNCakxPV3VvdWFJdCtlcnIrZUppT2Fjck9tY2dPYWJ0T2FXc08rOGpPaXZ0K1dKamVX
K2dPV1FyK1dLcU9XWnFPV3VqT2FJa09hYnRPYVdzQ3pubEtqbWlMYm5xNi9uaVlqbW5LenBuSURtbTdUbWxyRHZ2SXpvcTR2bGlZM2x2b0RsbFovbGk1WGxt
YWpscm96bWlKRG1tN1RtbHJBc0xDd0tjR0ZqYTJGblpWOXViM1JmZFhCc2IyRmtMT1d1b3VhSXQrZXJyK2FidE9hV3NPYWFndWFjcXVXUGtlVzRnKys4ak9p
dnQrYVluK1M0dE9pQWhlaUFrT1cvZytldGllVytoU3pubEtqbWlMYm5xNi9tbTdUbWxyRG1tcXZtbktybm1iemx1SVB2dkl6b3E0dm1tSi9vaDZqb2dJWG9n
SkRsdjRQbnJZbmx2b1VzTEN3S2NHRmphMkZuWlY5amJHbGxiblJmYm05MFgyeGhkR1Z6ZEN6bW80RG10WXZsaUxEbXVMam1pSS9tbTdUbWxyRHZ2SXpwbklE
b3BvSHBoNDNsa0svbXVMam1pSS9scm96bWlKRG1tN1RtbHJBczVZRzE1cmlzNVlpdzZZR0s1b2l5NXB1MDVwYXc3N3lNNlp5QTZLYUI2WWVONXBhdzVaV2Y1
WXVWNllHSzVvaXk1YTZNNW9pUTVwdTA1cGF3TEN3c0NteHZaMmx1WDJaaGFXeGxaQ3pubWJ2bHZaWGxwTEhvdEtVczU1bTc1WVdsNWFTeDVwV1hMQ3dzQ25K
bFgyeHZaMmx1TE9tSGplYVdzT2VadStXOWxTenBoNDNtbHJEbm1idmxoYVVzTEN3S2JHOW5iM1YwWDJaaGFXd3M1NW03NVllNjVhU3g2TFNsTE9lWnUrV0h1
dVdrc2VhVmx5d3NMQXB5WlhSMWNtNWZiRzluYVc0czVyaTQ1b2lQNTd1MDVvcWs1TGl0Nzd5TTVadWU1WWl3NTVtNzViMlY1NVdNNloyaUxPbUJpdWFJc3Vl
MnJlaXR0K1M0cmUrOGpPV2JudVdJc09lWnUrV0ZwZVM3aSttZG9pd3NMQXBuWVcxbFgyNWhiV1VzNkpPZDZJbXk1cGlmNVk2Zjc3eWE1cGVGNkxDakxPaVhq
ZWlKc3VhWW4rV09uKys4bXVhWGhlaXNvQ3dzTEFwaVlXTnJaM0p2ZFc1a1gyUnZkMjVzYjJGa2FXNW5MT1M0aStpOXZlUzRyZUtBcGl6a3VJdm92SW5rdUsz
aWdLYmlnS1lzTEN3S1ltRmphMmR5YjNWdVpGOWtiM2R1Ykc5aFpGOW1ZV2xzWldRczVMaUw2TDI5NWFTeDZMU2w3N3lNNksrMzZZZU41cGF3NWJDZDZLK1ZM
T1M0aStpOGllV2tzZWFWbCsrOGpPaXJpK21IamVhV3NPV1lsK2lwcGl3c0xBcGlZV05yWjNKdmRXNWtYMlJ2ZDI1c2IyRmtYM04xWTJObGMzTXM1TGlMNkwy
OTVhNk01b2lRTE9TNGkraThpZVd1ak9hSWtDd3NMQXBqYkdWaGNsOTFiblZ6WldSZllYTnpaWFJ6TE9hdG8rV2NxT2E0aGVlUWh1aTFoT2E2a0N6bXJhUGxu
S2ptdUlYbmtJYm1xcFRtb1lnc0xDd0tiV1Z5WjJsdVoxOWhjM05sZEhNczZMV0U1cnFRNVpDSTVibTI1TGl0TE9hcWxPYWhpT1dRaU9TOXRlUzRyU3dzTEFw
aGMzTmxkSE5mYldWeVoybHVaMTltWVdsc1pXUXM2TFdFNXJxUTVaQ0k1Ym0yNWFTeDZMU2xMT2FxbE9haGlPV1FpT1M5dGVXa3NlYVZseXdzTEFwMWNHUmhk
R1ZmWTI5dGNHeGxkR1ZmY21WemRHRnlkQ3psdlpQbGlZM2xyWmpsbktqbW5Lcmt1SXZvdmIzbm1vVG1tN1RtbHJEbGhvWGxycm52dkl6bXVMam1pSS9samJQ
bHNJYnBoNDNsa0s4czU1dXU1WW1ONWJDYTVweUo1cHlxNUxpTDZMeUo1NXFFNXB1MDVwYXc1WVduNWE2NTc3eU02WUdLNW9peTVZMno1YkNINlllTjVwYXc1
WldmNVl1VkxDd3NDblZ3WkdGMFpWOWpiMjF3YkdWMFpWOXlaWE4wWVhKMFgyOTBhR1Z5TE9XOWsrV0pqZVd0bU9XY3FPYWNxdVM0aStpOXZlZWFoT2FidE9h
V3NPV0doZVd1dWUrOGpPaXZ0K21IamVXUXIrYTR1T2FJanl6bm02N2xpWTNsc0pybW5Jbm1uS3JrdUl2b3ZJbm5tb1RtbTdUbWxyRGxoYWZscnJudnZJem9x
NHZwaDQzbWxyRGxsWi9saTVYcGdZcm1pTElzTEN3S2FXMXdiM0owYVc1blgyRnpjMlYwY3l6b3RZVG11cERscjd6bGhhWGt1SzBzNXFxVTVxR0k1WXl2NVlX
bDVMaXRMQ3dzQ21GemMyVjBjMTlwYlhCdmNuUnBibWRmWm1GcGJHVmtMT2kxaE9hNmtPV3Z2T1dGcGVXa3NlaTBwU3ptcXBUbW9ZamxqSy9saGFYbHBMSG1s
WmNzTEN3S1kyOXRjR0Z5WlY5aGMzTmxkSE1zNXB5czVaeXc2TFdFNXJxUTVxK1U1YSs1NUxpdExPYWNyT2FwbithcWxPYWhpT2F2bE9Xd2plUzRyU3dzTEFw
c2IyTmhiRjloYzNObGRITmZZMmhsWTJ0cGJtY3M2TFdFNXJxUTVxT0E1cCtsNUxpdExPYXFsT2FoaU9hcW91YWZwZVM0clN3c0xBcHpkV0p3WVdOcllXZGxY
MlJzWDNWcFh6RXdNREVzNW9xaTVZV0lMT2FRdHVXRmlDd3NMQXB6ZFdKd1lXTnJZV2RsWDJSc1gzVnBYekV3TURJczVhNk01cFcwTE9XdWpPYVZ0Q3dzTEFw
emRXSndZV05yWVdkbFgyUnNYM1ZwWHpFd01ETXM1THVGNUxpTDZMMjk1YnFQNTZ1ZzZMV0U1cnFRNzd5SWV6Qjk3N3lKNzd5TTVZK3Y1cHUwNXBlcDVMMlQ2
YXFNNXJpNDVvaVBMT1dEaGVTNGkraThpZVc2aitlcm9PYXFsT2FoaUNoN01IMHA3N3lNNVkrdjVwdTA1cGVwNmF1VTZhbVg2WUdLNW9peUxDd3NDbk4xWW5C
aFkydGhaMlZmWkd4ZmRXbGZNVEF3TkN6a3VJdm92YjNscm96bWxiVG90WVRtdXBEdnZJaDdNSDN2dkludnZJemxqNi9wb2JybmxZWGt2WlBwcW96bHJvem1s
YlRtdUxqbWlJL2xob1hscnJrczVMaUw2THlKNWE2TTVwVzA1cXFVNXFHSUtIc3dmU252dkl6bGo2L210WUhtbXFMcHE1VHBxWmZscm96bWxiVHBnWXJtaUxM
bGhhZmxycmtzTEN3S2MzVmljR0ZqYTJGblpWOWtiRjkxYVY4eE1EQTFMT1c2aitlcm9PUzlrK21xak9XdWpPYXZsZVdRanVTN2plbWNnT1M0aStpOXZlV3Vq
T2FWdE9pMWhPYTZrQ3psdW8vbnE2RHBxNVRwcVpmbnRaRG1uWi9sdm96a3U0M3BuSURrdUl2b3ZJbmxyb3ptbGJUbXFwVG1vWWdzTEN3S2MzVmljR0ZqYTJG
blpWOWtiRjkxYVY4eE1EQTJMT1M0aStpOXZTemt1SXZvdklrc0xDd0tjM1ZpY0dGamEyRm5aVjlrYkY5MWFWOHhNREEzTE9TNnN1ZUlzZWVhaE9hV3NPUzR0
T2lBaGUrOGpPYUNxT1czc3VXdWpPYUlrT1c2aitlcm9PUzlrK21xak8rOGpPUzRpK2k5dmVXSnFlUzltZVd1ak9hVnRPaTFoT2E2a09XUWp1V1ByK1M5aytt
cWpPV1FqdWU3cmVXR2hlV3V1U3pvcHFybWhKdm5tb1RtbHJEb2g2am9nSVh2dkl6bWdxamx0N0xscm96bWlKRGx1by9ucTZEcHE1VHBxWmZ2dkl6a3VJdm92
SW5saWFucHBKamxyb3ptbGJUbXFwVG1vWWpsdm96bGo2L3BxNVRwcVpmbHZvem51b3psaGFmbHJya3NMQ3dLYzNWaWNHRmphMkZuWlY5a2JGOTFhVjh4TURB
NExPUzRpK2k5dmVXSnFlUzltZVd1ak9hVnRPaTFoT2E2a08rOGlIc3dmZSs4aVN6a3VJdm92SW5saWFucHBKamxyb3ptbGJUbXFwVG1vWWdvZXpCOUtTd3NM
QXB6ZFdKd1lXTnJZV2RsWDJSc1gzVnBYekV3TURrczVicVA1NnVnNkxXRTVycVE1YmV5NUxpTDZMMjk3N3lNNVkrdjU2dUw1WTJ6NUwyVDZhcU01cmk0NW9p
UDVicVA1NnVnNVlhRjVhNjVMT1c2aitlcm9PYXFsT2FoaU9XM3N1UzRpK2k4aWUrOGpPV1ByK2VyaStXTnMrbXJsT21wbCttQml1YUlzdVc2aitlcm9PV0Zw
K1d1dVN3c0xBcHpkV0p3WVdOcllXZGxYMlJzWDNWcFh6RXdNVEFzNW9xaTVZV0k1TDJUNmFxTUxPYVF0dVdGaU9tcmxPbXBseXdzTEFwemRXSndZV05yWVdk
bFgyUnNYM1ZwWHpFd01URXM1TGlMNkwyOTVaQ081WSt2NTV1MDVvNmw2TCtiNktHTTVhNk01cFcwNXJpNDVvaVBMT1M0aStpOGllVytqT1dQcitlYnRPYU9w
ZW1Bc3VpaGpPV3VqT2FWdE9tQml1YUlzaXdzTEFwa2IzZHViRzloWkY5MWFWOHhNREF4TE9hVXIrYU1nZVdRanVXUHNPUzRpK2k5dlN6bWxLL21qN1RvZzR6
bW1hL2t1SXZvdklrc0xDd0tjSEpsYkc5aFpGOWpZV3hqZFd4aGRHbHVaeXdvNkxXRTVycVE2SzZoNTY2WDVMaXRLU3dvNXFxVTVxR0k2S2lJNTY2WDVMaXRL
U3dzTEFwemRXSndZV05yWVdkbFgyTmhiR04xYkdGMGFXNW5MT2l1b2VldWwrUzRyZUtBcGl6b3FJam5ycGZrdUszaWdLYmlnS1lzTEN3S2NISmxiRzloWkY5
dWIzUnBZMlVzNlp5QTZLYUI1TGlMNkwyOWV6Qjk1NXFFNXJpNDVvaVA2TFdFNXJxUTc3eU02YUtFNUxpTDZMMjk1cHlmNlplMDVwZWc1ck9WNkwrYjZLR001
cmk0NW9pUExPbWNnT2ltZ2VTNGkraThpWHN3ZmVlYWhPbUJpdWFJc3VhcWxPYWhpTys4ak9tZ2tPV0ZpT1M0aStpOGllYWNuK21XaytlRW9lYXpsZW1Bc3Vp
aGpPbUJpdWFJc2l3c0xBcHdjbVZzYjJGa1gyWnBibWx6YUN6cG9vVGt1SXZvdmIzbHQ3TGxyb3ptaUpBczZhQ1E1WVdJNUxpTDZMeUo1YmV5NWE2TTVvaVFM
Q3dzQ25OMFlYSjBYM1JwY0N6bHZJRGxwNHZtbDRYbnFJc3M2WmFMNWFlTDVwZUY1NmlMTEN3c0NtTnZiWEJwYkdsdVoxOTBhWEFzNTd5VzZLK1I1TGl0TE9l
M3FPaXRyK1M0clN3c0xBbz0iLCJhZnRlciI6Ijc3dS9hMlY1TEdOb2N5eGphSFFzWlc0c2FuQXNhM0lLWVd4bGNuUmZkR2wwYkdVczVvK1E2WWFTTE9hUGtP
bUdraXhCYkdWeWRDem9yYWJsa1lvczZySzk2ck9nQ21OdmJtWnBjbTBzNTZHdTVhNmFMT2VocnVXdW1peERiMjVtYVhKdExPZWl1dWlxalN6dG1aWHNuYmdL
WTJGdVkyVnNMT1dQbHVhMmlDemxqNWJtdG9nc1EyRnVZMlZzTE9PQ3JlT0RvK09EcytPQ3UrT0RxeXpzdDZqc2hvd0tjbVYwY25rczZZZU42SytWTE9tSGpl
aXZsU3hTWlhSeWVTemxobzNvcWFib29Zd3NJdXVMcE95TG5DRHNpNXpyajRRaUNuRjFhWFFzNllDQTVZZTZMT21BZ09XSHVpeFJkV2wwTE9lMWd1UzZodU9C
bWVPQ2l5enNvb1hybzR3S2FXNXBkR2xoYkdsNmFXNW5MT2F0bytXY3FPV0luZVduaStXTWx1S0FwaXptcmFQbG5LamxpSjNscDR2bGpKYmlnS1lzU1c1cGRH
bGhiR2w2YVc1bjRvQ21MT1dJbmVhY24rV01sdVM0cmVLQXBpd2k3TFNJNnJpdzdabVVJT3lra2VLQXBpSUtjbVZ4ZFdWemRHbHVaMTlwYm1adkxPYXRvK1dj
cU9pT3QrV1BsdWVKaU9hY3JPUy9vZWFCcitLQXBpem1yYVBsbktqb2pyZmxqNWJuaVlqbW5Lemt2NkhtZ2EvaWdLWXNJbEpsY1hWbGMzUnBibWNnYVc1bWIr
S0FwaUlzNW9PRjVhQ3g0NEtTNVkrVzViNlg0NEdYNDRHbTQ0R0U0NEcrNDRHWjRvQ21MQ0xzb0pYcnM3VHJwYndnNnJDQTdLQzQ3SmlrNjRxVUlPeWtrZUtB
cGlJS1kyaGxZMnRwYm1kZmRYQmtZWFJsTE9hdG8rV2NxT2FqZ09hZnBlYWJ0T2FXc09LQXBpem1yYVBsbktqbW80RG1uNlhtbTdUbWxyRGlnS1lzSWtOb1pX
TnJhVzVuSUhWd1pHRjBaZUtBcGlJczVwdTA1cGF3NDRLUzU2SzY2S3FONUxpdDRvQ21MQ0xzbDRYcmpiRHNuYlR0aXJnZzdabVY3SjI0SU95a2tlS0FwaUlL
Wkc5M2JteHZZV1JmYVc1bWJ5enBuSURvcG9IbW03VG1sckI3TUgzbm1vVG11TGptaUkvb3RZVG11cEFzNlp5QTZLYUI1cHUwNXBhd2V6Qjk1NXFFNXJpNDVv
aVA2TFdFNXJxUUxDSjdNSDBnYjJZZ1oyRnRaU0J5WlhOdmRYSmpaWE1nYm1WbFpDQjBieUJpWlNCa2IzZHViRzloWkdWa0lpeDdNSDNqZ2E3amdyTGpnN3pq
ZzZEamc2cmpncjNqZzd6amdybmpncExqZzREamdxYmpnN1BqZzYzamc3empnNG5qZ1puamdvdmx2NFhvcG9IamdZempnWUxqZ29yamdiN2pnWmtzSW5zd2Zl
eWRtQ0Rxc296c25vUWc2NmFzN0lhTTdJcWs2Nlc4SU91THBPeWF0T3Vobk91VG5PMlZ0T3lWdkNEdGxhbnJpNGpyaTZRaUNtUnZkMjVzYjJGa1gybHVabTlm
WkdWMFlXbHNMSHN3ZmVXZnV1ZWhnT2kxaE9hNmtDdDdNWDNwb3AzbHBKYm90WVRtdXBBc2V6Qjk1Wis2NTZHQTZMV0U1cnFRSzNzeGZlbWluZVdrbHVpMWhP
YTZrQ3dpZXpCOUlHOW1JRUpoYzJsaklDc2dlekY5SUc5bUlFRmtaR2wwYVc5dVlXd2lMSHN3ZmVXZnV1ZWtqaXQ3TVgzb3Y3M2xpcUFzSW5zd2ZTRHF1TERz
dElnZ0lDc2dlekY5SU95MmxPcXdnQ0lLWkc5M2JteHZZV1JwYm1jczVwdTA1cGF3NUxpdExPYWJ0T2FXc09TNHJTeEViM2R1Ykc5aFpHbHVaeXpqZzREamdx
YmpnN1BqZzYzamc3empnNG5rdUswc0l1dUxwT3lhdE91aG5PdVRuQ0RzcEpFaUNtUnZkMjVzYjJGa1gzTndaV1ZrWDNOc2IzY3M1TGlMNkwyOTZMK0g1b1dp
Nzd5TTZLKzM1cU9BNXArbDU3MlI1N3VjTE9TNGkraTl2ZWkvaCthRm91KzhqT2l2dCthamdPYWZwZWU5a2VlN25Dd2lSRzkzYm14dllXUWdkRzl2SUhOc2Iz
Y3NJSEJzWldGelpTQmphR1ZqYXlCMGFHVWdibVYwZDI5eWF5SXM0NE9BNDRLbTQ0T3o0NE90NDRPODQ0T0o0NEdNNllHRjQ0R1o0NEdPNDRHKzQ0R1o0NENC
NDRPTjQ0T0Q0NE9JNDRPdjQ0Tzg0NEt2NDRLUzU2SzY2S3FONDRHWDQ0R200NEdQNDRHZzQ0R1Y0NEdFTENMcmk2VHNtclRyb1p6cms1enFzSUFnNjRTSTY2
eTBJT3VLa091bXZldUxpT3VMcEN3ZzY0U2s3WXE0N0p1TTdZR3M2Nlc4SU8yWmxleWR1TzJWdE95anZPeUV1T3lhbENJS1pXNTBaWEpwYm1kZloyRnRaU3pt
bTdUbWxyRGxyb3ptcjVYdnZJemxqYlBsc0lib3Y1dmxoYVhtdUxqbWlJL3Z2SUVzNXB1MDVwYXc1YTZNNXErVjc3eU01WTJ6NWJDRzZMK2I1WVdsNXJpNDVv
aVA3N3lCTENKVmNHUmhkR1VnWTI5dGNHeGxkR1V1SUVWdWRHVnlhVzVuSVNJczVwdTA1cGF3NWE2TTVMcUc0NENCNVlXbDQ0S0s0NEcrNDRHWjc3eUJMQ0xz
bDRYcmpiRHNuYlR0aXJnZzdKbUU2Nk9NTENEc3A0VHNub1h0bGFucmk0anJpNlFoSWdwamIyNXVaV04wWDJaaGFXeGxaQ3pudlpIbnU1em92NTdtanFYbHBM
SG90S1VzNTcyUjU3dWM2TCtlNW82bDVhU3g2TFNsTENKT1pYUjNiM0pySUdOdmJtNWxZM1JwYjI0Z1ptRnBiR1ZrSWl6amc0M2pnNFBqZzRqamc2L2pnN3pq
Z3EvbWpxWG50cHJqZ2F2bHBMSG1sWmZqZ1pmamdiN2pnWmZqZ1o4c0l1dUVwTzJLdU95YmpPMkJyQ0RzbDdEcXNyRHNsNUFnN0l1azdZeW83WmFJN0lxMTY0
dUk2NHVrSWdwbGNuSnZjbDh0TVN6bnZaSG51NXpvdjU3bWpxWGx2SUxsdUxqdnZJem9yN2Zsc0ozb3I1WG92NTdtanFYbnZaSG51NXp2dkl6bHViYnBoNDNs
a0svbXVMam1pSS92dklFczU3MlI1N3VjNkwrZTVvNmw1YnlDNWJpNDc3eU02SyszNWJDZDZLK1Y2TCtlNW82bDU3MlI1N3VjNzd5TTVibTI2WWVONVpDdjVy
aTQ1b2lQNzd5QkxDSk9aWFIzYjNKcklHTnZibTVsWTNScGIyNGdaWEp5YjNJc0lIQnNaV0Z6WlNCMGNua2dkRzhnWTI5dWJtVmpkQ0IwYnlCMGFHVWdibVYw
ZDI5eWF5QmhibVFnY21WemRHRnlkQ0IwYUdVZ1oyRnRaU0VpTE9PRGplT0RnK09EaU9PRHIrT0R2T09DcithT3BlZTJtdU9DcU9PRHFlT0R2T09BZ2VPRGpl
T0RnK09EaU9PRHIrT0R2T09DcitPQnErYU9wZWUybXVPQmwrT0FnZU9Dc3VPRHZPT0RvT09Da3VXR2plaTF0K1dMbGVPQmwrT0JwdU9CaitPQm9PT0JsZU9C
aE8rOGdTd2k2NFNrN1lxNDdKdU03WUdzSU95WHNPcXlzQ0RzbUtUcnBaZ3NJT3VFcE8yS3VPeWJqTzJCck95WGtDRHNsN0Rxc3JEdGxaanFzNkFnNnJLTTdK
NkU3SjJFSU91THBPeUxuQ0RzaTV6c25wSHRsWmpzaTYzc2k1enNtS1FoSWdwbGNuSnZjbDh4TURBd0xPYUlrT1dLbnl6bWlKRGxpcDhzVTNWalkyVnpjeXpt
aUpEbGlwOHM3SVN4NnJPMUNtVnljbTl5WHpFd01ERXM1N083NTd1ZjZaU1o2Syt2TE9lenUrZTduK21VbWVpdnJ5d2lVM2x6ZEdWdElHVnljbTl5SWl6amdy
Zmpncm5qZzRiamc2RGpncWpqZzZuamc3d3NJdXlMbk95S3BPMkZuQ0RzbUtUcnBaZ2lDbVZ5Y205eVh6RXdNRElzU1ZEb29xdm5wb0htcmFJc1NWRG9vcXZu
cG9IbXJhSXNJa2xRSUdseklHSmhibTVsWkNJc1NWRGpnWXpucG9IbXJhTGpnWlhqZ296amdhYmpnWVRqZ2I3amdaa3NJa2xRNnJDQUlPcTRpT3luZ091UW1P
eVhpT3lLdGV1TGlPdUxwQ0lLWlhKeWIzSmZNVEF3TXl6bW5JM2xpcUhsbWFqbnU3VG1pcVRrdUswczVweU41WXFoNVptbzU3dTA1b3FrNUxpdExDSlRaWEoy
WlhJZ2FYTWdkVzVrWlhJZ2JXRnBiblJsYm1GdVkyVWlMT09DdGVPRHZPT0RrT09Edk9PQnIrT0RvZU9EcytPRGh1T0RpdU9EcytPQ3VlUzRyZU9CcCtPQm1T
d2k3SVNjNjdLRTZyQ0FJT3ljb095bmdDRHF0SURycHF3ZzdLU1I3SjZGNjR1STY0dWtJZ3BsY25KdmNsOHhNREEwTE9ldHZ1V1FqZW1VbWVpdnJ5em5yYjds
a0kzcGxKbm9yNjhzSWxOcFoyNWhkSFZ5WlNCbGNuSnZjaUlzNTcyeTVaQ040NEtvNDRPcDQ0TzhMQ0xzaEp6cnFvVWc3SmlrNjZXWUlncGxjbkp2Y2w4eE1E
QTFMT1dQZ3VhVnNPbVVtZWl2cnl6bGo0TG1sYkRwbEpub3I2OHNJbEJoY21GdFpYUmxjaUJsY25KdmNpSXM0NE9SNDRPcDQ0T2g0NE84NDRLLzQ0Tzg0NEtv
NDRPcDQ0TzhMQ0xycDZUcXNKd2c2N09BN0lpWUlPeVlwT3VsbUNJS2RYQmtZWFJsWDJGc1pYSjBYMjFsYzNOaFoyVXM2WnlBNkthQjVMaUw2TDI5NkxXRTVy
cVE1WkNPNW9tTjVZK3Y1THVsNkwrYjVZV2xMT21jZ09pbWdlUzRpK2k5dmVpMWhPYTZrT1dRanVhSmplV1ByK1M3cGVpL20rV0ZwU3dpV1c5MUlHNWxaV1Fn
ZEc4Z1pHOTNibXh2WVdRZ2RHaGxJSEpsYzI5MWNtTmxJR0psWm05eVpTQjViM1VnWTJGdUlHRmpZMlZ6Y3lCcGRDSXM0NEtpNDRLdjQ0Szc0NEs1NDRHWjQ0
S0w1WW1ONDRHcjQ0T3E0NEs5NDRPODQ0SzU0NEtTNDRPQTQ0S200NE96NDRPdDQ0Tzg0NE9KNDRHWjQ0S0w1YitGNkthQjQ0R000NEdDNDRLSzQ0Rys0NEda
TENMcnBxenNob3pzaXFUc2w1QWc3SldoN0lTNDdJcWs3WldZNjZDazY2bTBJT3Vvdk95Z2dDRHJwcXpzaG96c2lxVHJwYndnNjR1azdKcTA2NkdjNjVPYzda
VzA3Slc4SU8yVnFldUxpT3VMcENJS2RYQmtZWFJsWDJGc1pYSjBYM1J2WjJkc1pWOW1kV3hzWDNScGRHeGxMQ0xscm96bWxiVG90WVRtdXBBZ0tIc3dmU2tp
TENMbHJvem1sYlRvdFlUbXVwQWdLSHN3ZlNraUxDSkdkV3hzSUZKbGMyOTFjbU5sY3lBb2V6QjlLU0lzSXVXdWpPV0ZxT09CcXVPRHF1T0N2ZU9Edk9PQ3VT
QW9lekI5S1NJc0l1eWdoT3l5dENEcnBxenNob3pzaXFRZ0tIc3dmU2tpQ25Wd1pHRjBaVjloYkdWeWRGOTBiMmRuYkdWZlpuVnNiRjl6ZFdKMGFYUnNaU3ps
aklYbGtLdm11TGptaUkvbm1vVGxoYWpwZzZqb3RZVG11cEFzNVl5RjVaQ3I1cmk0NW9pUDU1cUU1WVdvNllPbzZMV0U1cnFRTENKSmJtTnNkV1JsY3lCaGJH
d2dkR2hsSUdGemMyVjBjeUJ2WmlCMGFHVWdaMkZ0WlNJczQ0S3k0NE84NDRPZzQ0R3U0NEdaNDRHNTQ0R200NEd1NDRLaTQ0Szc0NE9ENDRPSTQ0R001WkNy
NDRHKzQ0S000NEdtNDRHRTQ0Rys0NEdaTENMcXNvenNub1RzblpnZzY2cW82NU9nSU95ZWtPeUNzT3lkaENEdGo2enRsYWp0bGFucmk0anJpNlF1SWdwMWNH
UmhkR1ZmWVd4bGNuUmZkRzluWjJ4bFgySmhjMmxqWDNScGRHeGxMQ0xsbjdybm9ZRG90WVRtdXBBZ0tIc3dmU2tpTENMbG43cm5vWURvdFlUbXVwQWdLSHN3
ZlNraUxDSkNZWE5wWXlCU1pYTnZkWEpqWlhNZ0tIc3dmU2tpTENMamc1bmpnN3pqZ3Juamc2cmpncjNqZzd6amdya2dLSHN3ZlNraUxDTHNucXpyaTZnZzdK
NlE2Nk9NSUNoN01IMHBJZ3AxY0dSaGRHVmZZV3hsY25SZmRHOW5aMnhsWDJKaGMybGpYM04xWW5ScGRHeGxMT1M3aGVXTWhlV1FxK2E0dU9hSWoraS9rT2lo
ak9lYWhPV2Z1dWVoZ09pMWhPYTZrTys4ak9XRnR1V3VnK2kxaE9hNmtPV1ByK1djcU9hNHVPYUlqK2l1dnVlOXJ1UzRyZVM0aStpOXZTemt1NFhsaklYbGtL
dm11TGptaUkvb3Y1RG9vWXpubW9UbG43cm5vWURvdFlUbXVwRHZ2SXpsaGJibHJvUG90WVRtdXBEbGo2L2xuS2ptdUxqbWlJL29ycjdudmE3a3VLM2t1SXZv
dmIwc0lrOXViSGtnWW1GemFXTWdjbVZ6YjNWeVkyVnpJR1p2Y2lCbllXMWxJR0Z5WlNCcGJtTnNkV1JsWkM0Z1QzUm9aWElnY21WemIzVnlZMlZ6SUdOaGJp
QmlaU0JrYjNkdWJHOWhaR1ZrSUdsdUlHZGhiV1VnYzJWMGRHbHVaM011SWl6amdyTGpnN3pqZzZEbHJwL29vWXpqZ2E3amdaL2pnb0hqZ2E3bG43cm1uS3pq
ZzZyamdyM2pnN3pqZ3JuamdhN2pnYi9qZ1l6bGtLdmpnYjdqZ296amdJSGpnWjNqZ2E3a3U1YmpnYTdqZzZyamdyM2pnN3pqZ3JuamdhL2pnckxqZzd6amc2
RG9xSzNscnByamdZdmpnb25qZzREamdxYmpnN1BqZzYzamc3empnNG5qZ2FmamdZM2pnYjdqZ1prc0l1cXlqT3llaENEc2k2VHRsb25zbllRZzdKeUU3Wldj
SU9xNHNPdXp1Q0RycHF6c2hvenNpcVRycDR3ZzdZK3M3WldvTENEcXVMRHRnNEFnNjZhczdJYU03SXFrNjRxVUlPcXlqT3llaENEc2hLVHNvSlhzbDVEc2hK
d2c2NHVrN0pxMDY2R2M2NU9jSU9xd2dPdUtwU0lLYm1WMGQyOXlhMTloYkdWeWRGOTBhWEJ6TENMbHZaUGxpWTNrdUxycG5aNVhTVVpKNTQ2djVhS0Q3N3lN
NXBpdjVaQ201TDIvNTVTbzVyV0I2WWVQNUxpTDZMMjlQeUFpTE9lYnJ1V0pqZVM0dXVtZG5sZEpSa25uanEvbG9vUHZ2SXptbUsvbGtLYmt2Yi9ubEtqbXRZ
SHBoNC9rdUl2b3ZiMC9MQ0pVYUdseklHbHpJR0VnYm05dUxWZEpSa2tnWlc1MmFYSnZibTFsYm5RdUlFUnZJSGx2ZFNCM1lXNTBJSFJ2SUhWelpTQjBjbUZt
Wm1saklIUnZJR1J2ZDI1c2IyRmtQeUlzSXVPQmsrT0NqT09CcittZG5pQlhTVVpKSU9lU3NPV2lnK09CcCtPQm1lT0FndU9EZ09PQ3B1T0RzK09EcmVPRHZP
T0RpZU9CcStPRGlPT0RxZU9EbGVPQ28rT0RnK09DcitPQ2t1Uzl2K2VVcU9PQmwrT0J2dU9CbWVPQml6OGlMQ0pYU1VaSjZyQ0FJT3lWaE91TGpDRHRtWmpx
c3Izc2w1RHNoSndnNjR1azdKcTA2NkdjNjVPYzY2VzhJT3ljaE8yVnRDRHRpcmpybnBqdGxMM3NuWVFnN0lLczdKcXA3WldZN0l1YzZyS2c3SXExNjR1STZy
bU1QeUlLY21WemIzVnlZMlZmZG1WeWFXWjVhVzVuWDNScGNITXNJaURtcmFQbG5Lam1vS0hwcW96b3RZVG11cERpZ0tZaUxPYXRvK1djcU9hZ29lbXFqT2kx
aE9hNmtPS0FwaXdpVm1WeWFXWjVhVzVuSUhKbGMyOTFjbU5sY3k0dUxpSXM0NE9xNDRLOTQ0Tzg0NEs1NDRLUzU2SzY2S3FONDRHWDQ0R200NEdFNDRHKzQ0
R1o0b0NtTENMcnBxenNob3pzaXFRZzdabVY3SjI0SU95a2tlS0FwaUlLY21WemIzVnlZMlZmYkc5aFpHbHVaMTkwYVhCekxPYXRvK1djcU9XS29PaTl2ZVM0
cmVLQXBpem1yYVBsbktqbGlxRG92YjNrdUszaWdLWXNURzloWkdsdVp5NHVMaXpvcXEzamdiL292cnpqZ2Iva3VLM2lnS1lzSXV1aG5PdVRuQ0RzcEpIaWdL
WWlDblJwY0Y5MGFYUnNaU3ptajVEbnBMb3M1bytRNTZTNkxDempnNUxqZzdQamc0Z3NDbTl1YkhsZmJHRjFibU5vWlhJczZLKzM1TDIvNTVTbzVaQ3Y1WXFv
NVptbzVaQ3Y1WXFvNXJpNDVvaVBMT2l2dCtTOXYrZVVxT1dRcitXS3FPV1pxT1dRcitXS3FPYTR1T2FJanl3czQ0S3k0NE84NDRPZzQ0S1M2TFczNVl1VjQ0
R1o0NEtMNDRHcjQ0R3Y0NE9wNDRPejQ0T0I0NE9qNDRPODQ0S1M0NEdVNVlpcDU1U280NEdQNDRHZzQ0R1Y0NEdFTEFwdmRYUmZiMlpmWkdsemExOXpjR0Zq
TE9XOWsrV0pqZVdKcWVTOW1lZWpnZWVibU9Xa3ArV3dqK1M0amVpMnN5emx2WlBsaVkzbGlhbmt2Wm5ubzRIbm01amxwS2Zsc0kva3VJM290ck1zTE9PRGgr
T0NvK09DdWVPQ3IrT0JydWVwdXVPQmplV3V1ZW1IaitTNGplaTJzeXdLYjNWMFgyOW1YMlJwYzJ0ZmMzQmhZMTl6YVhwbExPaXV2dVdraCtXR2hlV3RtT1M0
amVpMnMrKzhqT21jZ09pbWdYc3dmZWVwdXVtWHRPYUpqZVdQcitlN3ArZTdyZVM0aStpOXZlT0FnaXpvcnI3bHBJZmxob1hsclpqa3VJM290clB2dkl6cG5J
RG9wb0Y3TUgzbnFicnBsN1RtaVkzbGo2L251NmZudTYza3VJdm92YjNqZ0lJc0xPUzdpdVdibnVPQnJ1YWJ0T2FXc08rOGlIc3dmZSs4aWVPQnErVy9oZWlt
Z2VPQnF1T0NzdU9Edk9PRG9PT0RoK09Edk9PQ3YrT0NrdU9DcE9PRHMrT0N1ZU9EaU9PRHZPT0RxK09CbWVPQ2krT0JuK09DZ2VPQnJ1ZXB1dU9CamVXdXVl
bUhqK09Cak9TNGplaTJzK09CbCtPQnB1T0JoT09CdnVPQm1Td0taRzkzYm14dllXUmZabUZwYkN6bW80RG10WXZsaUxEbHJaamxuS2prdUl2b3ZiM2xwTEhv
dEtYbm1vVG1sb2ZrdTdZczVxT0E1cldMNVlpdzVhMlk1WnlvNUxpTDZMMjk1YVN4NkxTbDU1cUU1cGFINUx1MkxDemt1SURwZzZqamdhN2pnNVhqZ3FIamdx
VGpnNnZqZ2E3amc0RGpncWJqZzdQamc2M2pnN3pqZzRuamdhdmxwTEhtbFpmamdaZmpnYjdqZ1pmamdaOHNDbWx1YVhSZlptRnBiQ3psaUozbHA0dmxqSmJs
cExIb3RLVXM1WWlkNWFlTDVZeVc1YVN4NkxTbExDemxpSjNtbkovbGpKYmpnYXZscExIbWxaZmpnWmZqZ2I3amdaZmpnWjhzQ21kbGRGOXNiMk5oYkY5c2FY
TjBYMlpoYVd3czZJNjM1WStXNXB5czVaeXc2TFdFNXJxUTVyaUY1WTJWNWFTeDZMU2xMT2lPdCtXUGx1YWNyT1djc09pMWhPYTZrT2E0aGVXTmxlV2tzZWkw
cFN3czQ0T3Q0NE84NDRLcjQ0T3I0NEd1NDRPcTQ0Szk0NE84NDRLNTVvT0Y1YUN4NDRLUzVZK1c1YjZYNDRHbjQ0R040NEcrNDRHYjQ0S1Q0NEduNDRHWDQ0
R2ZMQXBuWlhSZmJHOWpZV3hmZG1WeWMybHZibDltWVdsc0xPaU90K1dQbHVhY3JPV2NzT2VKaU9hY3JPV1B0K1drc2VpMHBTem9qcmZsajVibW5LemxuTERu
aVlqbW5LemxqN2ZscExIb3RLVXNMT09EcmVPRHZPT0NxK09EcStPQnJ1T0RrT09Edk9PQ3VPT0RwK09EcythRGhlV2dzZU9Da3VXUGx1VytsK09CcCtPQmpl
T0J2dU9CbStPQ2srT0JwK09CbCtPQm55d0tiM0JsYmw5emRHRnlkRjkyYVdWM1gyWmhhV3dzNVpDdjVZcW81NVdNNloyaTVvbVQ1YnlBNWFTeDZMU2xMT1dR
citXS3FPZVZqT21kb3VhSmsrVzhnT1drc2VpMHBTd3M2TFczNVl1VjU1Uzc2WjJpNDRHdTZLcXQ0NEcvNkw2ODQ0Ry80NEdyNWFTeDVwV1g0NEdYNDRHKzQ0
R1g0NEdmTEFwdmNHVnVYMmh2ZEhWd1pHRjBaVjkyYVdWM1gyWmhhV3dzNTRPdDVwdTA1NVdNNloyaTVvbVQ1YnlBNWFTeDZMU2xMT2VEcmVhYnRPZVZqT21k
b3VhSmsrVzhnT1drc2VpMHBTd3M0NEtpNDRPRDQ0T1g0NE9INDRPODQ0T0k1NVM3NloyaTQ0R3U2S3F0NDRHLzZMNjg0NEcvNDRHcjVhU3g1cFdYNDRHWDQ0
Rys0NEdYNDRHZkxBcG5aWFJmYzJWeWRtVnlYMnhwYzNSZlptRnBiQ3pvanJmbGo1Ym1uSURtbHJEb3RZVG11cERtdUlYbGpaWGxwTEhvdEtVczZJNjM1WStX
NXB5QTVwYXc2TFdFNXJxUTVyaUY1WTJWNWFTeDZMU2xMQ3ptbklEbWxyRGpnYTdqZzZyamdyM2pnN3pqZ3JubWc0WGxvTEhqZ3BMbGo1Ymx2cGZqZ2FmamdZ
M2pnYjdqZ1p2amdwUGpnYWZqZ1pmamdaOHNDbWRsZEY5elpYSjJaWEpmZG1WeWMybHZibDltWVdsc0xPaU90K1dQbHVhY2dPYVdzT2VKaU9hY3JPV2tzZWkw
cFN6b2pyZmxqNWJtbklEbWxyRG5pWWptbkt6bHBMSG90S1VzTE9hY2dPYVdzT09CcnVPRGtPT0R2T09DdU9PRHArT0RzK2FEaGVXZ3NlT0NrdVdQbHVXK2wr
T0JwK09CamVPQnZ1T0JtK09DaytPQnArT0JsK09Cbnl3S2JHOWhaRjlzYjJGa1pYSmZaR3hzWDJaaGFXd3M1WXFnNkwyOTVMdWo1NkNCNWFTeDZMU2xMT1dL
b09pOXZlUzdvK2VnZ2VXa3NlaTBwU3dzNDRLejQ0Tzg0NE9KNDRHdTZLcXQ0NEcvNkw2ODQ0Ry80NEdyNWFTeDVwV1g0NEdYNDRHKzQ0R1g0NEdmTEFwelpH
dGZhVzVwZEY5bVlXbHNMRk5FUytXSW5lV25pK1dNbHVXa3NlaTBwZSs4ak9hWXIrV1FwdW1IamVhV3NPV0luZVduaStXTWxpeFRSRXZsaUozbHA0dmxqSmJs
cExIb3RLWHZ2SXptbUsvbGtLYnBoNDNtbHJEbGlKM2xwNHZsakpZc0xDd0tjR1Z5Wm05eWJXRnVZMlZmWTJobFkydGZabUZwYkN6bWo1RG5wTHJ2dkpybW80
RG10WXZsaUxEbHZaUGxpWTNvcnI3bHBJZmt2WTdrdW83bW5JRGt2WTdwaFkzbnZhN29wb0htc1lMdnZJem11TGptaUkvb3Y0Zm5xSXZrdUszbGo2L29nNzNr
dkpybGg3cm5qckRsamFIcG9iL2pnSUhwbDZycGdJRG5yWW5tZzRYbGhyVXM1bytRNTZTNjc3eWE1cU9BNXJXTDVZaXc1YjJUNVltTjZLNis1YVNINUwyTzVM
cU81cHlBNUwyTzZZV041NzJ1NkthQjVyR0M3N3lNNXJpNDVvaVA2TCtINTZpTDVMaXQ1WSt2NklPOTVMeWE1WWU2NTQ2dzVZMmg2YUcvNDRDQjZaZXE2WUNB
NTYySjVvT0Y1WWExTEN3c0NtVnljbTl5WDNObGNuWmxjbDh4TE9hSnAraWhqT21VbWVpdnJ5em1pYWZvb1l6cGxKbm9yNjhzTEN3S1pYSnliM0pmYzJWeWRt
VnlYekV3TURBd0xPYWNqZVdLb2VXWnFPZTVnZVcvbVN6bW5JM2xpcUhsbWFqbnVZSGx2NWtzTEN3S1pYSnliM0pmYzJWeWRtVnlYekV3TURBeExPZUppT2Fj
ck9TL29lYUJyK1M0amVXdG1PV2NxQ3puaVlqbW5Lemt2NkhtZ2Eva3VJM2xyWmpsbktnc0xDd0taWEp5YjNKZmMyVnlkbVZ5WHpFd01EQXlMT2F5b2VhY2ll
YUp2dVdJc09hNG9PbUJrK1Mvb2VhQnJ5em1zcUhtbklubWliN2xpTERtdUtEcGdaUGt2NkhtZ2E4c0xDd0taWEp5YjNKZmMyVnlkbVZ5WHpFd01EQXpMT2F5
b2VhY2llYUp2dVdJc09hNHVPYUlqMGxFTE9heW9lYWNpZWFKdnVXSXNPYTR1T2FJajBsRUxDd3NDbVZ5Y205eVgzTmxjblpsY2w4eE1EQXdOQ3ptbkkzbGlx
SGxtYWpwbEpub3I2OHM1cHlONVlxaDVabW82WlNaNksrdkxDd3NDbVZ5Y205eVgzTmxjblpsY2w4eE1EQXdOU3hKVU9paXErV3dnZWVtZ1N4SlVPaWlxK1d3
Z2VlbWdTd3NMQXBsY25KdmNsOXpaWEoyWlhKZk1UQXdNRFlzNkxTbTVZKzM2S0tyNWJDQjU2YUJMT2kwcHVXUHQraWlxK1d3Z2VlbWdTd3NMQXBsY25KdmNs
OXpaWEoyWlhKZk1UQXdNRGNzNXB5TjVZcWg1Wm1vNUxpTjVZK3Y1NVNvTE9hY2plV0tvZVdacU9TNGplV1ByK2VVcUN3c0xBcGxjbkp2Y2w5elpYSjJaWEpm
TVRBd01EZ3M1b0tvNlp5QTZLYUI1cHUwNXBhdzVvS281NXFFNWE2aTVvaTM1NnV2NTRtSTVweXNLT2E0b09tQmsrZUppT2Fjck9TNGplV011ZW1GalNrczVv
S282WnlBNkthQjVwdTA1cGF3NW9LbzU1cUU1YTZpNW9pMzU2dXY1NG1JNXB5c0tPYTRvT21CaytlSmlPYWNyT1M0amVXTXVlbUZqU2tzTEN3S1pYSnliM0pm
YzJWeWRtVnlYekV3TURBNUxPYVh0dW1YdE9hSXMrYWdvZW1xak9XSHV1bVVtU3ptbDdicGw3VG1pTFBtb0tIcHFvemxoN3JwbEprc0xDd0taWEp5YjNKZmMy
VnlkbVZ5WHpFd01ERXdMRU5rYnVpdnQrYXhndVdQZ3VhVnNPbVVtZWl2cnl4RFpHN29yN2Ztc1lMbGo0TG1sYkRwbEpub3I2OHNMQ3dLWlhKeWIzSmZjMlZ5
ZG1WeVh6RTFNREF3TVN3aVNXNTJZV3hwWkNCVFpYTnphVzl1U1VRaUxDSkpiblpoYkdsa0lGTmxjM05wYjI1SlJDSXNMQ3dLWlhKeWIzSmZjMlZ5ZG1WeVh6
RTFNREF3TWl6bnJiN2xrSTNwbEpub3I2OHM1NjIrNVpDTjZaU1o2Syt2TEN3c0NtVnljbTl5WDNObGNuWmxjbDh4TlRBd01ETXM2SyszNXJHQzVwV3c1bzJ1
NWJ5QzViaTQ3N3lJNXBXdzVvMnU2WlNaNksrdjc3eU02SyszNXJHQzVwV3c1bzJ1NXFDODVieVA2WlNaNksrdjc3eUpMQ0xvcjdmbXNZTG1sYkRtamE3bHZJ
TGx1TGdnS09hVnNPYU5ydW1VbWVpdnIrKzhqT2l2dCtheGd1YVZzT2FOcnVhZ3ZPVzhqK21VbWVpdnJ5a2lMQ3dzQ21WeWNtOXlYM05sY25abGNsOHhOVEF3
TURRczZLKzM1ckdDNXBXdzVvMnU1YnlDNWJpNDc3eUk1b21uNktHTTVieUM1Ymk0Nzd5TTVMNkw1YWFDNXBlMjZaZTA1b2l6NUxpTjVhKzU3N3lKTENMb3I3
Zm1zWUxtbGJEbWphN2x2SUxsdUxnZ0tPYUpwK2loak9XOGd1VzR1Q3prdm92bHBvTG1sN2JwbDdUbWlMUGt1STNscjdrcElpd3NMQXBsY25KdmNsOXpaWEoy
WlhKZlpHVm1ZWFZzZEN6bW5JM2xpcUhsbWFqbmlyYm1nSUhudVlIbHY1a3M1cHlONVlxaDVabW81NHEyNW9DQjU3bUI1YitaTEN3c0NuQmhZMnRoWjJWZmJt
VmxaRjkxY0dSaGRHVXNJdW1jZ09pbWdlYWJ0T2FXc0N3ZzZLKzM1TGlMNkwyOTVweUE1cGF3NTRtSTVweXM1NXFFNWE2SjZLT0Y1WXlGNkwrYjVZV2w1cmk0
NW9pUElpenBuSURvcG9IbW03VG1sckR2dkl6b3I3Zmt1SXZvdmIzbW5JRG1sckRuaVlqbW5Lem5tb1Rscm9ub280WG1vYVBtb1lqb3Y1dmxoYVhtdUxqbWlJ
OHNMQ3dLYzJoaFpHVnlYMnh2WVdScGJtY3M1cTJqNVp5bzU3eVc2SytSNTUyQTZJbXk1Wm1vTE9hdG8rV2NxT2U4bHVpdmtlZWRnT2lKc3VXWnFDd3NMQXB6
YUdGa1pYSmZkMkZwZEdsdVoxOWtaV1oxYkhSZmRHbHdjeXpudkpib3I1SG5uWURvaWJMbG1ham9nSmZtbDdib3ZvUHBsYi92dkl6b3I3Zm1tSi9rdUxUb2dJ
WG9nSkRsdjRQbnJZbmx2b1VzNTd5VzZLK1I1NTJBNklteTVabW82SUNYNXBlMjZMNkQ2WlcvNzd5TTZLKzM1cGlmNUxpMDZJQ0Y2SUNRNWIrRDU2Mko1YjZG
TEN3c0NuTm9ZV1JsY2w5M1lXbDBhVzVuWDJsdmMxOTBhWEJ6TENMbnZKYm9yNUhubllEb2liTGxtYWpvZ0pmbWw3Ym92b1BwbGI4czVMaTY1bytRNVkySDVw
V0k1NDZINzd5TTVZcW81NVM3NXBxQzVZR2M1cEt0NXBTKzc3eU02SyszNXBpZjVMaTA2SUNGNklDUTViK0Q1NjJKNWI2Rklpem52SmJvcjVIb2taZm9pYkxs
bWFqb2dKZm1sN2Jvdm9QcGxiL3Z2SXprdUxybWo1RGxqWWZtbFlqbmpvZnZ2SXpsaXFqbmxMdm1tb0xsZ1p6bWtxM21sTDd2dkl6b3I3Zm1tSi9rdUxUb2dJ
WG9nSkRsdjRQbnJZbmx2b1VzTEN3S2NHRmphMkZuWlY5dVpXVmtYM1Z3WkdGMFpWOXBibTVsY2l3aTVZYUY1NzJSNWEyWTVaeW81cGF3NTVxRTVhNko2S09G
NVl5RkxDRGxqNi9wZ0lubWk2bmt1SXZvdmIzbW5JRG1sckRscm9ub280WGxqSVVzSU9lQ3VlV0h1K2VocnVXdW11aS9tK1dGcGVhNHVPYUlqeUlzNVl5NjVa
K2Y1NzJSNkxldjVweUo1cGF3NTVxRTVhNko2S09GNXFHajVxR0k3N3lNNVkrdjZZQ0o1b3VwNUxpTDZMMjk1cHlBNXBhdzVhNko2S09GNXFHajVxR0k3N3lN
NTRLNTZZQ0o1Nkd1NWE2YTZMK2I1WVdsNXJpNDVvaVBMQ3dzQ25GMWFYUmZaMkZ0WlY5MGFYUnNaU3pwZ0lEbGg3cm11TGptaUk4czZZQ0E1WWU2NXJpNDVv
aVBMQ3dzQ25GMWFYUmZaMkZ0WlY5amIyNTBaVzUwTE9hWXIrV1FwdWVocnVpdXBPaW1nZW1BZ09XSHV1YTR1T2FJaisrOG55em1tSy9sa0tibm9hN29ycVRv
cG9IcGdJRGxoN3JtdUxqbWlJL3Z2SjhzTEN3S2NYVnBkRjluWVcxbFgzWmxjbk5wYjI1ZmJtOTBYMjFoZEdOb0xDTG11TGptaUkvbHZaUGxpWTNuaVlqbW5L
emxwSVRrdW83bnU3VG1pcVRrdUswc0lPZW9qZVdRanVtSGplaXZsUzRpTE9hNHVPYUlqK2VicnVXSmplZUppT2Fjck9hdG8rV2NxT2U3dE9hS3BPUzRyZSs4
ak9pdnQrZW9qZVdRanVXR2plaXZsZU9BZ2l3c0xBcGxjbkp2Y2w5elpYSjJaWEpmTVRBd01USXM1YTZpNW9pMzU2dXY2SyszNXJHQzVZK0M1cFd3NUxpTjVZ
eTU2WVdOTE9XdW91YUl0K2VycitpdnQrYXhndVdQZ3VhVnNPUzRqZVdNdWVtRmpTd3NMQXBsY25KdmNsOXpaWEoyWlhKZk1UQXdNVE1zNXB5cTVvbSs1WWl3
NksrMzVyR0NRMlJ1NUwraDVvR3ZMT2FjcXVhSnZ1V0lzT2l2dCtheGdrTmtidVMvb2VhQnJ5d3NMQXBsY25KdmNsOXpaWEoyWlhKZk1UQXdNVFFzNXB5cTVv
bSs1WWl3NksrMzVyR0M2WUNhNXB5TjVhU241WXk2NUwraDVvR3ZMT2FjcXVhSnZ1V0lzT2l2dCtheGd1bUFtdWFjamVXa3ArV011dVMvb2VhQnJ5d3NMQXBs
Y25KdmNsOXpaWEoyWlhKZk1UQXdNVFVzNXB5cTVvbSs1WWl3NksrMzVyR0M1cDZFNWJ1NlNtOWk1NG1JNXB5czVMK2g1b0d2TE9hY3F1YUp2dVdJc09pdnQr
YXhndWFlaE9XN3VrcHZZdWVKaU9hY3JPUy9vZWFCcnl3c0xBcGxjbkp2Y2w5elpYSjJaWEpmTVRBd01UWXM1cHlxNW9tKzVZaXc2SyszNXJHQzVhNko2S09G
NVl5RjU0bUk1cHlzNUwraDVvR3ZMT2FjcXVhSnZ1V0lzT2l2dCtheGd1V3VpZWlqaGVXTWhlZUppT2Fjck9TL29lYUJyeXdzTEFwbGNuSnZjbDl6WlhKMlpY
SmZNVEF3TVRjczVweXE1b20rNVlpdzZLKzM1ckdDNTRPdDVwdTA1NG1JNXB5czVMK2g1b0d2TE9hY3F1YUp2dVdJc09pdnQrYXhndWVEcmVhYnRPZUppT2Fj
ck9TL29lYUJyeXdzTEFwd1lXTnJZV2RsWDI1bFpXUmZkWEJrWVhSbFgzQmpMT1d1b3VhSXQrZXJyK2VKaU9hY3JPbWNnT2FidE9hV3NPKzhqT2l2dCtXSmpl
VytnT1dRcitXS3FPV1pxT1d1ak9hSWtPYWJ0T2FXc0N6bHJxTG1pTGZucTYvbmlZam1uS3pwbklEbW03VG1sckR2dkl6b3I3ZmxpWTNsdm9EbGtLL2xpcWps
bWFqbHJvem1pSkRtbTdUbWxyQXNMQ3dLY0dGamEyRm5aVjl1YjNSZmRYQnNiMkZrTE9XdW91YUl0K2VycithYnRPYVdzT2FhZ3VhY3F1V1BrZVc0ZysrOGpP
aXZ0K2FZbitTNHRPaUFoZWlBa09XL2crZXRpZVcraFN6bHJxTG1pTGZucTYvbW03VG1sckRtbW9MbW5LcmxqNUhsdUlQdnZJem9yN2ZtbUova3VMVG9nSVhv
Z0pEbHY0UG5yWW5sdm9Vc0xDd0tjR0ZqYTJGblpWOWpiR2xsYm5SZmJtOTBYMnhoZEdWemRDem1vNERtdFl2bGlMRG11TGptaUkvbW03VG1sckR2dkl6cG5J
RG9wb0hwaDQzbGtLL211TGptaUkvbHJvem1pSkRtbTdUbWxyQXM1TDZtNXJXTDVZaXc1cmk0NW9pUDVwdTA1cGF3Nzd5TTZaeUE2S2FCNlllTjVwYXc1WkN2
NVlxbzVyaTQ1b2lQNWE2TTVvaVE1cHUwNXBhd0xDd3NDbXh2WjJsdVgyWmhhV3hsWkN6bm1idmx2WlhscExIb3RLVXM1NW03NWIyVjVhU3g2TFNsTEN3c0Nu
SmxYMnh2WjJsdUxPbUhqZWFXc09lWnUrVzlsU3pwaDQzbWxyRG5tYnZsdlpVc0xDd0tiRzluYjNWMFgyWmhhV3dzNTVtNzVZZTY1YVN4NkxTbExPZVp1K1dI
dXVXa3NlaTBwU3dzTEFweVpYUjFjbTVmYkc5bmFXNHM1cmk0NW9pUDU3dTA1b3FrNUxpdDc3eU01WnVlNVlpdzU1bTc1YjJWNTVXTTZaMmlMT2E0dU9hSWor
ZTd0T2FLcE9TNHJlKzhqT1dibnVXSXNPZVp1K1c5bGVlVmpPbWRvaXdzTEFwbllXMWxYMjVoYldVczZKT2Q2SW15NXBpZjVZNmY3N3lhNXBlRjZMQ2pMT2lU
bmVpSnN1YVluK1dPbisrOG11YVhoZWl3b3l3c0xBcGlZV05yWjNKdmRXNWtYMlJ2ZDI1c2IyRmthVzVuTE9TNGkraTl2ZVM0cmVLQXBpemt1SXZvdmIza3VL
M2lnS2JpZ0tZc0xDd0tZbUZqYTJkeWIzVnVaRjlrYjNkdWJHOWhaRjltWVdsc1pXUXM1TGlMNkwyOTVhU3g2TFNsNzd5TTZLKzM2WWVONXBhdzViQ2Q2SytW
TE9TNGkraTl2ZVdrc2VpMHBlKzhqT2l2dCttSGplYVdzT1d3bmVpdmxTd3NMQXBpWVdOclozSnZkVzVrWDJSdmQyNXNiMkZrWDNOMVkyTmxjM01zNUxpTDZM
Mjk1YTZNNW9pUUxPUzRpK2k5dmVXdWpPYUlrQ3dzTEFwamJHVmhjbDkxYm5WelpXUmZZWE56WlhSekxPYXRvK1djcU9hNGhlZVFodWkxaE9hNmtDem1yYVBs
bktqbXVJWG5rSWJvdFlUbXVwQXNMQ3dLYldWeVoybHVaMTloYzNObGRITXM2TFdFNXJxUTVaQ0k1Ym0yNUxpdExPaTFoT2E2a09XUWlPVzV0dVM0clN3c0xB
cGhjM05sZEhOZmJXVnlaMmx1WjE5bVlXbHNaV1FzNkxXRTVycVE1WkNJNWJtMjVhU3g2TFNsTE9pMWhPYTZrT1dRaU9XNXR1V2tzZWkwcFN3c0xBcDFjR1Jo
ZEdWZlkyOXRjR3hsZEdWZmNtVnpkR0Z5ZEN6bHZaUGxpWTNsclpqbG5Lam1uS3JrdUl2b3ZiM25tb1RtbTdUbWxyRGxob1hscnJudnZJem11TGptaUkvbGpi
UGxzSWJwaDQzbGtLOHM1NXV1NVltTjViQ2E1cHlKNXB5cTVMaUw2TDI5NTVxRTVwdTA1cGF3NVlhRjVhNjU3N3lNNXJpNDVvaVA1WTJ6NWJDRzZZZU41cGF3
NVpDdjVZcW9MQ3dzQ25Wd1pHRjBaVjlqYjIxd2JHVjBaVjl5WlhOMFlYSjBYMjkwYUdWeUxPVzlrK1dKamVXdG1PV2NxT2FjcXVTNGkraTl2ZWVhaE9hYnRP
YVdzT1dHaGVXdXVlKzhqT2l2dCttSGplV1FyK2E0dU9hSWp5em5tNjdsaVkzbHNKcm1uSW5tbktya3VJdm92YjNubW9UbW03VG1sckRsaG9YbHJybnZ2SXpv
cjdmcGg0M21sckRsa0svbGlxam11TGptaUk4c0xDd0thVzF3YjNKMGFXNW5YMkZ6YzJWMGN5em90WVRtdXBEbHI3emxoYVhrdUswczZMV0U1cnFRNWErODVZ
V2w1TGl0TEN3c0NtRnpjMlYwYzE5cGJYQnZjblJwYm1kZlptRnBiR1ZrTE9pMWhPYTZrT1d2dk9XRnBlV2tzZWkwcFN6b3RZVG11cERscjd6bGhhWGxwTEhv
dEtVc0xDd0tZMjl0Y0dGeVpWOWhjM05sZEhNczVweXM1Wnl3NkxXRTVycVE1cStVNWErNTVMaXRMT2Fjck9XY3NPaTFoT2E2a09hdmxPV3Z1ZVM0clN3c0xB
cHNiMk5oYkY5aGMzTmxkSE5mWTJobFkydHBibWNzNkxXRTVycVE1cU9BNXArbDVMaXRMT2kxaE9hNmtPYWpnT2FmcGVTNHJTd3NMQXB6ZFdKd1lXTnJZV2Rs
WDJSc1gzVnBYekV3TURFczVvcWk1WVdJTE9hS291V0ZpQ3dzTEFwemRXSndZV05yWVdkbFgyUnNYM1ZwWHpFd01ESXM1YTZNNXBXMExPV3VqT2FWdEN3c0xB
cHpkV0p3WVdOcllXZGxYMlJzWDNWcFh6RXdNRE1zNUx1RjVMaUw2TDI5NWJxUDU2dWc2TFdFNXJxUTc3eUllekI5Nzd5Sjc3eU01WSt2NXB1MDVwZXA1TDJU
NmFxTTVyaTQ1b2lQTE9TN2hlUzRpK2k5dmVXNmorZXJvT2FobythaGlDaDdNSDBwNzd5TTVZK3Y1cHUwNXBlcDVMMlQ2YXFNNXJpNDVvaVBMQ3dzQ25OMVlu
QmhZMnRoWjJWZlpHeGZkV2xmTVRBd05Demt1SXZvdmIzbHJvem1sYlRvdFlUbXVwRHZ2SWg3TUgzdnZJbnZ2SXpsajYvcG9icm5sWVhrdlpQcHFvemxyb3pt
bGJUbXVMam1pSS9saG9YbHJya3M1TGlMNkwyOTVhNk01cFcwNXFHajVxR0lLSHN3ZlNudnZJemxqNi9tdFlIbmxZWGt2WlBwcW96bHJvem1sYlRtdUxqbWlJ
L2xob1hscnJrc0xDd0tjM1ZpY0dGamEyRm5aVjlrYkY5MWFWOHhNREExTE9XNmorZXJvT1M5ayttcWpPV3VqT2F2bGVXUWp1UzdqZW1jZ09TNGkraTl2ZVd1
ak9hVnRPaTFoT2E2a0N6bHVvL25xNkRrdlpQcHFvemxyb3ptcjVYbGtJN2t1NDNwbklEa3VJdm92YjNscm96bWxiVG90WVRtdXBBc0xDd0tjM1ZpY0dGamEy
Rm5aVjlrYkY5MWFWOHhNREEyTE9TNGkraTl2U3prdUl2b3ZiMHNMQ3dLYzNWaWNHRmphMkZuWlY5a2JGOTFhVjh4TURBM0xPUzZzdWVJc2VlYWhPYVdzT1M0
dE9pQWhlKzhqT2FDcU9XM3N1V3VqT2FJa09XNmorZXJvT1M5ayttcWpPKzhqT1M0aStpOXZlV0pxZVM5bWVXdWpPYVZ0T2kxaE9hNmtPV1FqdVdQcitTOWsr
bXFqT1dRanVlN3JlV0doZVd1dVN6a3VyTG5pTEhubW9UbWxyRGt1TFRvZ0lYdnZJem1ncWpsdDdMbHJvem1pSkRsdW8vbnE2RGt2WlBwcW96dnZJemt1SXZv
dmIzbGlhbmt2Wm5scm96bWxiVG90WVRtdXBEbGtJN2xqNi9rdlpQcHFvemxrSTdudTYzbGhvWGxycmtzTEN3S2MzVmljR0ZqYTJGblpWOWtiRjkxYVY4eE1E
QTRMT1M0aStpOXZlV0pxZVM5bWVXdWpPYVZ0T2kxaE9hNmtPKzhpSHN3ZmUrOGlTemt1SXZvdmIzbGlhbmt2Wm5scm96bWxiVG1vYVBtb1lnb2V6QjlLU3dz
TEFwemRXSndZV05yWVdkbFgyUnNYM1ZwWHpFd01Ea3M1YnFQNTZ1ZzZMV0U1cnFRNWJleTVMaUw2TDI5Nzd5TTVZK3Y1NnVMNVkyejVMMlQ2YXFNNXJpNDVv
aVA1YnFQNTZ1ZzVZYUY1YTY1TE9XNmorZXJvT2kxaE9hNmtPVzNzdVM0aStpOXZlKzhqT1dQcitlcmkrV05zK1M5ayttcWpPYTR1T2FJaitXNmorZXJvT1dH
aGVXdXVTd3NMQXB6ZFdKd1lXTnJZV2RsWDJSc1gzVnBYekV3TVRBczVvcWk1WVdJNUwyVDZhcU1MT2FLb3VXRmlPUzlrK21xakN3c0xBcHpkV0p3WVdOcllX
ZGxYMlJzWDNWcFh6RXdNVEVzNUxpTDZMMjk1WkNPNVkrdjU1dTA1bzZsNkwrYjZLR001YTZNNXBXMDVyaTQ1b2lQTE9TNGkraTl2ZVdRanVXUHIrZWJ0T2FP
cGVpL20raWhqT1d1ak9hVnRPYTR1T2FJanl3c0xBcGtiM2R1Ykc5aFpGOTFhVjh4TURBeExPYVVyK2FNZ2VXUWp1V1BzT1M0aStpOXZTem1sSy9taklIbGtJ
N2xqN0RrdUl2b3ZiMHNMQ3dLY0hKbGJHOWhaRjlqWVd4amRXeGhkR2x1Wnl3bzZMV0U1cnFRNks2aDU2Nlg1TGl0S1N3bzZMV0U1cnFRNks2aDU2Nlg1TGl0
S1N3c0xBcHpkV0p3WVdOcllXZGxYMk5oYkdOMWJHRjBhVzVuTE9pdW9lZXVsK1M0cmVLQXBpem9ycUhucnBma3VLM2lnS2JpZ0tZc0xDd0tjSEpsYkc5aFpG
OXViM1JwWTJVczZaeUE2S2FCNUxpTDZMMjllekI5NTVxRTVyaTQ1b2lQNkxXRTVycVE3N3lNNmFLRTVMaUw2TDI5NXB5ZjZaZTA1cGVnNXJPVjZMK2I2S0dN
NXJpNDVvaVBMT21jZ09pbWdlUzRpK2k5dlhzd2ZlZWFoT2E0dU9hSWorYWhvK2FoaU8rOGpPbWloT1dGaU9TNGkraTl2ZWFjbittWHRPYVhvT2F6bGVpL20r
aWhqT2E0dU9hSWp5d3NMQXB3Y21Wc2IyRmtYMlpwYm1semFDenBvb1RrdUl2b3ZiM2x0N0xscm96bWlKQXM2YUtFNVlXSTVMaUw2TDI5NWJleTVhNk01b2lR
TEN3c0NuTjBZWEowWDNScGNDemx2SURscDR2bWw0WG5xSXNzNWJ5QTVhZUw1cGVGNTZpTExDd3NDbU52YlhCcGJHbHVaMTkwYVhBczU3eVc2SytSNUxpdExP
ZThsdWl2a2VTNHJTd3NMQW89In0=
