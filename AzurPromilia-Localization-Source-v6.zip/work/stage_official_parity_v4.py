from pathlib import Path
import copy,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v4';OUT.mkdir(exist_ok=True)
STABLE=ROOT/'work/official_game_patch'
plan=json.loads((STABLE/'deployment-plan.json').read_text('utf8'))
assert plan['patch_revision']==3
meta=json.loads((ROOT/'work/game_decrypt_paths/sdk_qm/mainland-common-plus-global-manifest.json').read_text('utf8'))
candidate=ROOT/'work/game_decrypt_paths/sdk_qm/union_pcsdk.mainland-common-plus-global.candidate.dll'
data=Path(plan['data_root']);rel='Plugins/mj_sdk/union_pcsdk.dll';installed=data/rel
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(installed)==meta['original_sha256']
assert sha(candidate)==meta['candidate_sha256']
assert installed.stat().st_size==candidate.stat().st_size
entry=dict(relative_path=rel,source_sha256=meta['original_sha256'],target_sha256=meta['candidate_sha256'],
           candidate=str(candidate),size=candidate.stat().st_size,previous_sha256=[])
assert not any(f['relative_path']==rel for f in plan['files'])
plan['files'].append(entry);plan['patch_revision']=4;plan['runtime_tested']=False
plan['official_parity_v4']=dict(sdk_translation_entries=143,
    sdk_mainland_identical=31,sdk_mainland_adapted=7,sdk_region_semantics_retained=6,
    sdk_official_simplified_fallback=99,login_status_official='欢迎回来',switch_account_official='切换账号',
    sdk_code_and_region_configuration_unchanged=True,
    sdk_original_signature='Valid',sdk_modified_signature='HashMismatch',sdk_load_runtime_verified=False,
    unresolved=['远端公告词汇替换仍需可验证的显示处理入口','独有台服条目无同ID国服来源','SDK加载尚需运行验证'])
plan['ui_v2']['unresolved']=['登录状态官方译文已定位并纳入V4候选，待安装及运行验证']
(OUT/'deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
(OUT/'Apply-OfficialZH.ps1').write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
(OUT/'stage-report.json').write_text(json.dumps(dict(installed_modified=False,revision=4,
    files=len(plan['files']),new_files=[entry],sdk_validation=str(ROOT/'work/game_decrypt_paths/sdk_qm/mainland-common-plus-global-manifest.json')),
    ensure_ascii=False,indent=2),'utf8')
print(json.dumps(dict(revision=4,files=len(plan['files']),new_bytes=candidate.stat().st_size,installed_modified=False)))
