from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch'
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'))
assert len(plan['files'])==14 and plan['font_coverage']['combinedMissingCount']==0
(OUT/'Apply-OfficialZH.ps1').write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
bat='@echo off\r\nchcp 65001 >nul\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\\work\\official_game_patch\\Apply-OfficialZH.ps1"\r\npause\r\n'
(ROOT/'outputs/台服游戏官方简体替换与还原.bat').write_bytes(bat.encode('ascii'))
report='''# 台服游戏官方简体替换试验

此补丁将国服官方简体文字按“语言表名＋文本 ID”对应到台服，保持台服语言标识 `cht`。

- 台服 357 张语言表，共 470,989 条记录。
- 对应国服 470,963 条：339,523 条相同；131,440 条不同。
- 实际替换 131,439 条不同文字；国服特有的备案文字不写入台服。
- 台服特有 26 条操作提示：8 条复用国服同文、3 条字形原已一致、15 条短提示补充转简。
- 剧情、道具、技能、任务、菜单等内容以各语言表中的实际条目为范围。
- 台服原有 1,737,118 个文字池键值全部保持原文；新增文字使用新键。仅修改 cht 语言行中的文字引用，其余表数据及英语均通过不变校验。
- 配套 a00、b00、c00 字体及 SDF 回退引用/加载依赖。替换文字所需 3,868 个字符联合覆盖完整。

双击同目录 `台服游戏官方简体替换与还原.bat`：

1. 应用官方简体文字与字体。
2. 还原本次修改。
3. 检查当前状态。

目标：`E:\\AzurPromilia_TC\\AzurPromilia_TC_game`。

本次修改 14 个资源和清单文件。写入前核对源文件 SHA256、完成原文件备份；应用和还原均支持失败回滚。已通过真实 Windows PowerShell 的模拟文件测试，包括应用、还原、重复应用、版本不匹配拒绝写入，以及中途失败回滚。

备份目录：`E:\\AzurPromilia_TC\\AzurPromilia_TC_game\\.zhcn-official-3221745-backup`。

补丁数据与脚本位于工作区 `work/official_game_patch`，保留该目录以使用上述 BAT。版本不匹配时脚本会停止。

已完成：加密读写往返、文字内容、保留范围、字体覆盖、资源大小/CRC/清单 MD5 和字体依赖的离线验证。

待确认：实际游戏启动、菜单、剧情对话、道具说明与特殊界面的显示。当前结论是可还原试验版，尚未获得运行验证；服务器下发的动态文字和图片内文字不属于本地语言表替换范围。
'''
(ROOT/'outputs/台服游戏官方简体替换说明.md').write_text(report,'utf8')
print(json.dumps(dict(files=len(plan['files']),patch_bytes=sum(x['size'] for x in plan['files']),tool=str(OUT/'Apply-OfficialZH.ps1')),ensure_ascii=True))
