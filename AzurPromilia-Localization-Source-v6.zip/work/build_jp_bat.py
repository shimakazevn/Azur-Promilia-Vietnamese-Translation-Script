from pathlib import Path
import re
HERE=Path(__file__).parent
ps=(HERE/'launcher_portable.ps1').read_text('utf-8')
ps=ps.replace('30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa','4f013026736f6afa819a37f299caa9577140e88254ef4097b4d4589fa47f0818')
ps=re.sub(r'\$knownHashes = @\([^\n]+\)',r'$knownHashes = @($originalHash, $patchedHash)',ps)
ps=ps.replace('台服','日服').replace('1.0.1.4','1.8.1').replace('launcher.exe','AZUPRO_JP_Gamelauncher.exe')
ps=ps.replace("$directories = @($path)","$directories = @($path)\n        $directories += @([IO.Directory]::GetDirectories($path) | Where-Object { [IO.Path]::GetFileName($_) -match '^(?:YostarGames|AZUPRO_JP_Gamelauncher)$' })\n        if ([IO.Directory]::Exists((Join-Path $path 'YostarGames\\AZUPRO_JP_Gamelauncher'))) { $directories += Join-Path $path 'YostarGames\\AZUPRO_JP_Gamelauncher' }")
ps=ps.replace("Root = [IO.Path]::GetDirectoryName($directory)","Root = $directory")
ps=ps.replace('AzurPromilia|蓝色星原|藍色星原','AZUPRO|Yostar|AzurPromilia|アズールプロミリア|蓝色星原|藍色星原')
ps=ps.replace("if ($directory.Name -match 'AZUPRO|", "if ($directory.Name -match 'AZUPRO|")
ps=ps.replace("(Games?|游戏|遊戲|Program Files", "(Games?|YostarGames|游戏|遊戲|Program Files")
ps=re.sub(r'    \$gameDirectory = Find-GameDirectory \$launcher.Root\n.*?\n    \$running =', '    $running =',ps,flags=re.S)
ps=ps.replace('游戏根目录、启动器版本目录或','YostarGames 目录、日服启动器目录或')
(HERE/'launcher_jp_portable.ps1').write_text(ps,encoding='utf-8')
builder=(HERE/'build_launcher_bat.py').read_text('utf-8')
builder=builder.replace(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak',r'E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar.before-zhcn-20261124.bak')
builder=builder.replace('launcher_complete.app.asar','launcher_jp_zhcn.app.asar').replace('launcher_portable.ps1','launcher_jp_portable.ps1').replace("OUT/'启动器简体汉化与还原.bat'","OUT/'日服启动器简体汉化与还原.bat'")
exec(compile(builder,str(HERE/'build_launcher_bat.py'),'exec'))
