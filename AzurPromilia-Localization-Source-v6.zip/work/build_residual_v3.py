"""Stage narrowly scoped wording fixes; preserve original pool keys and V2 data."""
from pathlib import Path
import copy,hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work'),str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/game_decrypt_paths'),str(ROOT/'work/game_mmap')]
from vstring_pool import VStringPool
from rebuild_vstring import rebuild,append_custom_texts,HashIndex
from parse_language_tables import read_index,read_rows
from patch_manifest import patch_manifest
from decode_mmap import decode_file
from build_official_game_patch import encode

OUT=ROOT/'work/official_game_patch_v3';OUT.mkdir(exist_ok=True)
stable=ROOT/'work/official_game_patch'
plan=json.loads((stable/'deployment-plan.json').read_text('utf8'))
assert plan['patch_revision']==2
data=Path(plan['data_root'])
sha=lambda b:hashlib.sha256(b).hexdigest()
for f in plan['files']:assert sha((data/f['relative_path']).read_bytes())==f['target_sha256'],f['relative_path']
pool=VStringPool(stable/'vstring-patched.bin')
original=(stable/'table-data-patched.bin').read_bytes()
fixes={'未入駐':'未入驻','当前状态不能切換':'当前状态不能切换'}
items,mapping=append_custom_texts(pool,list(fixes.values()))
newpool=rebuild(pool,items)
(OUT/'vstring-patched.bin').write_bytes(newpool)
new=VStringPool(OUT/'vstring-patched.bin')
for k in range(pool.count):assert pool[k]==new[k]
idx=HashIndex(new)
for i,(text,h) in enumerate(items):assert idx.lookup(h,text) is not None
table=bytearray(original);_,langs,_=read_index(original);changes=[]
for name,off in langs['cht'].items():
 for row in read_rows(original,off,pool):
  if row['value'] in fixes:
   value=fixes[row['value']];key=mapping[value]
   struct.pack_into('<I',table,row['value_offset'],key)
   changes.append(dict(table=name,id=row['id'],before=row['value'],after=value,
                       old_key=row['key'],new_key=key,value_offset=row['value_offset']))
assert len(changes)==2
allowed={i for r in changes for i in range(r['value_offset'],r['value_offset']+4)}
assert len(original)==len(table) and all(a==b or i in allowed for i,(a,b) in enumerate(zip(original,table)))
for language,tables in langs.items():
 for name,off in tables.items():
  before=read_rows(original,off,pool);after=read_rows(table,off,new)
  for a,b in zip(before,after):
   if language=='cht' and a['value'] in fixes:assert b['value']==fixes[a['value']]
   else:assert a==b
assert new[1563477]=='闇星庇佑'
(OUT/'table-data-patched.bin').write_bytes(table)

staged={}
for package,filename,plain,oldplain in [
 ('raw_base_package','v0k2cafcxjxawklow6skg.r',newpool,pool.data),
 ('raw_streaming_package','3iffxeedh2grvnbn2iag.r',bytes(table),original)]:
 rel=Path('.res')/package/'BundleFiles'/filename;src=data/rel
 decoded=OUT/(filename+'.baseline.bin');decode_file(src,decoded)
 assert decoded.read_bytes()==oldplain
 encrypted=encode(src.read_bytes(),plain)
 dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(encrypted)
 decoded=OUT/(filename+'.roundtrip.bin');decode_file(dest,decoded);assert decoded.read_bytes()==plain
 manifest=data/'.res'/package/'ManifestFiles'/f'0release_{package}_3221745.bytes'
 payload=manifest.read_bytes();assert manifest.with_suffix('.hash').read_bytes()==hashlib.md5(payload).hexdigest().encode('ascii')
 nm,nh,rep=patch_manifest(payload,src,encrypted,src.read_bytes())
 staged[src]=dest
 for path,payload in [(manifest,nm),(manifest.with_suffix('.hash'),nh)]:
  target=OUT/path.relative_to(data);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload);staged[path]=target

for src,candidate in staged.items():
 rel=src.relative_to(data).as_posix();f=next(f for f in plan['files'] if f['relative_path']==rel)
 f['previous_sha256']=sorted(set(f.get('previous_sha256',[])+[f['target_sha256']]))
 f.update(target_sha256=sha(candidate.read_bytes()),size=candidate.stat().st_size,candidate=str(candidate))
plan['patch_revision']=3
plan['residual_v3']=dict(language_table_changes=changes,proper_name_preserved='闇星庇佑',
                       previous_pool_keys_preserved=pool.count,appended_pool_strings=len(items))
(OUT/'text-stage-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
(OUT/'text-validation.json').write_text(json.dumps(dict(changed_rows=changes,appended_strings=len(items),
    previous_pool_values_preserved=True,other_language_rows_unchanged=True,all_other_table_bytes_unchanged=True,
    proper_name_preserved=True,mmap_roundtrip=True,installed_modified=False),ensure_ascii=False,indent=2),'utf8')
print(json.dumps(dict(changes=changes,appended_strings=len(items),files=len(staged)),ensure_ascii=True),flush=True)
