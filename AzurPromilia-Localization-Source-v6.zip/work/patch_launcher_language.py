"""Simplify the launcher's complete Traditional Chinese UI dictionary."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "analysis_deps"))
from opencc import OpenCC

TARGET = Path(r"E:\AzurPromilia_TC\1.0.1.4\resources\app.asar")
MEMBER = "_next/static/chunks/327-2adec23307eb9076.js"
PREPARED = HERE / "launcher_simplified.app.asar"
MANIFEST = HERE / "launcher_language_patch.json"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def parse(data):
    length = struct.unpack_from("<I", data, 12)[0]
    header = data[16:16 + length]
    return json.loads(header), header, 8 + struct.unpack_from("<I", data, 4)[0]

def entries(header, prefix=""):
    for name, entry in header.get("files", {}).items():
        path = prefix + name
        if "files" in entry:
            yield from entries(entry, path + "/")
        else:
            yield path, entry

def member_data(data, entry, start):
    offset = start + int(entry["offset"])
    return data[offset:offset + entry["size"]]

def prepare():
    original = TARGET.read_bytes()
    header, header_bytes, start = parse(original)
    entry = dict(entries(header))[MEMBER]
    old_chunk = member_data(original, entry, start)
    assert old_chunk.count(b'"./zh-CN.json":8096,"./zh-TW.json":9500') == 1
    dictionaries = {}
    matches = {}
    for number in (8096, 9500):
        pattern = str(number) + r':function\(e\)\{"use strict";e.exports=JSON.parse\((\x27(?:\\.|[^\x27\\])*\x27)\)\}'
        match = re.search(pattern, old_chunk.decode("utf-8"))
        assert match, f"Dictionary module {number} was not found."
        matches[number] = match
        dictionaries[number] = json.loads(ast.literal_eval(match.group(1)))
    assert dictionaries[8096].keys() == dictionaries[9500].keys(), "Language dictionary keys differ."
    old_literal = matches[9500].group(1)
    new_literal = OpenCC("t2s").convert(old_literal)
    simplified = json.loads(ast.literal_eval(new_literal))
    assert simplified.keys() == dictionaries[9500].keys()
    for key in simplified:
        assert sorted(re.findall(r"\{\d+\}", simplified[key])) == sorted(
            re.findall(r"\{\d+\}", dictionaries[9500][key])
        ), f"Interpolation arguments differ: {key}"
        assert bool(simplified[key]) == bool(dictionaries[9500][key])
    assert len(old_literal.encode("utf-8")) == len(new_literal.encode("utf-8"))
    assert old_chunk.count(old_literal.encode("utf-8")) == 1
    new_chunk = old_chunk.replace(old_literal.encode("utf-8"), new_literal.encode("utf-8"))
    integrity = entry["integrity"]
    assert integrity["algorithm"] == "SHA256"
    assert integrity["hash"] == sha(old_chunk)
    assert len(old_chunk) < integrity["blockSize"]
    assert integrity["blocks"] == [sha(old_chunk)]
    old_digest = sha(old_chunk).encode("ascii")
    new_digest = sha(new_chunk).encode("ascii")
    assert header_bytes.count(old_digest) == 2
    updated_header = header_bytes.replace(old_digest, new_digest)
    updated = bytearray(original)
    updated[16:16 + len(header_bytes)] = updated_header
    offset = start + int(entry["offset"])
    updated[offset:offset + len(new_chunk)] = new_chunk
    assert len(updated) == len(original)
    updated_header_obj, _, updated_start = parse(updated)
    changed = []
    for name, old_entry in entries(header):
        if old_entry.get("unpacked") or "link" in old_entry:
            continue
        new_entry = dict(entries(updated_header_obj))[name]
        left = member_data(original, old_entry, start)
        right = member_data(updated, new_entry, updated_start)
        if left != right:
            changed.append(name)
        assert len(left) == len(right)
    assert changed == [MEMBER]
    PREPARED.write_bytes(updated)
    (HERE / "launcher_simplified_chunk.js").write_bytes(new_chunk)
    patch = {
        "target": str(TARGET), "member": MEMBER,
        "original_sha256": sha(original), "patched_sha256": sha(updated),
        "dictionary_key_count": len(dictionaries[8096]),
        "changed_dictionary_values": sum(simplified[key] != dictionaries[9500][key]
                                          for key in simplified),
        "method": "OpenCC t2s on module 9500 dictionary strings; language mapping and all other module code retained.",
        "examples": {key: {"before": dictionaries[9500][key], "after": simplified[key]}
                     for key in ("BTN_MAIN_START", "TAB_TITLE_CONFIG_SETUP", "TXT_AUTO_START", "TRAY_EXIT")},
        "validation": "Only the specified member payload changed; all archive offsets and lengths preserved; SHA256 member integrity updated; interpolation placeholders match.",
    }
    MANIFEST.write_text(json.dumps(patch, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(patch, ensure_ascii=False, indent=2))

def apply():
    patch = json.loads(MANIFEST.read_text("utf-8"))
    assert sha(TARGET.read_bytes()) == patch["original_sha256"], "Launcher changed since patch preparation."
    assert sha(PREPARED.read_bytes()) == patch["patched_sha256"]
    backup = TARGET.with_name("app.asar.before-zhcn-20261124.bak")
    if backup.exists():
        assert sha(backup.read_bytes()) == patch["original_sha256"], "An unrelated backup already exists."
    else:
        shutil.copy2(TARGET, backup)
    temporary = TARGET.with_name("app.asar.codex-language.tmp")
    assert not temporary.exists(), "Staging file already exists."
    shutil.copy2(PREPARED, temporary)
    temporary.replace(TARGET)
    assert sha(TARGET.read_bytes()) == patch["patched_sha256"]
    patch["backup"] = str(backup)
    patch["applied"] = True
    MANIFEST.write_text(json.dumps(patch, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"applied": True, "backup": str(backup), "target": str(TARGET)}, ensure_ascii=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "apply"])
    args = parser.parse_args()
    {"prepare": prepare, "apply": apply}[args.action]()
