from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v4';STABLE=ROOT/'work/official_game_patch'
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'))
data=Path(plan['data_root']);backup=data.parent/'.zhcn-official-3221745-backup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in plan['files']:
 assert sha(data/f['relative_path'])==f['target_sha256'],f['relative_path']
 assert sha(backup/f['relative_path'])==f['source_sha256'],f['relative_path']
 assert sha(Path(f['candidate']))==f['target_sha256'],f['relative_path']
for f in plan['required_unchanged_files']:assert sha(data/f['relative_path'])==f['sha256']
archive=STABLE/'deployment-plan.v3.json'
if not archive.exists():
 assert json.loads((STABLE/'deployment-plan.json').read_text('utf8'))['patch_revision']==3
 archive.write_bytes((STABLE/'deployment-plan.json').read_bytes())
plan['ui_v2']['unresolved']=['SDK登录状态已安装官方简体译文，游戏实际加载待验证']
(OUT/'deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
for name in ['deployment-plan.json','Apply-OfficialZH.ps1']:
 temporary=STABLE/(name+'.stage');temporary.write_bytes((OUT/name).read_bytes());temporary.replace(STABLE/name)
report=dict(applied=True,patch_revision=4,applied_at=datetime.datetime.now().astimezone().isoformat(),
 installed_files_verified=len(plan['files']),original_backups_verified=len(plan['files']),
 candidates_verified=len(plan['files']),language='cht',runtime_verified=False,
 backup_directory=str(backup),ui_v2=plan['ui_v2'],residual_v3=plan['residual_v3'],
 official_parity_v4=plan['official_parity_v4'],verified_files=[f['relative_path'] for f in plan['files']])
for path in [OUT/'installed-verification.json',STABLE/'installed-verification.json',ROOT/'outputs/台服游戏官方简体应用记录.json']:
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
docpath=ROOT/'outputs/台服游戏官方简体替换说明.md'
doc=docpath.read_text('utf8')
doc=doc.replace('（补漏第三版）','（官方用词补漏第四版）').replace('升级到第三版','升级到第四版')
doc=doc.replace('本工具修改的17个文件','本工具修改的18个文件').replace('上述17个文件','上述18个文件').replace('第三版17个安装文件','第四版18个安装文件').replace('17个原始备份及17个候选','18个原始备份及18个候选')
doc=doc.replace('## 第三版精确修正','''## 第四版：SDK 官方简体词汇

已替换 `Plugins/mj_sdk/union_pcsdk.dll` 内繁体 Qt QM 显示资源；选择语言身份仍为zh_TW，区服、接口和代码字节不变。

- SDK译文143项：31项与国服同键同译、7项使用国服同键官方用词、99项使用台服SDK自带官方简体译文。
- 6项涉及台服邮件/国服短信验证差别、占位符或协议范围，保留台服功能语义的官方简体文案，不能声称与国服逐字一致。
- 登录状态为“欢迎回来”“切换账号”，已核对国服LoginSucceedWnd实际译文相同。
- DLL原签名Valid；修改内置资源后签名HashMismatch，未绕过任何验证。SDK能否被实际加载需要用户重启确认。若拒绝启动，应通过本BAT还原，不应关闭完整性检查。

## 第三版精确修正''')
old='截图中的“登入成功 / 切換帳號”仍在追踪来源，本版尚未确认覆盖，不能称为全部汉化。其他未检查界面、独立字体及图片也可能存在遗漏。'
new='截图中的“登入成功 / 切換帳號”已确认为SDK内嵌Qt译文，第四版已按上述官方简体词汇替换，实际加载待验证。远端公告词汇、无国服同项的台服内容、其他未检查界面及图片仍有覆盖边界，不能称为全部一致。'
doc=doc.replace(old,new).replace('`work/official_game_patch_v3`','`work/official_game_patch_v3`、`work/official_game_patch_v4`')
doc+='''

## 国服文案严格审计

当前357表470989行中，470960行与国服同table+ID文字完全一致；26行台服独有；3行差异均为既有备案保留和第三版两项精确转简修正。剧情命名7表和选项命名4表未发现共同ID差异。StaticText的2642共同key逐字一致；590项台服独有，其中150项在国服其他key/ID可找到同文，但同文不等于语义对应。

完整清单位于 `work/official_parity_audit`。这是本地资源审计，不替代实际游玩。
'''
docpath.write_text(doc,'utf8')
print(json.dumps(dict(revision=4,verified_files=len(plan['files']),runtime_verified=False),ensure_ascii=True),flush=True)
