$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$script:regions = ConvertFrom-Json '__REGION_CONFIG__'
$script:candidates = @{}
$script:visited = @{}
$script:bundles = $null

function Get-BytesHash([byte[]]$bytes) {
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}
function Get-PathHash([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose(); $stream.Dispose() }
}
function Read-Answer([string]$prompt) {
    Write-Host $prompt -NoNewline
    $answer = [Console]::ReadLine()
    if ($null -eq $answer) { return '' }
    return $answer.Trim().Trim('"')
}
function Get-Subdirectories([string]$path) {
    return @(Get-ChildItem -LiteralPath $path -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) })
}
function Add-LauncherDirectory([string]$directory) {
    $archive = Join-Path $directory 'resources\app.asar'
    if (-not [IO.File]::Exists($archive)) { return }
    if ($script:candidates.ContainsKey($archive)) { return }
    foreach ($region in $script:regions) {
        $exe = Join-Path $directory $region.exe
        if (-not [IO.File]::Exists($exe)) { continue }
        try { $hash = Get-PathHash $archive } catch { continue }
        if ($hash -notin $region.known) { continue }
        $script:candidates[$archive] = [PSCustomObject]@{
            Archive = $archive; Exe = $exe; Directory = $directory; Region = $region
            Hash = $hash; State = $(if ($hash -eq $region.patched) { '已汉化' } elseif ($hash -eq $region.original) { '原版' } else { '旧版汉化' })
        }
        return
    }
}
function Add-Location([string]$hint) {
    if ([string]::IsNullOrWhiteSpace($hint)) { return }
    try {
        $path = [IO.Path]::GetFullPath(($hint.Trim().Trim('"') -replace ',\s*-?\d+$', ''))
        if ([IO.File]::Exists($path)) { $path = [IO.Path]::GetDirectoryName($path) }
        if ([IO.Path]::GetFileName($path) -eq 'resources') { $path = [IO.Path]::GetDirectoryName($path) }
        if (-not [IO.Directory]::Exists($path)) { return }
        Add-LauncherDirectory $path
        foreach ($child in @(Get-Subdirectories $path)) {
            Add-LauncherDirectory $child.FullName
            if ($child.Name -match '^\d+\.\d+\.\d+(?:\.\d+)?$|AzurPromilia|AZUPRO|Yostar|蓝色星原|藍色星原|^Games?$|^游戏$|^遊戲$') {
                foreach ($grandchild in @(Get-Subdirectories $child.FullName)) { Add-LauncherDirectory $grandchild.FullName }
            }
        }
    } catch { }
}
function Scan-Tree([string]$root, [int]$maxDepth, [int]$limit) {
    $queue = New-Object 'System.Collections.Generic.Queue[object]'
    $queue.Enqueue([PSCustomObject]@{ Path = $root; Depth = 0 })
    $count = 0
    while ($queue.Count -gt 0 -and $count -lt $limit) {
        $item = $queue.Dequeue()
        if ($script:visited.ContainsKey($item.Path)) { continue }
        $script:visited[$item.Path] = $true
        $count++
        Add-LauncherDirectory $item.Path
        if ($item.Depth -ge $maxDepth) { continue }
        if ([IO.File]::Exists((Join-Path $item.Path 'resources\app.asar'))) { continue }
        foreach ($child in @(Get-Subdirectories $item.Path)) {
            if ($child.Name -match '^(Windows|Users|ProgramData|AppData|\$.*|System Volume Information|Recovery|node_modules|\.git|resources|.*_Data|StreamingAssets|AssetBundles|Library|Temp|Cache)$') { continue }
            $queue.Enqueue([PSCustomObject]@{ Path = $child.FullName; Depth = $item.Depth + 1 })
        }
    }
}
function Find-Launchers {
    Write-Host '正在扫描台服、日服启动器安装路径……' -ForegroundColor Cyan
    if ($env:AZUR_PATCH_HINT) {
        # 指定路径时仅处理该路径中的安装，避免误选其他磁盘上的启动器。
        Add-Location $env:AZUR_PATCH_HINT
        if ([IO.Directory]::Exists($env:AZUR_PATCH_HINT)) { Scan-Tree $env:AZUR_PATCH_HINT 5 3000 }
    } else {
        $nearby = [IO.Path]::GetDirectoryName($env:AZUR_PATCH_SELF)
        for ($level = 0; $level -lt 3 -and $nearby; $level++) {
            Add-Location $nearby
            $parent = [IO.Directory]::GetParent($nearby)
            if ($null -eq $parent) { break }
            $nearby = $parent.FullName
        }
        try {
            foreach ($process in @(Get-CimInstance Win32_Process -Filter "Name = 'launcher.exe' OR Name = 'AZUPRO_JP_Gamelauncher.exe'")) { Add-Location $process.ExecutablePath }
        } catch { }
        foreach ($registry in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
            foreach ($key in @(Get-ChildItem -LiteralPath $registry -ErrorAction SilentlyContinue)) {
                $entry = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
                if ($entry.DisplayName -match 'AzurPromilia|AZUPRO|Yostar|アズールプロミリア|蓝色星原|藍色星原') {
                    Add-Location $entry.InstallLocation
                    Add-Location $entry.DisplayIcon
                }
            }
        }
        try {
            $shortcuts = New-Object -ComObject WScript.Shell
            foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('StartMenu'), [Environment]::GetFolderPath('CommonStartMenu'))) {
                if (-not $folder) { continue }
                foreach ($link in @(Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'AzurPromilia|AZUPRO|Yostar|アズールプロミリア|蓝色星原|藍色星原' })) {
                    Add-Location ($shortcuts.CreateShortcut($link.FullName).TargetPath)
                }
            }
        } catch { }
        foreach ($drive in [IO.DriveInfo]::GetDrives()) {
            if (-not $drive.IsReady -or $drive.DriveType -notin @([IO.DriveType]::Fixed, [IO.DriveType]::Removable)) { continue }
            Write-Host ('  扫描磁盘：' + $drive.RootDirectory.FullName)
            Scan-Tree $drive.RootDirectory.FullName 3 1800
        }
    }
    return @($script:candidates.Values | Sort-Object @{Expression = { $_.Region.order }}, Directory)
}
function Select-Copies([object[]]$items) {
    if ($items.Count -eq 0) { throw '没有找到该区服支持版本的启动器。' }
    if ($items.Count -eq 1) { return $items[0] }
    Write-Host '同一区服找到多个安装位置：'
    for ($i = 0; $i -lt $items.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i + 1), $items[$i].Directory) }
    Write-Host '  A. 该区服全部目录'
    $answer = Read-Answer '请选择目录编号或 A（Q 取消）：'
    if ($answer -eq 'q') { return }
    if ($answer -eq 'a') { return $items }
    $index = 0
    if (-not [int]::TryParse($answer, [ref]$index) -or $index -lt 1 -or $index -gt $items.Count) { throw '目录编号无效。' }
    return $items[$index - 1]
}
function Get-Bundles {
    if ($null -ne $script:bundles) { return $script:bundles }
    $text = [IO.File]::ReadAllText($env:AZUR_PATCH_SELF, [Text.Encoding]::UTF8)
    $base64 = ($text -split '(?m)^:__DATA__\r?$', 2)[1] -replace '\s', ''
    $compressed = [Convert]::FromBase64String($base64)
    $inputStream = New-Object IO.MemoryStream(,$compressed)
    $gzip = New-Object IO.Compression.GZipStream($inputStream, [IO.Compression.CompressionMode]::Decompress)
    $reader = New-Object IO.StreamReader($gzip, [Text.Encoding]::UTF8)
    try { $script:bundles = $reader.ReadToEnd() | ConvertFrom-Json }
    finally { $reader.Dispose(); $gzip.Dispose(); $inputStream.Dispose() }
    return $script:bundles
}
function Assert-Closed([object[]]$plans) {
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'launcher.exe' OR Name = 'AZUPRO_JP_Gamelauncher.exe'")
    foreach ($plan in $plans) {
        if (@($running | Where-Object { $_.ExecutablePath -eq $plan.Item.Exe }).Count -gt 0) {
            throw ('请先完全退出' + $plan.Item.Region.label + '启动器（包括托盘图标）：' + $plan.Item.Directory + '。尚未替换任何启动器。')
        }
    }
}
function Invoke-Selected([object[]]$items, [bool]$restore) {
    $plans = @()
    foreach ($item in $items) {
        $region = $item.Region
        $current = Get-PathHash $item.Archive
        if ($current -notin $region.known) { throw ('启动器文件已变化：' + $item.Directory) }
        $expected = $(if ($restore) { $region.original } else { $region.patched })
        if ($current -eq $expected) {
            Write-Host ('[' + $region.label + '] ' + $(if ($restore) { '当前已经是原版，无需还原。' } else { '当前已经是完整简体汉化版本。' })) -ForegroundColor Green
            continue
        }
        $backup = $item.Archive + '.before-zhcn-20261124.bak'
        if ([IO.File]::Exists($backup)) {
            if ((Get-PathHash $backup) -ne $region.original) { throw ('原版备份校验失败：' + $backup) }
        } elseif ($restore -or $current -ne $region.original) { throw ('未找到经过校验的原版备份：' + $backup) }
        $staging = $item.Archive + '.zhcn-combined.tmp'
        $rollback = $item.Archive + '.zhcn-combined.rollback'
        if ([IO.File]::Exists($staging) -or [IO.File]::Exists($rollback)) { throw ('发现上次遗留的临时文件，请先检查：' + $item.Directory) }
        $plans += [PSCustomObject]@{ Item = $item; Before = $current; Expected = $expected; Backup = $backup; Staging = $staging; Rollback = $rollback; Staged = $false; Committed = $false }
    }
    if ($plans.Count -eq 0) { return }
    Assert-Closed $plans
    try {
        # 全部目标先校验并生成临时文件，再替换，避免第二个启动器正在运行时只修改第一个。
        foreach ($plan in $plans) {
            $item = $plan.Item
            $region = $item.Region
            if (-not [IO.File]::Exists($plan.Backup)) { [IO.File]::Copy($item.Archive, $plan.Backup, $false) }
            if ((Get-PathHash $plan.Backup) -ne $region.original) { throw ('原版备份校验失败：' + $plan.Backup) }
            Write-Host ('[' + $region.label + '] 正在' + $(if ($restore) { '准备还原……' } else { '构建简体补丁……' }))
            if ($restore) {
                [IO.File]::Copy($plan.Backup, $plan.Staging, $false)
                $plan.Staged = $true
            } else {
                $bundle = (Get-Bundles).PSObject.Properties[$region.id].Value
                if ($null -eq $bundle) { throw '补丁数据缺失。' }
                $sourceBytes = [IO.File]::ReadAllBytes($plan.Backup)
                $stream = New-Object IO.MemoryStream
                try {
                    $header = [Convert]::FromBase64String($bundle.header)
                    $stream.Write($header, 0, $header.Length)
                    foreach ($operation in $bundle.operations) {
                        if ($null -ne $operation.data) {
                            $block = [Convert]::FromBase64String($operation.data)
                            $stream.Write($block, 0, $block.Length)
                        } else { $stream.Write($sourceBytes, [int]$operation.offset, [int]$operation.length) }
                    }
                    $bytes = $stream.ToArray()
                } finally { $stream.Dispose() }
                if ((Get-BytesHash $bytes) -ne $plan.Expected) { throw '补丁构建校验失败。' }
                $plan.Staged = $true
                [IO.File]::WriteAllBytes($plan.Staging, $bytes)
                $sourceBytes = $null; $bytes = $null
            }
            if ((Get-PathHash $plan.Staging) -ne $plan.Expected) { throw '临时文件校验失败。' }
        }
        Assert-Closed $plans
        foreach ($plan in $plans) {
            if ((Get-PathHash $plan.Item.Archive) -ne $plan.Before) { throw ('操作期间启动器文件已变化：' + $plan.Item.Directory) }
        }
        foreach ($plan in $plans) {
            [IO.File]::Replace($plan.Staging, $plan.Item.Archive, $plan.Rollback)
            $plan.Committed = $true
            if ((Get-PathHash $plan.Item.Archive) -ne $plan.Expected) { throw '替换后校验失败。' }
        }
    } catch {
        $failure = $_.Exception.Message
        for ($i = $plans.Count - 1; $i -ge 0; $i--) {
            $plan = $plans[$i]
            if ($plan.Committed) {
                try {
                    [IO.File]::Replace($plan.Rollback, $plan.Item.Archive, $plan.Staging)
                    if ((Get-PathHash $plan.Item.Archive) -ne $plan.Before) { throw '回退校验失败' }
                    $plan.Committed = $false
                } catch { Write-Host ('自动回退失败，请保留备份和临时文件：' + $plan.Item.Directory + '；' + $_.Exception.Message) -ForegroundColor Red }
            }
        }
        throw $failure
    } finally {
        foreach ($plan in $plans) {
            if ($plan.Staged -and [IO.File]::Exists($plan.Staging)) { [IO.File]::Delete($plan.Staging) }
        }
    }
    foreach ($plan in $plans) {
        if ([IO.File]::Exists($plan.Rollback)) { [IO.File]::Delete($plan.Rollback) }
        Write-Host ('[' + $plan.Item.Region.label + '] ' + $(if ($restore) { '已成功还原原版启动器。' } else { '简体汉化完成！' })) -ForegroundColor Green
        Write-Host ('  目录：' + $plan.Item.Directory)
        Write-Host ('  原版备份：' + $plan.Backup)
    }
}
function Invoke-Main {
    try { [Console]::Title = '蓝色星原 - 台服 / 日服启动器汉化与还原' } catch { }
    # 菜单文字：修改 Write-Host 引号内的显示内容即可，保存为 UTF-8。
    Write-Host '=================================================='
    Write-Host '       台服 / 日服启动器简体汉化与还原'
    Write-Host '=================================================='
    Write-Host '支持台服 1.0.1.4、日服 1.8.1。'
    $found = @(Find-Launchers)
    while ($found.Count -eq 0) {
        Write-Host '未找到支持版本，可手动指定游戏文件夹或启动器 EXE。' -ForegroundColor Yellow
        $manual = Read-Answer '请输入扫描路径（Q 退出）：'
        if (-not $manual -or $manual -eq 'q') { return }
        Add-Location $manual
        if ([IO.Directory]::Exists($manual)) { $script:visited = @{}; Scan-Tree $manual 5 3000 }
        $found = @($script:candidates.Values | Sort-Object @{Expression = { $_.Region.order }}, Directory)
    }
    Write-Host ''
    Write-Host '扫描结果：'
    foreach ($item in $found) { Write-Host ('  [' + $item.Region.label + ' / ' + $item.State + '] ' + $item.Directory) }
    $tw = @($found | Where-Object { $_.Region.id -eq 'tw' })
    $jp = @($found | Where-Object { $_.Region.id -eq 'jp' })
    Write-Host ''
    Write-Host ('  1. 台服汉化  ' + $(if ($tw.Count) { '（找到 ' + $tw.Count + ' 处）' } else { '（未发现）' }))
    Write-Host ('  2. 日服汉化  ' + $(if ($jp.Count) { '（找到 ' + $jp.Count + ' 处）' } else { '（未发现）' }))
    Write-Host '  3. 全部汉化'
    Write-Host '  4. 还原'
    Write-Host '  Q. 退出'
    Write-Host ''
    $action = Read-Answer '请输入选项并按回车：'
    $selected = @(); $restore = $false
    switch ($action) {
        'q' { return }
        '1' { $selected = @(Select-Copies $tw) }
        '2' { $selected = @(Select-Copies $jp) }
        '3' { $selected = $found }
        '4' {
            $restore = $true
            if ($tw.Count -and $jp.Count) {
                Write-Host ''; Write-Host '还原范围：'
                Write-Host '  1. 还原台服'; Write-Host '  2. 还原日服'; Write-Host '  3. 全部还原'
                $scope = Read-Answer '请选择还原范围（Q 取消）：'
                switch ($scope) {
                    'q' { return }
                    '1' { $selected = @(Select-Copies $tw) }
                    '2' { $selected = @(Select-Copies $jp) }
                    '3' { $selected = $found }
                    default { throw '还原范围无效。' }
                }
            } else { $selected = @(Select-Copies $found) }
        }
        default { throw '请输入 1、2、3、4 或 Q。' }
    }
    if ($selected.Count -gt 0) { Invoke-Selected $selected $restore }
}
$exitCode = 0
try { Invoke-Main }
catch { Write-Host ('操作停止：' + $_.Exception.Message) -ForegroundColor Red; $exitCode = 1 }
Write-Host ''
$null = Read-Answer '按回车关闭窗口……'
exit $exitCode
