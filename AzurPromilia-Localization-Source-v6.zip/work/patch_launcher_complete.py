import ast,hashlib,json,re,struct,sys,copy,shutil
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent
sys.path.insert(0,str(HERE/'analysis_deps'))
from opencc import OpenCC
from patch_launcher_language import parse,entries,member_data,sha
TARGET=Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar')
BACKUP=TARGET.with_name('app.asar.before-zhcn-20261124.bak')
CN=Path(r'D:\AzurPromilia\1.0.1.1\resources\app.asar')
MEMBER='_next/static/chunks/327-2adec23307eb9076.js'
PREPARED=HERE/'launcher_complete.app.asar'
MANIFEST=HERE/'launcher_complete_patch.json'
def prepare():
 original=BACKUP.read_bytes(); assert sha(original)=='30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa'
 h,_,base=parse(original); allentries=dict(entries(h))
 old={k:member_data(original,v,base) for k,v in allentries.items() if 'offset' in v}
 official=json.loads((HERE/'launcher_cn/dictionaries.json').read_text('utf-8'))
 tw=official['9500'];cn=official['8096']; cc=OpenCC('t2s')
 # Preserve regional agreement meaning and links, including deliberately empty entries.
 localized={k:(cc.convert(v) if not v or not cn.get(k) or 'AGREEMENT' in k else cn[k]) for k,v in tw.items()}
 for k,v in localized.items():
  assert sorted(re.findall(r'\{\d+\}',v))==sorted(re.findall(r'\{\d+\}',tw[k])),k
  assert bool(v)==bool(tw[k]),k
 chunk=old[MEMBER].decode('utf-8')
 pat=r'9500:function\(e\)\{"use strict";e.exports=JSON.parse\((\x27(?:\\.|[^\x27\\])*\x27)\)\}'
 m=re.search(pat,chunk);assert m
 literal=json.dumps(localized,ensure_ascii=False,separators=(',',':'))
 js_literal=json.dumps(literal,ensure_ascii=False)
 chunk=chunk[:m.start(1)]+js_literal+chunk[m.end(1):]
 updates={MEMBER:chunk.encode()}
 main=old['main.js'].decode('utf-8')
 assert main.count('title:c.JB,')==1 and main.count('setToolTip(c.JB)')==1
 main=main.replace('title:c.JB,','title:"蓝色星原：旅谣",').replace('setToolTip(c.JB)','setToolTip("蓝色星原：旅谣")')
 updates['main.js']=main.encode()
 maps={}
 for label,name in [('PHRASES','TSPhrases.txt'),('CHARACTERS','TSCharacters.txt')]:
  table={}
  for line in (HERE/'analysis_deps/opencc/dictionary'/name).read_text('utf-8').splitlines():
   if not line or line.startswith('#'):continue
   source,destination=line.split('\t');table[source]=destination.split(' ')[0]
  maps[label]=table
 display=(HERE/'launcher_display_template.js').read_text('utf-8')
 for label,table in maps.items():display=display.replace('__'+label+'__',json.dumps(table,ensure_ascii=False,separators=(',',':')))
 updates['launcher-zhcn-display.js']=display.encode()
 updates['preload.js']=old['preload.js']+b'\n// Simplified Chinese display layer.\nrequire("./launcher-zhcn-display.js");\n'
 h=copy.deepcopy(h);h['files']['launcher-zhcn-display.js']={'size':0,'offset':'0'}
 payload=bytearray()
 for name,entry in entries(h):
  if 'offset' not in entry:continue
  data=updates.get(name,old.get(name));assert data is not None
  entry['offset']=str(len(payload));entry['size']=len(data)
  blocksize=entry.get('integrity',{}).get('blockSize',4194304)
  entry['integrity']={'algorithm':'SHA256','hash':sha(data),'blockSize':blocksize,'blocks':[sha(data[i:i+blocksize]) for i in range(0,len(data),blocksize)]}
  payload.extend(data)
 header=json.dumps(h,ensure_ascii=False,separators=(',',':')).encode()
 padding=(-len(header))%4
 headerpickle=struct.pack('<II',4+len(header)+padding,len(header))+header+b'\0'*padding
 result=struct.pack('<II',4,len(headerpickle))+headerpickle+payload
 hh,_,bb=parse(result); ee=dict(entries(hh))
 for name,entry in ee.items():
  if 'offset' not in entry:continue
  data=member_data(result,entry,bb);assert data==updates.get(name,old.get(name)),name
  assert sha(data)==entry['integrity']['hash']
 for name,data in updates.items():
  path=HERE/'launcher_complete_files'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 PREPARED.write_bytes(result)
 manifest={'target':str(TARGET),'official_reference':str(CN),'official_reference_sha256':sha(CN.read_bytes()),'original_sha256':sha(original),'previous_partial_sha256':sha(TARGET.read_bytes()),'patched_sha256':sha(result),'backup':str(BACKUP),'changed_members':list(updates),'dictionary_keys':len(localized),'official_simplified_keys':sum(bool(tw[k] and cn[k]) and 'AGREEMENT' not in k for k in tw),'fallback_keys':[k for k,v in tw.items() if v and not cn[k]],'images_changed':False,'regional_configuration_changed':False,'applied':False}
 MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False,indent=2))
def apply():
 m=json.loads(MANIFEST.read_text('utf-8'))
 assert sha(TARGET.read_bytes())==m['previous_partial_sha256']
 assert sha(BACKUP.read_bytes())==m['original_sha256']
 assert sha(PREPARED.read_bytes())==m['patched_sha256']
 temp=TARGET.with_name('app.asar.complete-zhcn.tmp');assert not temp.exists()
 shutil.copy2(PREPARED,temp);temp.replace(TARGET)
 assert sha(TARGET.read_bytes())==m['patched_sha256']
 m['applied']=True;MANIFEST.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Applied',m['patched_sha256'])
if __name__=='__main__': {'prepare':prepare,'apply':apply}[sys.argv[1]]()
