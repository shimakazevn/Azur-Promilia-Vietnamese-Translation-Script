from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v5';STABLE=ROOT/'work/official_game_patch'
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'))
data=Path(plan['data_root']);backup=data.parent/'.zhcn-official-3221745-backup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in plan['files']:
 assert sha(data/f['relative_path'])==f['target_sha256'],f['relative_path']
 assert sha(backup/f['relative_path'])==f['source_sha256'],f['relative_path']
 assert sha(Path(f['candidate']))==f['target_sha256'],f['relative_path']
for f in plan['required_unchanged_files']:assert sha(data/f['relative_path'])==f['sha256']
archive=STABLE/'deployment-plan.v4.json'
if not archive.exists():
 assert json.loads((STABLE/'deployment-plan.json').read_text('utf8'))['patch_revision']==4
 archive.write_bytes((STABLE/'deployment-plan.json').read_bytes())
for name in ['deployment-plan.json','Apply-OfficialZH.ps1']:
 t=STABLE/(name+'.stage');t.write_bytes((OUT/name).read_bytes());t.replace(STABLE/name)
report=dict(applied=True,patch_revision=5,applied_at=datetime.datetime.now().astimezone().isoformat(),
 installed_files_verified=len(plan['files']),original_backups_verified=len(plan['files']),candidates_verified=len(plan['files']),
 language='cht',runtime_verified=False,backup_directory=str(backup),ui_v2=plan['ui_v2'],residual_v3=plan['residual_v3'],
 official_parity_v4=plan['official_parity_v4'],official_parity_v5=plan['official_parity_v5'],verified_files=[f['relative_path'] for f in plan['files']])
for p in [OUT/'installed-verification.json',STABLE/'installed-verification.json',ROOT/'outputs/台服游戏官方简体应用记录.json']:
 p.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
dp=ROOT/'outputs/台服游戏官方简体替换说明.md';doc=dp.read_text('utf8')
doc=doc.replace('（官方用词补漏第四版）','（官方用词补漏第五版）').replace('升级到第四版','升级到第五版')
doc=doc.replace('本工具修改的18个文件','本工具修改的19个文件').replace('上述18个文件','上述19个文件').replace('第四版18个安装文件','第五版19个安装文件').replace('18个原始备份及18个候选','19个原始备份及19个候选')
doc=doc.replace('## 第四版：SDK 官方简体词汇','''## 第五版：登录程序与官方专用字形

- 第四版重启后登录条仍为原文：查明独立登录程序 `Plugins/mj_sdk/sdkbrowser.exe` 也内嵌同一套 zh_TW 译文。第五版写入与 SDK DLL 相同的143项官方简体译文（“欢迎回来／切换账号”），代码段字节不变；修改后签名为 HashMismatch，未绕过任何验证，需要重启确认。
- 字体显示映射误改了两处官方原文用字，现已在三套字体中恢复原字形：剧情“逆转**乾**坤功”（之前显示为“干”）、活动页“桃**箋**缘”。“闇星庇佑”的“闇”继续保留。
- 宠物说明里的默认繁体占位文字和商店的日文占位文字，在国服预制体里也是同样内容，运行时会被语言表覆盖，因此没有恢复这些字的原字形，以免影响远端繁体文字的显示。

## 第四版：SDK 官方简体词汇''')
doc+='''

## 第五版补充审计

- UI 预制体直写文字：4365个资源段全部扫描，1917段含文字，18719个字段按对象ID+字段与国服逐一比对，全部一致，没有缺少对应项的字段。
- 字体映射影响审计：覆盖主表176513条非空文本、StaticText 3232条、启动CSV 112条、UI直写18719条。只有“乾”“箋”“闇”三个字出现在需要保留原字的官方正文里，均已处理。
- 仍未解决：远端公告由服务器下发繁体（例如“伺服器”），客户端没有可验证、可安全修改的显示处理入口，目前只有字形转简，用词未替换；台服独有的26行语言表和590项StaticText没有同ID国服来源，已做字形转简。

清单位于 `work/official_parity_audit`（serialized-ui-differences.json、serialized-ui-no-counterpart.json、font-official-wording-impact-full.json）。
'''
doc=doc.replace('`work/official_game_patch_v4`','`work/official_game_patch_v4`、`work/official_game_patch_v5`')
dp.write_text(doc,'utf8')
print(json.dumps(dict(revision=5,verified=len(plan['files'])),ensure_ascii=True))