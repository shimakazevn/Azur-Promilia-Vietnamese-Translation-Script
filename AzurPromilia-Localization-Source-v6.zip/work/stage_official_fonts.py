from pathlib import Path
import sys,json,struct,hashlib,zlib,gc
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'work/game_compare_manifests'))
from parse_manifest import parse
from patch_manifest import encode_name
from patch_manifest_dependencies import extend_dependencies
OUT=ROOT/'work/official_game_patch'
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(x):print(json.dumps(x,ensure_ascii=True),flush=True)

def main():
 text=json.loads((OUT/'text-build-report.json').read_text('utf8'))
 fonts=json.loads((ROOT/'work/game_decrypt_bundle/font-deployment-plan.json').read_text('utf8'))
 deps=json.loads((ROOT/'work/game_decrypt_bundle/font_dependencies.json').read_text('utf8'))
 assert fonts['coverage']['combinedMissingCount']==0
 data=Path(text['data_root']);files=list(text['files']);manifests={};fontreports=[]
 for item in fonts['plans']:
  source=Path(item['installPath']);original=source.read_bytes();candidate=Path(item['candidatePath']).read_bytes()
  assert sha(original)==item['installedSha256'];assert sha(candidate)==item['candidateSha256']
  oldsize=item['oldFirstBundleSize'];newsize=item['newFirstBundleSize']
  assert original[oldsize:]==candidate[newsize:]
  assert struct.unpack_from('>Q',candidate,24)[0]==newsize
  rel=source.relative_to(data);target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(candidate)
  files.append(dict(relative_path=rel.as_posix(),source_sha256=sha(original),target_sha256=sha(candidate),size=len(candidate),candidate=str(target)))
  assert item['manifests'],item['name']
  for ref in item['manifests']:manifests.setdefault(ref['manifest'],[]).append((item,original,candidate,ref))
 for name,replacements in manifests.items():
  source=Path(name);raw=source.read_bytes();m=parse(raw);changed=bytearray(raw);allowed=bytearray(len(raw))
  for item,original,candidate,ref in replacements:
   packindex=ref['packIndex'];pack=m['packs'][packindex]
   assert encode_name(pack['name0'],pack['name1']) in (Path(item['installPath']).name,Path(item['installPath']).stem)
   assert (pack['size'],pack['crc'])==(len(original),zlib.crc32(original))
   bundles=sorted([(i,b) for i,b in enumerate(m['bundles']) if b['pack_id']==packindex],key=lambda x:x[1]['offset'])
   assert len(bundles)==len(ref['bundles'])
   shift=item['newFirstBundleSize']-item['oldFirstBundleSize']
   assert bundles[0][1]['offset']==0 and bundles[0][1]['size']==item['oldFirstBundleSize']
   for ordinal,(i,b) in enumerate(bundles):
    oldseg=original[b['offset']:b['offset']+b['size']]
    assert len(oldseg)==b['size'] and zlib.crc32(oldseg)==b['crc']
    offset=0 if ordinal==0 else b['offset']+shift
    size=item['newFirstBundleSize'] if ordinal==0 else b['size']
    segment=candidate[offset:offset+size]
    assert len(segment)==size
    if ordinal:assert segment==oldseg
    pos=m['bundle_count_offset']+4+i*56
    struct.pack_into('<qI',changed,pos,size,zlib.crc32(segment));allowed[pos:pos+12]=b'\1'*12
    struct.pack_into('<q',changed,pos+36,offset);allowed[pos+36:pos+44]=b'\1'*8
   pos=m['pack_count_offset']+4+packindex*48
   struct.pack_into('<q',changed,pos+32,len(candidate));allowed[pos+32:pos+40]=b'\1'*8
   struct.pack_into('<I',changed,pos+44,zlib.crc32(candidate));allowed[pos+44:pos+48]=b'\1'*4
   fontreports.append(dict(name=item['name'],manifest=name,pack_index=packindex,bundles=len(bundles),tail_preserved=item['preservedTailBytes']))
  assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(raw,changed)))
  del m;gc.collect()
  dep=next(x for x in deps if x['manifest']==name)
  changed,_,dependency_report=extend_dependencies(bytes(changed),dep['target']['bundleIndex'],dep['additionalDependencyClosure'],dep['neededDirectDependencyIndices'],new_direct_count=4)
  check=parse(changed);a=check['assets'][dep['target']['asset']['index']]
  closure=check['asset_depend_pool'][a['depend_start']:a['depend_start']+a['depend_count']]
  assert closure==dep['recommendedDependencyClosure']
  del check;gc.collect()
  fontreports.append(dict(manifest=name,dependency_report=dependency_report))
  hp=source.with_suffix('.hash');assert hp.read_bytes()==hashlib.md5(raw).hexdigest().encode()
  for src,new in [(source,bytes(changed)),(hp,hashlib.md5(changed).hexdigest().encode())]:
   rel=src.relative_to(data);target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(new)
   files.append(dict(relative_path=rel.as_posix(),source_sha256=sha(src.read_bytes()),target_sha256=sha(new),size=len(new),candidate=str(target)))
  emit(dict(stage='font_manifest_verified',manifest=name,replacements=len(replacements)))
 expected_resources='5c1af532a79dbae32a297418c0782447960142e8c95d28bbfb099b5301206b25'
 assert sha((data/'resources.assets').read_bytes())==expected_resources
 result={**text,'files':files,'font_manifests':fontreports,'font_coverage':fonts['coverage'],'runtime_tested':False,'language':'cht','required_unchanged_files':[dict(relative_path='resources.assets',sha256=expected_resources)]}
 (OUT/'deployment-plan.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
 emit(dict(stage='all_resources_staged',files=len(files),total_bytes=sum(x['size'] for x in files)))
if __name__=='__main__':main()
