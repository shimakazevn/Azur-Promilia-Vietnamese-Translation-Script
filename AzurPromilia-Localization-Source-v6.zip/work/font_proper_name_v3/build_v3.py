from pathlib import Path
import sys,io,json,struct,hashlib
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_decrypt_bundle'),str(BASE/'game_compare_manifests'),str(BASE/'analysis_deps')]
from unity_setup import UnityPy
from reencrypt_bundle import wrap
from fontTools.ttLib import TTFont
from parse_manifest import parse
from patch_manifest import encode_name
OUT=Path(__file__).resolve().parent
ROOT=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
spec=[('a00',ROOT/'StreamingAssets/.res/default_package/a66pm5ie1rrjguuzlsyq.r','cn_a00.otf'),('c00',ROOT/'StreamingAssets/.res/default_package/p4hifvtlpthiunufa1lslg.r','official_chs_c00.otf'),('b00',ROOT/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r','cn_b00.otf')]
manifestpaths=[ROOT/'StreamingAssets/.res/default_package/0release_default_package_3060618.bytes',ROOT/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes']
manifests=[(p,parse(p)) for p in manifestpaths];report=[]
for name,p,official in spec:
 raw=p.read_bytes();size=struct.unpack_from('>Q',raw,24)[0];segment=raw[:size];env=UnityPy.load(segment);bundle=next(iter(env.files.values()));before={o.path_id:o.get_raw_data() for o in env.objects}
 obj=next(o for o in env.objects if o.type.name=='Font' and o.read_typetree()['m_Name']==name);tree=obj.read_typetree();oldfont=TTFont(io.BytesIO(bytes(tree['m_FontData'])));font=TTFont(io.BytesIO(bytes(tree['m_FontData'])));original=TTFont(BASE/'game_decrypt_bundle'/official)
 cp=0x95c7;glyph=original.getBestCmap()[cp];expected='cid43780' if name=='c00' else 'cid25996';assert glyph==expected,(glyph,expected)
 oldmaps=[dict(t.cmap) if hasattr(t,'cmap') else None for t in font['cmap'].tables];changedtables=[]
 for index,t in enumerate(font['cmap'].tables):
  if t.isUnicode() and hasattr(t,'cmap'):
   t.cmap[cp]=glyph;changedtables.append(index)
 data=io.BytesIO();font.save(data);newbytes=data.getvalue();checkfont=TTFont(io.BytesIO(newbytes));assert checkfont.getBestCmap()[cp]==glyph
 for index,t in enumerate(checkfont['cmap'].tables):
  if oldmaps[index] is not None:
   assert {k:v for k,v in t.cmap.items() if k!=cp}=={k:v for k,v in oldmaps[index].items() if k!=cp}
 assert oldfont.getGlyphOrder()==checkfont.getGlyphOrder()
 a=oldfont['CFF '].cff.topDictIndex[0].CharStrings;b=checkfont['CFF '].cff.topDictIndex[0].CharStrings
 for g in oldfont.getGlyphOrder():
  x=a[g];y=b[g];x.decompile();y.decompile();assert x.program==y.program
 tree['m_FontData']=list(newbytes);obj.save_typetree(tree);plain=bundle.save(packer='lz4');candidate,nblocks=wrap(plain,segment);dest=OUT/(name+'_proper_name_segment.r');dest.write_bytes(candidate)
 check=UnityPy.load(candidate);after={o.path_id:o.get_raw_data() for o in check.objects};assert [i for i in before if before[i]!=after[i]]==[obj.path_id]
 reloaded=next(o for o in check.objects if o.path_id==obj.path_id).read_typetree();assert bytes(reloaded['m_FontData'])==newbytes
 refs=[]
 for mp,m in manifests:
  for pi,pack in enumerate(m['packs']):
   if encode_name(pack['name0'],pack['name1'])!=p.name:continue
   for bi,bundleinfo in enumerate(m['bundles']):
    if bundleinfo['pack_id']==pi and bundleinfo['offset']==0:
     assert bundleinfo['size']==size
     refs.append({'manifestPath':str(mp),'bundleIndex':bi,'packIndex':pi,'offset':0,'oldSize':size,'sourceSizeMatches':True})
 report.append({'sourcePack':str(p),'currentSHA256':hashlib.sha256(raw).hexdigest(),'offset':0,'oldSize':size,'segmentCandidate':str(dest),'candidateSize':len(candidate),'candidateSHA256':hashlib.sha256(candidate).hexdigest(),'mutations':[{'type':'Font','pathId':obj.path_id,'name':name,'unicode':'U+95C7','oldGlyph':oldfont.getBestCmap()[cp],'newGlyph':glyph}],'manifests':refs,'unrelatedObjectBytesPreserved':True,'allOtherCmapEntriesPreserved':True,'allGlyphOutlineProgramsPreserved':True,'glyphOrderPreserved':True,'fontDataReloadVerified':True,'blockRoundtrips':nblocks})
(OUT/'segment-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
