param(
    [ValidateSet('Menu','Apply','Restore','Verify')][string]$Action = 'Menu',
    [string]$PlanPath = (Join-Path $PSScriptRoot 'deployment-plan.json')
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
$dataRoot = [IO.Path]::GetFullPath($plan.data_root)
$backupRoot = Join-Path (Split-Path $dataRoot -Parent) '.zhcn-official-3221745-backup'
function Get-Sha([string]$Path) {
    $stream=[IO.File]::OpenRead($Path)
    $algorithm=[Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
function Assert-GameClosed {
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'")
    if ($running.Count -gt 0) { throw '游戏正在运行，请退出游戏后再执行。' }
}
function Resolve-Target($entry) {
    $p = [IO.Path]::GetFullPath((Join-Path $dataRoot $entry.relative_path))
    if (-not $p.StartsWith($dataRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw '补丁路径超出游戏目录。' }
    return $p
}
function Replace-Checked([string]$Source,[string]$Target,[string]$Expected) {
    $temp = $Target + '.zhcn-stage-' + [Guid]::NewGuid().ToString('N')
    try {
        [IO.File]::Copy($Source,$temp,$false)
        if ((Get-Sha $temp) -ne $Expected) { throw "暂存文件校验失败：$Target" }
        [IO.File]::Replace($temp,$Target,[System.Management.Automation.Language.NullString]::Value)
        if ((Get-Sha $Target) -ne $Expected) { throw "写入后校验失败：$Target" }
    } finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
}
function New-Snapshot($Entries) {
    $snapshot=@{paths=@{};hashes=@{};root=(Join-Path $backupRoot ('rollback\'+[Guid]::NewGuid().ToString('N')))}
    foreach ($entry in $Entries) {
        $target=Resolve-Target $entry
        $hash=Get-Sha $target
        $path=Join-Path $snapshot.root $entry.relative_path
        [IO.Directory]::CreateDirectory((Split-Path $path -Parent)) | Out-Null
        [IO.File]::Copy($target,$path,$false)
        if ((Get-Sha $path) -ne $hash) { throw '事务快照校验失败，尚未写入游戏文件。' }
        $snapshot.paths[$entry.relative_path]=$path
        $snapshot.hashes[$entry.relative_path]=$hash
    }
    return $snapshot
}
function Verify-Patch {
    $result = foreach ($entry in $plan.files) {
        $target = Resolve-Target $entry
        $hash = Get-Sha $target
        $state = if ($hash -eq $entry.target_sha256) { '已汉化' } elseif ($hash -eq $entry.source_sha256) { '原资源' } elseif ($hash -in @($entry.previous_sha256)) { '上一版补丁' } else { '版本不匹配' }
        [PSCustomObject]@{状态=$state;文件=$entry.relative_path}
    }
    $result | Format-Table -AutoSize
    return
}
function Apply-Patch {
    Assert-GameClosed
    foreach ($required in $plan.required_unchanged_files) {
        if ((Get-Sha (Resolve-Target $required)) -ne $required.sha256) { throw "语言配置或客户端版本已改变，已停止：$($required.relative_path)" }
    }
    $states = @($plan.files | ForEach-Object { Get-Sha (Resolve-Target $_) })
    $allPatched = $true
    for ($i=0;$i -lt $states.Count;$i++) { if ($states[$i] -ne $plan.files[$i].target_sha256) { $allPatched=$false } }
    if ($allPatched) { Write-Host '官方简体试验补丁已经应用。'; return }
    $toWrite=@()
    foreach ($entry in $plan.files) {
        $current=Get-Sha (Resolve-Target $entry)
        $allowed=@($entry.source_sha256,$entry.target_sha256)+@($entry.previous_sha256)
        if ($current -notin $allowed) { throw "资源版本不匹配，已停止：$($entry.relative_path)" }
        if ((Get-Sha $entry.candidate) -ne $entry.target_sha256) { throw "补丁文件校验失败：$($entry.relative_path)" }
        if ($current -ne $entry.target_sha256) { $toWrite += $entry }
    }
    # Complete and verify every backup before the first installed-file write.
    foreach ($entry in $plan.files) {
        $backup = Join-Path $backupRoot $entry.relative_path
        if (Test-Path -LiteralPath $backup) {
            if ((Get-Sha $backup) -ne $entry.source_sha256) { throw "原始备份不匹配：$backup" }
        } else {
            if ((Get-Sha (Resolve-Target $entry)) -ne $entry.source_sha256) { throw "缺少原版备份，无法安全升级：$($entry.relative_path)" }
            [IO.Directory]::CreateDirectory((Split-Path $backup -Parent)) | Out-Null
            [IO.File]::Copy((Resolve-Target $entry),$backup,$false)
            if ((Get-Sha $backup) -ne $entry.source_sha256) { throw "备份校验失败：$backup" }
        }
    }
    $snapshot=New-Snapshot $toWrite
    Assert-GameClosed
    $written = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($entry in $toWrite) {
            $written.Add($entry)
            Replace-Checked $entry.candidate (Resolve-Target $entry) $entry.target_sha256
        }
    } catch {
        $problem = $_
        $rollbackErrors = @()
        for ($i=$written.Count-1;$i -ge 0;$i--) {
            $entry=$written[$i]
            try {
                $before=$snapshot.hashes[$entry.relative_path]
                if ((Get-Sha (Resolve-Target $entry)) -ne $before) {
                    Replace-Checked $snapshot.paths[$entry.relative_path] (Resolve-Target $entry) $before
                }
            } catch { $rollbackErrors += "$($entry.relative_path): $_" }
        }
        if ($rollbackErrors.Count) { throw "应用失败；部分回滚未完成，请保留备份：$problem；$($rollbackErrors -join '; ')" }
        throw "应用失败，已回滚：$problem"
    }
    Write-Host '已应用官方简体试验补丁。请启动台服检查菜单、剧情和道具文字。'
    Write-Host "原始资源备份：$backupRoot"
}
function Restore-Patch {
    Assert-GameClosed
    $toRestore=@()
    foreach ($entry in $plan.files) {
        $current=Get-Sha (Resolve-Target $entry)
        if ($current -notin (@($entry.source_sha256,$entry.target_sha256)+@($entry.previous_sha256))) { throw "资源已更新或被修改，已停止还原：$($entry.relative_path)" }
        if ($current -ne $entry.source_sha256) {
            if ((Get-Sha (Join-Path $backupRoot $entry.relative_path)) -ne $entry.source_sha256) { throw '原始备份校验失败。' }
            $toRestore += $entry
        }
    }
    $snapshot=New-Snapshot $toRestore
    Assert-GameClosed
    $restored = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($entry in $toRestore) {
            $restored.Add($entry)
            Replace-Checked (Join-Path $backupRoot $entry.relative_path) (Resolve-Target $entry) $entry.source_sha256
        }
    } catch {
        $problem=$_
        $rollbackErrors = @()
        for ($i=$restored.Count-1;$i -ge 0;$i--) {
            $entry=$restored[$i]
            try {
                $before=$snapshot.hashes[$entry.relative_path]
                if ((Get-Sha (Resolve-Target $entry)) -ne $before) {
                    Replace-Checked $snapshot.paths[$entry.relative_path] (Resolve-Target $entry) $before
                }
            } catch { $rollbackErrors += "$($entry.relative_path): $_" }
        }
        if ($rollbackErrors.Count) { throw "还原失败；部分回滚未完成，请保留备份：$problem；$($rollbackErrors -join '; ')" }
        throw "还原失败，已回滚至汉化状态：$problem"
    }
    Write-Host '已还原本次修改前的游戏资源。'
}
try {
    if ($Action -eq 'Menu') {
        Write-Host '========================================'
        Write-Host '  台服游戏官方简体替换试验 / 还原'
        Write-Host '========================================'
        Write-Host "目标：$($plan.game_root)"
        Write-Host '1. 应用官方简体文字与字体'
        Write-Host '2. 还原本次修改'
        Write-Host '3. 检查当前状态'
        Write-Host 'Q. 退出'
        $choice=Read-Host '请选择'
        $Action=switch ($choice) { '1' {'Apply'} '2' {'Restore'} '3' {'Verify'} default {return} }
    }
    switch ($Action) { 'Apply' {Apply-Patch} 'Restore' {Restore-Patch} 'Verify' {Verify-Patch} }
} catch { Write-Host $_ -ForegroundColor Red; exit 1 }
