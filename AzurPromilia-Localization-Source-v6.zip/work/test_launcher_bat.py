import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
fixture=ROOT/'bat_qa'/'游戏 测试 & 路径'
version=fixture/'1.0.1.4';resources=version/'resources';resources.mkdir(parents=True,exist_ok=True)
exe=version/'launcher.exe'
if not exe.exists():exe.write_bytes(b'Test fixture only; never executed.')
source=Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak')
target=resources/'app.asar';backup=resources/'app.asar.before-zhcn-20261124.bak'
shutil.copy2(source,target)
if backup.exists():
 assert hashlib.sha256(backup.read_bytes()).hexdigest()=='30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa'
bat=fixture/'汉化工具 & 测试.bat'
shutil.copy2(ROOT.parent/'outputs'/'启动器简体汉化与还原.bat',bat)
original='30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa'
patched='42a6240ba33f793c247fb44cd5fdf211670a9256c09513366155277912393a47'
checks=[]
def run(action,expected,argument=None,success=True):
 command=f'cmd.exe /d /s /c ""{bat}"'+(f' "{argument}"' if argument else '')+'"'
 r=subprocess.run(command,input=action+'\n\n',encoding='utf-8',errors='replace',capture_output=True,cwd=fixture,timeout=60)
 text=r.stdout+r.stderr
 assert (r.returncode==0)==success,(r.returncode,text)
 assert 'is not recognized' not in text and '�' not in text,text
 assert '1. 汉化为简体中文' in text and '2. 还原原版启动器' in text and 'Q. 退出' in text,text
 assert expected in text,text
 checks.append({'action':action,'expect':expected,'exit_code':r.returncode,'output':text})
run('1','简体汉化完成！')
assert hashlib.sha256(target.read_bytes()).hexdigest()==patched
assert hashlib.sha256(backup.read_bytes()).hexdigest()==original
run('1','当前已经是完整简体汉化版本。')
run('2','已成功还原原版启动器。')
assert hashlib.sha256(target.read_bytes()).hexdigest()==original
run('Q','Q. 退出')
run('1','指定路径没有匹配的台服启动器',argument=r'D:\AzurPromilia',success=False)
shutil.copy2(ROOT.parent/'outputs'/'启动器简体汉化与还原.bat',fixture/'lf_only.bat')
# ASCII CMD stub is also safe when an editor changes CRLF to LF.
lf=fixture/'lf_only.bat';lf.write_bytes(lf.read_bytes().replace(b'\r\n',b'\n'))
bat=lf
run('Q','Q. 退出')
(ROOT/'bat_validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'cases':len(checks),'chinese_space_ampersand_path':True,'automatic_location':str(version),'auto_backup':True,'apply_restore_hashes':True,'refuse_cn_launcher':True,'lf_line_endings':True},ensure_ascii=False,indent=2))
