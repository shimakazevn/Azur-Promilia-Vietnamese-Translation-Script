import hashlib,json,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
here=Path(__file__).parent.resolve()
sys.path.insert(0,str(here/'analysis_deps'))
import UnityPy
target=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\resources.assets')
sources=[target.with_name(target.name+'.before-game-zhcn-20261124.bak'),here/'game_bootstrap_zhcn.resources.assets']
mapping=[]
for source in sources:
    before=source.read_bytes()
    assert before[818010:818013]==b'cht'
    after=before[:818010]+b'chs'+before[818013:]
    original=UnityPy.load(before); patched=UnityPy.load(after)
    originals={x.path_id:x for x in original.objects}
    assert len(originals)==len(patched.objects)
    for obj in patched.objects:
        old=originals[obj.path_id]
        if obj.path_id==216:
            cfg=json.loads(obj.read().m_Script); oldcfg=json.loads(old.read().m_Script)
            assert cfg['language']=='chs' and oldcfg['language']=='cht'
            cfg['language']='cht'; assert cfg==oldcfg
        else: assert obj.get_raw_data()==old.get_raw_data()
    assert sum(a!=b for a,b in zip(before,after))==1
    mapping.append(dict(before=hashlib.sha256(before).hexdigest(),after=hashlib.sha256(after).hexdigest(),source=str(source)))
ps=(here/'game_language_trial.ps1').read_text('utf-8').replace('__MAPPING__',json.dumps(mapping,separators=(',',':')).replace('\\','\\'))
stub=(here.parent/'outputs/台服日服启动器汉化与还原.bat').read_text('utf-8').split('\n:__SCRIPT__\n',1)[0]
output=here.parent/'outputs/台服游戏CHS语言切换与还原试验.bat'
output.write_bytes((stub+'\n:__SCRIPT__\n'+ps+'\n:__DATA__\n').replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
report=dict(target=str(target),language_offset=818010,config_changed=['language'],region_unchanged=True,other_objects_identical=True,full_localization_verified=False,variants=mapping,tool=str(output))
(here/'game_language_trial.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
