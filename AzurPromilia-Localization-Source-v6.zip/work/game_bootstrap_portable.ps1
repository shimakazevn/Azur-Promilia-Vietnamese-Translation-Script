$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$originalHash = '__ORIGINAL_HASH__'
$patchedHash = '__PATCHED_HASH__'
$script:found = @{}
function Get-Hash([byte[]]$bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $h.Dispose() }
}
function Read-Answer([string]$prompt) {
    Write-Host $prompt -NoNewline
    $answer = [Console]::ReadLine()
    if ($null -eq $answer) { return '' }
    return $answer.Trim().Trim('"')
}
function Add-Game([string]$hint) {
    if (-not $hint) { return }
    try {
        $path = [IO.Path]::GetFullPath($hint.Trim().Trim('"'))
        if ([IO.File]::Exists($path)) { $path = [IO.Path]::GetDirectoryName($path) }
        if ([IO.Path]::GetFileName($path) -eq 'AzurPromilia_Data') { $path = [IO.Path]::GetDirectoryName($path) }
        $roots = @($path, (Join-Path $path 'AzurPromilia_TC_game'))
        foreach ($game in $roots) {
            $archive = Join-Path $game 'AzurPromilia_Data\resources.assets'
            if ([IO.File]::Exists((Join-Path $game 'AzurPromilia.exe')) -and [IO.File]::Exists($archive) -and -not $script:found.ContainsKey($archive)) {
                $hash = Get-Hash ([IO.File]::ReadAllBytes($archive))
                if ($hash -in @($originalHash, $patchedHash)) {
                    $script:found[$archive] = [PSCustomObject]@{ Root = $game; Archive = $archive; Hash = $hash }
                }
            }
        }
    } catch { }
}
function Invoke-Patch {
    try { [Console]::Title = '台服游戏启动文本 - 简体试验补丁' } catch { }
    # 菜单文字：这里只覆盖启动文本，尚不覆盖剧情、道具、技能与完整游戏界面。
    Write-Host '=================================================='
    Write-Host '        台服游戏启动文本简体补丁（试验版）'
    Write-Host '=================================================='
    Write-Host '仅处理启动、更新、下载和早期错误提示。'
    Write-Host '剧情、道具、技能等完整文本尚未汉化。'
    Write-Host '请先退出台服游戏。'
    Write-Host ''
    Write-Host '  1. 应用启动文本简体补丁'
    Write-Host '  2. 还原游戏原文件'
    Write-Host '  Q. 退出'
    $action = Read-Answer '请选择：'
    if ($action -eq 'q') { return }
    if ($action -notin @('1', '2')) { throw '请输入 1、2 或 Q。' }
    if ($env:AZUR_PATCH_HINT) { Add-Game $env:AZUR_PATCH_HINT }
    else {
        $nearby = [IO.Path]::GetDirectoryName($env:AZUR_PATCH_SELF)
        for ($level = 0; $level -lt 3 -and $nearby; $level++) {
            Add-Game $nearby
            $parent = [IO.Directory]::GetParent($nearby)
            if ($null -eq $parent) { break }
            $nearby = $parent.FullName
        }
        foreach ($drive in [IO.DriveInfo]::GetDrives()) {
            if (-not $drive.IsReady -or $drive.DriveType -notin @([IO.DriveType]::Fixed, [IO.DriveType]::Removable)) { continue }
            Add-Game (Join-Path $drive.RootDirectory.FullName 'AzurPromilia_TC')
            Add-Game (Join-Path $drive.RootDirectory.FullName 'Games\AzurPromilia_TC')
        }
    }
    if ($script:found.Count -eq 0 -and -not $env:AZUR_PATCH_HINT) {
        Add-Game (Read-Answer '未自动找到，请输入台服游戏目录（Q 退出）：')
    }
    $found = @($script:found.Values | Sort-Object Root)
    if ($found.Count -eq 0) { throw '没有找到匹配的台服游戏原文件或本工具已修改的文件。' }
    $game = $found[0]
    if ($found.Count -gt 1) {
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i + 1), $found[$i].Root) }
        $answer = Read-Answer '请选择游戏目录编号：'
        $index = 0
        if (-not [int]::TryParse($answer, [ref]$index) -or $index -lt 1 -or $index -gt $found.Count) { throw '目录编号无效。' }
        $game = $found[$index - 1]
    }
    Write-Host ('目标：' + $game.Root) -ForegroundColor Cyan
    $bytes = [IO.File]::ReadAllBytes($game.Archive)
    $current = Get-Hash $bytes
    if ($current -notin @($originalHash, $patchedHash)) { throw '游戏文件已变化。' }
    $expected = $(if ($action -eq '1') { $patchedHash } else { $originalHash })
    if ($current -eq $expected) { Write-Host $(if ($action -eq '1') { '当前已经应用启动文本补丁。' } else { '当前已经是原文件。' }) -ForegroundColor Green; return }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'" | Where-Object { -not $_.ExecutablePath -or $_.ExecutablePath -eq (Join-Path $game.Root 'AzurPromilia.exe') })
    if ($running.Count) { throw '请先退出台服游戏，再运行本工具。' }
    $backup = $game.Archive + '.before-game-zhcn-20261124.bak'
    if ([IO.File]::Exists($backup)) {
        if ((Get-Hash ([IO.File]::ReadAllBytes($backup))) -ne $originalHash) { throw '原版备份校验失败。' }
    } elseif ($action -eq '1' -and $current -eq $originalHash) {
        [IO.File]::Copy($game.Archive, $backup, $false)
    } else { throw '缺少有效原版备份。' }
    if ((Get-Hash ([IO.File]::ReadAllBytes($backup))) -ne $originalHash) { throw '原版备份校验失败。' }
    if ($action -eq '2') { $result = [IO.File]::ReadAllBytes($backup) }
    else {
        $text = [IO.File]::ReadAllText($env:AZUR_PATCH_SELF, [Text.Encoding]::UTF8)
        $payload = [Convert]::FromBase64String((($text -split '(?m)^:__DATA__\r?$', 2)[1] -replace '\s', ''))
        $bundle = [Text.Encoding]::UTF8.GetString($payload) | ConvertFrom-Json
        $before = [Convert]::FromBase64String($bundle.before)
        $after = [Convert]::FromBase64String($bundle.after)
        $offset = [int]$bundle.offset
        if ($before.Length -ne $after.Length -or $offset -lt 0 -or $offset + $before.Length -gt $bytes.Length) { throw '补丁数据无效。' }
        $slice = New-Object byte[] $before.Length
        [Array]::Copy($bytes, $offset, $slice, 0, $before.Length)
        if ((Get-Hash $slice) -ne (Get-Hash $before)) { throw '原文校验失败。' }
        $result = $bytes.Clone()
        [Array]::Copy($after, 0, $result, $offset, $after.Length)
    }
    if ((Get-Hash $result) -ne $expected) { throw '结果校验失败。' }
    $staging = $game.Archive + '.game-zhcn.tmp'
    $rollback = $game.Archive + '.game-zhcn.rollback'
    if ([IO.File]::Exists($staging) -or [IO.File]::Exists($rollback)) { throw '存在上次临时文件，请先检查资源目录。' }
    try {
        [IO.File]::WriteAllBytes($staging, $result)
        if ((Get-Hash ([IO.File]::ReadAllBytes($staging))) -ne $expected) { throw '写入校验失败。' }
        $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'" | Where-Object { -not $_.ExecutablePath -or $_.ExecutablePath -eq (Join-Path $game.Root 'AzurPromilia.exe') })
        if ($running.Count) { throw '请先退出台服游戏，再运行本工具。' }
        if ((Get-Hash ([IO.File]::ReadAllBytes($game.Archive))) -ne $current) { throw '操作期间游戏文件已变化。' }
        [IO.File]::Replace($staging, $game.Archive, $rollback)
        if ((Get-Hash ([IO.File]::ReadAllBytes($game.Archive))) -ne $expected) {
            [IO.File]::Replace($rollback, $game.Archive, $staging)
            throw '替换后校验失败，已回退。'
        }
        [IO.File]::Delete($rollback)
    } finally { if ([IO.File]::Exists($staging)) { [IO.File]::Delete($staging) } }
    Write-Host $(if ($action -eq '1') { '启动文本简体补丁已应用。游戏实际显示效果待验证。' } else { '游戏原文件已还原。' }) -ForegroundColor Green
    Write-Host ('原版备份：' + $backup)
}
$exitCode = 0
try { Invoke-Patch }
catch { Write-Host ('操作停止：' + $_.Exception.Message) -ForegroundColor Red; $exitCode = 1 }
$null = Read-Answer '按回车关闭窗口……'
exit $exitCode
