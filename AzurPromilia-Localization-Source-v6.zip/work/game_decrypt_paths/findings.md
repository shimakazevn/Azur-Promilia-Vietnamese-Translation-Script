# Metadata and language-table mapping findings

## Proven offline decryption

Both regional global-metadata.dat files were decrypted entirely in workspace copies, without executing native game code or writing game files. Format: magic 0x1357FEDA, uint32 payload size, 256-byte key, 64-byte bytecode, payload at 0x148. Current installed Taiwan GameAssembly metadata loader is RVA 0x10D9800 and invokes VM at RVA 0x1468FA0. Public Taiga74164/AP-MetadataDecryptor gave the container structure but its opcode constants are incompatible. Actual 32 used opcodes were recovered from native switch table RVA 0x146B428, using Capstone static disassembly. `decrypt_metadata_current.py` implements those updated operations; `decrypt_metadata_cn.py` applies the same current operations to mainland metadata.

Output files: `tw-global-metadata-decrypted.dat`, `cn-global-metadata-decrypted.dat`. Both contain standard magic FAB11BAF and metadata version31 after removal of CODEPHIL signature. All Taiwan header offset/size pairs fit the file, SHA256 fb09221f21bcc68eae9dacbda93a72ff7efef592b6ded876909e6b8e8d9c5fb4.

Official Il2CppDumper v6.7.46 successfully generated complete offline dump in `il2cppdumper/dump.cs`, script.json and stringliteral.json. CodeRegistration=0x18D74FBC0, MetadataRegistration=0x18F6B7480. The tool's final redirected ReadKey raised after successful output generation; this is cosmetic and does not invalidate files.

## Explicit language table separation

`TableMgr.GetMMapStream` RVA0x508DB10 loads `Config/NewTableMMap/table_data.bytes` via LoadRawFileSync, obtains disk path, opens CreateViewStream, then reads:

1. BeginRead()
2. Create dictionary for empty language tag
3. Int32 base table count
4. Each base table: ReadString name, ReadInt32 offset
5. Int32 language count
6. Each language: ReadString languageTag, Int32 table count, then ReadString name + ReadInt32 offset per table

Interface calls were resolved against IMemoryReader slots3 ReadString and10 ReadInt32. Offsets are stored in Dictionary<string,Dictionary<string,int>> m_MMapTablePos. Thus gameplay tables and language tables share a physical map but have separate explicit indexes. Do not replace the entire table_data across versions.

TableMgr.TryLoadLangTable RVA0x50909A0 creates TDLangCommonTable with customTableName and calls CreateDataStreamReader(tableName,currentLanguage). Language caches are separate m_LangTables and m_LangTableCacheDict. TDLangCommon exposes id:Int64 and value:string. Language-specific replacement can therefore compare matching table names and IDs without changing gameplay tables.

## Row table format

DataStreamReaderXCMMap header length36:

- +0 tag4 (not inspected yet)
- +4 version4
- +8 seven big-endian Int32 values: col,row,fingerprintLen,fieldCommentLen,fieldTypeLen,fieldNameLen,dataLen
- Variable header sections have the four recorded lengths.
- Each data row begins ReadInt2 row length (signed BE short).
- Encoded field types: 0=int0,1=int1,2=int2,3=int3,4=int4,5=float,6=string,7=vec2,8=vec3,9=int5,10=int6,11=int7,12=int8.
- String ReadStringInternal: low nibble must6, high nibble0..4 gives length integer width0..4; length integer followed by string bytes.

Relevant static evidence: `language-dump.cs`, `readerxcmmap.cs`, `tablemgr-disasm.txt`, `readers-disasm.txt`, `table-layout-disasm.txt`.

## Other language resource literals

`Config/LangAssetManifest.bytes`, `Assets/ResourcesAssets/PathMapConfig/txt_updateAssetPathMap.txt`, `Assets/ResourcesLang/{0}/`, `/lang_`, chs,cht. `tw-language-literals.json` contains literal indexes and full relevant values. LangAssetManifest has AssetList/ImageAtlasPairs/ImageAtlasMap; this is separate from text table data.

No game patches were applied by this agent. MMap container cryptography remains parent task; this report concerns metadata and logical language-table layout only.

## Actual table_data recovered and compared

Update table_data was found in raw_streaming_package, not the three raw_base VString/SO/AzurConfig containers. TW file 3iffxeedh2grvnbn2iag.r; CN lgidxoengx75k12t88pyeg.r. Both decrypted with parent MMap XOR decoder. Workspace plaintext: tw-update-table-data.bin / cn-update-table-data.bin.

Actual index strings use uint32 LE byte length + UTF8, not VString indexes. Taiwan has2264 base gameplay tables; language tags cht/en,357 tables each. Mainland has2264 base gameplay tables; chs357 tables. Each physical table offset must subtract4120, then read uint32 LE byteLen preceding LRGB1001 data.

CORRECTION to provisional row description above: actual optimized language tables use fixed rows, bypassing generic encoded field readers. Header rowCount includes3 schema rows. Header dataLen is LE whereas preceding6 fields are BE. Variable schema sections end with uint32 LE stride(12 for nonempty), uint32 LE idListByteLength, then Int64 LE ID index array, then rows of exactly Int64 LE ID + uint32 LE VString key. No per-row length. All1071 language table ID arrays exactly match corresponding data row IDs, verifying offsets.

Parser: parse_language_tables.py. Outputs tw-language-rows.json,cn-language-rows.json. Comparison matches tableName+Int64ID. Taiwan cht470989 rows; Mainland chs476731 rows; matched470963 (99.99448% of TW), identical339523,different131440,TW-only26,CN-only5768. No duplicate IDs within tables in either client.

Compatibility evidence: official-text-matches.jsonl contains470963 matches with table,id,TW/CN keys,TW plaintext value offsets,text. official-cn-candidates.json contains131440 differing rows. language-coverage.json contains per-table counts and26TW-only rows. placeholder-mismatches.json found one text placeholder translation in story_convenient; no executable variable placeholder mismatch observed. duplicate-ids.json is empty. These files remain workspace-only and do not modify installed games.

For integration append mainland official text strings into TW VString pool and update only matching cht language row value keys; preserve all IDs/base gameplay tables/TW-only rows. Never insert mainland VString numeric keys directly into TW tables: regional pool numeric indexes differ.
