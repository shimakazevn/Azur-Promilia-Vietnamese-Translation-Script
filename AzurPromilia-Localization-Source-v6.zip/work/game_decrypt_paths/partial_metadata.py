import re,struct,pathlib,json
s=pathlib.Path('work/game_decrypt_paths/decrypt_chunk.hpp').read_text(); c=re.split(r'case (0x[0-9A-F]+|[0-9]+):',s); cases={int(c[i],0):c[i+1].split('goto')[0].strip() for i in range(1,len(c),2)}
report={}
for label,pth in [('tw','E:/AzurPromilia_TC/AzurPromilia_TC_game'),('cn','D:/AzurPromilia/AzurPromilia_Game')]:
 p=pathlib.Path(pth+'/AzurPromilia_Data/il2cpp_data/Metadata/global-metadata.dat').read_bytes(); n=struct.unpack_from('<I',p,4)[0]; start=len(p)-n; a3=p[8:264]; b=bytearray(p[start:start+n//64*64])
 for op in p[264:328]:
  t=cases[op]; i=int(re.search(r'(0x[0-9A-F]+) % a5',t)[1],16)%64
  if t.startswith('v1'):
   e=re.search(r'v1[13] = \(unsigned __int8\)(.*?);',t)[1]; j=(eval(e)&0xffffffff)%64
   if t.startswith('v12'):
    temp=b[j::64].translate(bytes((x-1)&255 for x in range(256))); b[i::64]=bytes((x-y)&255 for x,y in zip(b[i::64],temp)); b[j::64]=temp
   else: temp=b[i::64];b[i::64]=b[j::64];b[j::64]=temp
  elif '^=' in t: b[i::64]=b[i::64].translate(bytes(x^eval(t.split('^=')[1].rstrip(';')) for x in range(256)))
  elif '__ROR1__' in t:
   r=eval(t.split(',')[-1].rsplit(')',1)[0].replace('*a3','a3[0]'))&7;b[i::64]=b[i::64].translate(bytes(((x>>r)|(x<<(8-r)))&255 for x in range(256)))
  else:
   v=eval('0 '+t.split('=')[1].split(' + a4)')[1].strip().rstrip(';'));b[i::64]=b[i::64].translate(bytes((x+v)&255 for x in range(256)))
 out=pathlib.Path('work/game_decrypt_paths/'+label+'-metadata-partial.bin');out.write_bytes(b)
 strings=[x.decode() for x in re.findall(rb'[\x20-\x7e]{8,}',b) if re.search(rb'Lang|lang|I18N|TableMgr',x)]
 pathlib.Path('work/game_decrypt_paths/'+label+'-lang-strings.txt').write_text('\n'.join(strings))
 print(label,len(strings),strings[:25],flush=True)
