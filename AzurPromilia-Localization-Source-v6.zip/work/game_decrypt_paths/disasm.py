from pathlib import Path
import struct,sys
sys.path.insert(0,'work/game_decrypt_paths/pylibs')
from capstone import *
p=Path('E:/AzurPromilia_TC/AzurPromilia_TC_game/GameAssembly.dll').read_bytes();off=struct.unpack_from('<I',p,60)[0];count=struct.unpack_from('<H',p,off+6)[0];sz=struct.unpack_from('<H',p,off+20)[0];base=struct.unpack_from('<Q',p,off+24+24)[0];sections=[]
for i in range(count):
 o=off+24+sz+i*40;vs,va,rs,raw=struct.unpack_from('<IIII',p,o+8);sections.append((raw,raw+rs,va))
def adr(o):
 for lo,hi,va in sections:
  if lo<=o<hi:return base+va+o-lo
md=Cs(CS_ARCH_X86,CS_MODE_64)
for i in md.disasm(p[0x10d8ba0:0x10d8e50],adr(0x10d8ba0)):print(hex(i.address),i.mnemonic,i.op_str)
