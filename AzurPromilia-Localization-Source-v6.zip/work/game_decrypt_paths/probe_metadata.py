import re,struct,pathlib
s=pathlib.Path('work/game_decrypt_paths/decrypt_chunk.hpp').read_text(); c=re.split(r'case (0x[0-9A-F]+|[0-9]+):',s); cases={int(c[i],0):c[i+1].split('goto')[0].strip() for i in range(1,len(c),2)}
for label,pth in [('tw','E:/AzurPromilia_TC/AzurPromilia_TC_game'),('cn','D:/AzurPromilia/AzurPromilia_Game')]:
 p=pathlib.Path(pth+'/AzurPromilia_Data/il2cpp_data/Metadata/global-metadata.dat').read_bytes(); n=struct.unpack_from('<I',p,4)[0]; start=len(p)-n; key=p[8:264]; b=bytearray(p[start:start+64]); a3=key
 for op in p[264:328]:
  t=cases[op]; i=int(re.search(r'(0x[0-9A-F]+) % a5',t)[1],16)%64
  if t.startswith('v1'):
   e=re.search(r'v1[13] = \(unsigned __int8\)(.*?);',t)[1]; j=(eval(e)&0xffffffff)%64
   if t.startswith('v12'): temp=(b[j]-1)&255;b[i]=(b[i]-temp)&255;b[j]=temp
   else:b[i],b[j]=b[j],b[i]
  elif '^=' in t: b[i]^=eval(t.split('^=')[1].rstrip(';'))
  elif '__ROR1__' in t:
   e=t.split(',')[-1].rsplit(')',1)[0].replace('*a3','a3[0]'); r=eval(e)&7;b[i]=((b[i]>>r)|(b[i]<<(8-r)))&255
  else:
   e=t.split('=')[1].split(' + a4)')[1].strip().rstrip(';');b[i]=(b[i]+eval('0 '+e))&255
 print(label,start,b[:32].hex(),repr(b[:32]))
