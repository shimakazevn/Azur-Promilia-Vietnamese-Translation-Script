import re,struct,bisect,json
from pathlib import Path
p=Path('E:/AzurPromilia_TC/AzurPromilia_TC_game/GameAssembly.dll').read_bytes();d=Path('work/game_decrypt_paths/il2cppdumper/dump.cs').read_text(encoding='utf-8-sig');pairs=sorted((int(a,16),b.strip()) for a,b in re.findall(r'// RVA: (0x[0-9A-F]+)[^\n]*\n\s*([^\n]+)',d));addrs=[x[0] for x in pairs]
r={}
for target in [0x6e4a2c0,0x6e4a120,0x6e4a6f0]:
 hits=[];o=0
 while (o:=p.find(b'\xe8',o))>=0:
  if o+5<=len(p):
   rva=o+0xc00
   if rva+5+struct.unpack_from('<i',p,o+1)[0]==target:
    ix=bisect.bisect_right(addrs,rva)-1;hits.append({'rva':hex(rva),'method':pairs[ix]})
  o+=1
 r[hex(target)]=hits
Path('work/game_decrypt_paths/builtinlang-xrefs.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
