import re,struct,pathlib,json,hashlib
s=pathlib.Path('work/game_decrypt_paths/current-opcodes.txt').read_text();parts=re.split(r'OP (0x[0-9a-f]+)\n',s);ops={int(parts[i],16):parts[i+1] for i in range(1,len(parts),2)}
path=pathlib.Path('D:/AzurPromilia/AzurPromilia_Game/AzurPromilia_Data/il2cpp_data/Metadata/global-metadata.dat');p=path.read_bytes();n=struct.unpack_from('<I',p,4)[0];key=p[8:264];b=bytearray(p[328:]);full=n//64*64
# Treat the tail separately so modulo and strided counts remain exact.
def apply(buf,size):
 for op in p[264:328]:
  t=ops[op];i=int(re.search(r'mov eax, (0x[0-9a-f]+)',t)[1],16)%size;k=int(re.search(r'\[rbx \+ (0x[0-9a-f]+|[0-9]+)\]',t)[1],0)
  if 'movzx eax, byte ptr [rbx' in t:
   sign,constant=re.search(r'(add|sub) eax, (0x[0-9a-f]+)',t).groups();j=((key[k]+(1 if sign=='add' else -1)*int(constant,16))&0xffffffff)%size
   if '0x18146b3ed' in t:
    temp=buf[j::size].translate(bytes((x-1)&255 for x in range(256)));buf[i::size]=bytes((x-y)&255 for x,y in zip(buf[i::size],temp));buf[j::size]=temp
   else:temp=buf[i::size];buf[i::size]=buf[j::size];buf[j::size]=temp
  else:
   if 'shr al' in t:r=(key[k]-4)&7;tab=bytes(((x>>r)|(x<<(8-r)))&255 for x in range(256))
   elif 'xor cl' in t:v=key[k]^int(re.search(r'xor cl, (0x[0-9a-f]+)',t)[1],16);tab=bytes(x^v for x in range(256))
   else:
    sign,constant=re.search(r'(add|sub) cl, (0x[0-9a-f]+)',t).groups();v=-key[k]+(1 if sign=='add' else -1)*int(constant,16);tab=bytes((x+v)&255 for x in range(256))
   buf[i::size]=buf[i::size].translate(tab)
 return buf
out=apply(b[:full],64)+apply(b[full:],n-full) if n%64 else apply(b,64)
print(repr(out[:32]),flush=True)
assert out[:8]==b'CODEPHIL',out[:8]
assert out[8:12]==bytes.fromhex('af1bb1fa')
pathlib.Path('work/game_decrypt_paths/cn-global-metadata-decrypted.dat').write_bytes(out[8:])
strings=[x.decode('utf8','replace') for x in re.findall(rb'[\x20-\x7e]{5,}',out) if re.search(rb'Lang|lang|I18N|TableMgr',x)]
pathlib.Path('work/game_decrypt_paths/cn-decrypted-lang-strings.txt').write_text('\n'.join(strings),encoding='utf8')
print(len(strings))

