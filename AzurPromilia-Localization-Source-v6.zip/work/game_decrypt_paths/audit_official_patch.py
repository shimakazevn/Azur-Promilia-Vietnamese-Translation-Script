from pathlib import Path
import sys,json,re,collections
sys.path.insert(0,'work/game_compare_manifests')
from vstring_pool import VStringPool

root=Path('work/game_decrypt_paths')
missing=json.loads((root/'missing-official-text-search.json').read_text('utf8'))
targets={r['expected'] for r in missing}
hits={s:[] for s in targets}
tw_hits={s:[] for s in targets}
for name,poolfile,out in [('cn','cn_update_bjzqzapbodx6zodmvtrta.bin',hits),('tw','tw_update_v0k2cafcxjxawklow6skg.bin',tw_hits)]:
 pool=VStringPool(Path('work/game_mmap/decoded')/poolfile)
 for key in range(pool.count):
  v=pool[key]
  if v in targets:out[v].append(key)
for r in missing:
 r['cn_pool_keys']=hits[r['expected']];r['tw_pool_keys']=tw_hits[r['expected']]
(root/'missing-full-pool-search.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2),'utf8')
print(json.dumps([{k:r[k] for k in ['tw','expected','cn_pool_keys','tw_pool_keys']} for r in missing],ensure_ascii=False),flush=True)
candidates=json.loads((root/'official-cn-candidates.json').read_text('utf8'))
suspect=[]
for r in candidates:
 a,b=r['tw'] or '',r['cn'] or ''
 if re.search(r'https?://|ICP备|公司|營運|运营|客服|隐私|隱私|悠星|蛮啾|蠻啾',a+b):
  urls=lambda s: re.findall(r'https?://[^\s<>\[\]"\u3000]+',s)
  if urls(a)!=urls(b) or re.search(r'ICP备|悠星|蛮啾|蠻啾',a+b):suspect.append(r)
(root/'official-region-text-audit.json').write_text(json.dumps(suspect,ensure_ascii=False,indent=2),'utf8')
print('region_text_suspects',len(suspect),flush=True)
for r in suspect[:30]:print(json.dumps(r,ensure_ascii=False),flush=True)
