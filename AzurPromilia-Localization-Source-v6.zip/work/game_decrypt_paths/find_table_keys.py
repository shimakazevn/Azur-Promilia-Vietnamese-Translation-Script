from pathlib import Path
import struct
p=Path('work/game_mmap/decoded/tw_builtin_mjsd3ojqtcpsyxkepjq6tw.bin').read_bytes();H=struct.unpack_from('<I',p)[0];hdr=struct.unpack_from('<5I',p,H);offs=hdr[2]-4120;n=hdr[4]
def st(k):
 o=struct.unpack_from('<I',p,offs+k*4)[0]-4120;l=struct.unpack_from('<i',p,o)[0];return p[o+4:o+4+l].decode('utf8') if l>=0 else ''
for k in range(n):
 s=st(k)
 if ('NewTable' in s or 'table_data.bytes' in s or s.startswith('lang_')):print(k,s)
