from pathlib import Path
import json,struct,hashlib,re
root=Path('work/game_decrypt_paths/sdk_qm');tw=json.loads((root/'tw-raw-181cfaf.json').read_text(encoding='utf-8'));cn=json.loads((root/'cn-e79915.json').read_text(encoding='utf-8'))
def key(r):return tuple(r.get('7',[])),tuple(r.get('6',[])),tuple(r.get('8',[]))
c={key(r):r for r in cn['rows']}
allow={'manjuu_gamesdk_toast_password_invalid_first_check','manjuu_gamesdk_toast_password_invalid_second_check','manjuu_gamesdk_policy_reject_double_check','manjuu_gamesdk_privacy_policy','manjuu_gamesdk_txt_webview_net_error','manjuu_gamesdk_user_terms_of_service','manjuu_gamesdk_policy_check_all'}
exclude={'manjuu_gamesdk_hint_verify_code':'Preserve email/generic verification wording; mainland specifically says SMS.','manjuu_gamesdk_policy_update_content':'Preserve Taiwan agreement/legal scope and regulatory wording.','manjuu_gamesdk_account_banned_content':'Incompatible variable placeholders and newline format.','manjuu_gamesdk_security_tip':'Preserve Taiwan email delivery; mainland says SMS delivery.','manjuu_union_sdk_delete_channel_account_revoke_content':'Incompatible variable placeholders and newline format.','manjuu_gamesdk_policy_double_check':'Preserve Taiwan agreement scope: includes other agreements (etc.).'}
manifest=[];overrides={}
for row in tw['rows']:
 k=key(row);s=row['6'][0]
 if k not in c:continue
 a=row.get('3',[]);b=c[k].get('3',[])
 status='same' if a==b else 'use-mainland' if s in allow else 'retain-global'
 if status=='use-mainland':
  ph=lambda x:sorted(re.findall(r'%\d+|%n|\$\{[^}]+\}',str(x)))
  assert ph(a)==ph(b);overrides[k]=b
 manifest.append({'context':row['7'],'source':s,'global_zh_CN':a,'mainland':b,'action':status,'reason':exclude.get(s,'Exact source/context/comment and compatible placeholders; display wording only.' if status=='use-mainland' else 'Identical official wording.')})
b=(root/'tw-raw-181cfaf.qm').read_bytes();o=16;blocks=[]
while o<len(b):
 t=b[o];n=int.from_bytes(b[o+1:o+5],'big');blocks.append((t,b[o+5:o+5+n]));o+=5+n
msgs=dict(blocks)[0x69];o=0;new=bytearray();offsets={};idx=0
while o<len(msgs):
 start=o;offsets[start]=len(new);row=tw['rows'][idx];k=key(row);idx+=1
 while True:
  tag=msgs[o];o+=1;new.append(tag)
  if tag==1:break
  n=int.from_bytes(msgs[o:o+4],'big');o+=4;val=msgs[o:o+n];o+=n
  if tag==3 and k in overrides:val=overrides[k][0].encode('utf-16be')
  new+=len(val).to_bytes(4,'big')+val
result=bytearray(b[:16])
for tag,data in blocks:
 if tag==0xa7:data=b'zh_TW'
 if tag==0x69:data=bytes(new)
 if tag==0x42:
  q=bytearray(data)
  for pos in range(0,len(q),8):old=int.from_bytes(q[pos+4:pos+8],'big');q[pos+4:pos+8]=offsets[old].to_bytes(4,'big')
  data=bytes(q)
 result.append(tag);result+=len(data).to_bytes(4,'big')+data
assert idx==143
qm=root/'zh_TW.mainland-common-plus-global.qm';qm.write_bytes(result)
original=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\Plugins\mj_sdk\union_pcsdk.dll').read_bytes();patched=bytearray(original);start=0x181999c;oldlen=13839;assert len(result)<=oldlen
patched[start-4:start]=len(result).to_bytes(4,'big');patched[start:start+oldlen]=result+b'\0'*(oldlen-len(result));dest=root/'union_pcsdk.mainland-common-plus-global.candidate.dll';dest.write_bytes(patched)
assert patched[:start-4]==original[:start-4] and patched[start+oldlen:]==original[start+oldlen:]
report={'entries_total':143,'mainland_exact_shared':len(manifest),'mainland_identical':sum(x['action']=='same' for x in manifest),'mainland_changed':sum(x['action']=='use-mainland' for x in manifest),'global_semantics_retained':sum(x['action']=='retain-global' for x in manifest),'other_global_fallback':143-len(manifest),'original_sha256':hashlib.sha256(original).hexdigest(),'candidate_sha256':hashlib.sha256(patched).hexdigest(),'qm_sha256':hashlib.sha256(result).hexdigest(),'new_qm_bytes':len(result),'resource_capacity':oldlen,'installed':False,'signature':'HashMismatch expected; no bypass','comparison':manifest}
(root/'mainland-common-plus-global-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='comparison'}))
