from pathlib import Path
import struct,re,sys,json
sys.path.insert(0,'work/game_decrypt_paths/pylibs');from capstone import *
root=Path('work/game_decrypt_paths')
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\Plugins\mj_sdk\union_pcsdk.dll').read_bytes();pe=struct.unpack_from('<I',p,60)[0];ns=struct.unpack_from('<H',p,pe+6)[0];sz=struct.unpack_from('<H',p,pe+20)[0];base=struct.unpack_from('<Q',p,pe+48)[0];secs=[]
for i in range(ns):
 o=pe+24+sz+40*i;vs,va,rs,raw=struct.unpack_from('<IIII',p,o+8);secs.append((p[o:o+8].rstrip(b'\0').decode(),raw,rs,va))
def addr(o):
 for _,r,n,v in secs:
  if r<=o<r+n:return base+v+o-r
terms=['setLanguage','mj_base::Context::SetGameLanguage','mj_official_global::MjOfglBiz::SetGameLanguage','mj_official_global::MjOfglBiz::SwitchLanguage','zh-CN','zh-TW','zh_CN','zh_TW','game language: ']
targets={};out=[]
for t in terms:
 for enc in ['utf-8','utf-16le']:
  b=t.encode(enc);start=0
  while (i:=p.find(b,start))>=0:
   targets[addr(i)]=(t,enc,i);start=i+1
for sn,r,n,v in secs:
 if sn!='.text':continue
 data=p[r:r+n]
 for m in re.finditer(rb'[\x48\x4c][\x8d\x8b][\x05\x0d\x15\x1d\x25\x2d\x35\x3d]....',data,re.S):
  o=r+m.start(); dest=addr(o)+7+struct.unpack_from('<i',p,o+3)[0]
  if dest in targets:
   out.append({'rva':hex(addr(o)-base),'raw':o,'term':targets[dest]})
(root/'sdk-language-xrefs.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
md=Cs(CS_ARCH_X86,CS_MODE_64);lines=[]
for x in out:
 o=x['raw'];lines.append('\nXREF '+str(x))
 for ins in md.disasm(p[o:o+320],addr(o)):lines.append(f'{ins.address-base:x} {ins.mnemonic} {ins.op_str}')
(root/'sdk-language-xref-disasm.txt').write_text('\n'.join(lines))
