from pathlib import Path
import re,zlib,json
out=Path('work/game_decrypt_paths/sdk_qm');out.mkdir(exist_ok=True)
magic=bytes.fromhex('3cb86418caef9c95cd211cbf60a1bddd')
for region,path in [('tw',r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\Plugins\mj_sdk\union_pcsdk.dll'),('cn',r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data\Plugins\mj_sdk\union_pcsdk.dll')]:
 b=Path(path).read_bytes();hits=[]
 for m in re.finditer(rb'\x78[\x01\x5e\x9c\xda]',b):
  o=m.start()
  try:
   d=zlib.decompressobj();s=d.decompress(b[o:o+8_000_000],8_000_000)
   if s.startswith(magic):
    p=out/f'{region}-{o:x}.qm';p.write_bytes(s);hits.append((o,len(s),str(p)))
  except:pass
 print(region,'qm raw magic',b.find(magic),'zlib qm',hits)
