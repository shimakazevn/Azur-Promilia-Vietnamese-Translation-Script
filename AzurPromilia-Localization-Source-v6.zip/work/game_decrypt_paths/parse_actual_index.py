import struct,json,sys
from pathlib import Path
sys.path.insert(0,'work/game_compare_manifests');from vstring_pool import VStringPool
pool=VStringPool('work/game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin');p=Path('work/game_decrypt_paths/tw-update-table-data.bin').read_bytes();i=0
def u():
 global i
 v=struct.unpack_from('<I',p,i)[0];i+=4;return v
def s():
 global i
 n=u();v=p[i:i+n].decode('utf8');i+=n;return v
n=u();print('table count',n);base=[(s(),u()) for _ in range(n)];ln=u();print('languages',ln);langs={}
for _ in range(ln):
 lang=s();cnt=u();langs[lang]=[(s(),u()) for j in range(cnt)]
print('indexEnd',i,'langs',[(k,len(v)) for k,v in langs.items()]);print('base first',base[:5]);print('lang first',[(k,v[:5]) for k,v in langs.items()]);r={'base':base,'langs':langs,'index_end':i};Path('work/game_decrypt_paths/tw-table-index.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
for lang,entries in langs.items():
 for name,o in entries[:2]:print(lang,name,o,p[o:o+40].hex(),p[o-4120:o-4120+40].hex())

