# SDK login UI localization: static evidence

Read-only investigation; no process attachment, SDK loading, login requests, or SDK/game changes performed.

## Confirmed

- `AzurPromilia_Data/Plugins/mj_sdk/union_pcsdk.dll` is a separate native Qt/CEF SDK. Its shipped ASCII strings include `setLanguage`, `mj_base::Context::SetGameLanguage`, `mj_official_global::MjOfglBiz::SetGameLanguage`, `mj_official_global::MjOfglBiz::SwitchLanguage`, `send browser language synchronization failed`, and ` change language from `. Both zh-CN and zh-TW exist.
- Therefore a distinct SDK language layer exists. This does not prove the supported request schema, nor that all SDK screens have both translations.
- Managed bridge `MJPCInterface` exposes generic `ManjuuSdk_SetValue(contextHwnd, apiName, v)` and `ManjuuSdk_Extensive`; no strongly typed SDK SetLanguage method found in the inspected bridge.
- `MJSDKManager.InitParams` RVA 0x6E144C0 retrieves SDK version/channel/gameID/appID and writes corresponding launch fields. Inspected instructions do not establish a language setter call.
- `MJPCInterface.MJNativeInit` RVA 0xBB3AFC0 calls setSdkEnv then forwards initialization data to a native target. This alone does not establish a display-only language parameter.
- Exact UTF-8 and UTF-16LE searches for 登入成功 and 切換帳號 return no matches in union_pcsdk.dll. Earlier broad text searches also did not find 登入成功 in main language tables or metadata literals.
- A local CEF locale directory has zh-CN.pak and zh-TW.pak. Those are browser-engine localization packs; their mere presence does not prove they contain the SDK account UI.
- AppData LocalLow/manjuu/AzurPromilia contains small HTTP caches and logs, plus an announcement image. Inventory only was printed; no account/token values exposed. Local/UniSDK inventory refers to unrelated provider-looking caches and was not pursued.

## Boundary and next action

The grey login status strip remains a candidate for separate SDK localization, not a proven remote-only UI. No directly editable localization file or safe documented display-only switch was established. Do not replace the Taiwan SDK with the mainland SDK or globally change cht to chs: both can affect channel/region behavior. Do not report full visible coverage until the user restarts and checks the V2 patch.

If the login strip remains traditional after V2, a targeted next investigation would trace the SDK native setLanguage handler and its accepted language values from shipped code, preserving all Taiwan channel/account endpoints. This has not been performed or applied.

Evidence: sdk-native-resource-strings.json; sdk-language-disasm.txt; login-text-sources.md.


## Follow-up: embedded SDK translations located (supersedes earlier unknown)

A focused native trace resolved the resource source:

- `MjOfglBiz::SwitchLanguage`, RVA 0x260500, reads context language at +0x1A0. It maps `zh-Hans` to `zh_CN` and `zh-Hant` to `zh_TW` (0x26055B–0x260597), then constructs `:/base/translations/<locale>.qm` (0x26078E onward).
- At 0x1E5EE0 a separate path maps the same language names to `zh-CN`/`zh-TW` for browser use. Browser locale and Qt translation locale have different spellings.
- Both Qt QM files are UNCOMPRESSED embedded data, not UTF-8 or UTF-16LE strings. Their translation bytes are UTF-16BE. This explains why the earlier raw searches missed the visible text.
- TW zh_TW QM: raw DLL offset 0x181999C, 13,839 bytes, 143 entries. TW zh_CN QM: 0x181CFAF, 13,629 bytes, 143 entries. Their exact context/source/comment keys match 143/143, with zero placeholder mismatches.
- The visible status texts have exact source keys in context `Common`: `manjuu_gamesdk_welcome_title` = 登入成功 in zh_TW, 欢迎回来 in the same SDK official zh_CN; `manjuu_gamesdk_switch_account` = 切換帳號 / 切换账号. Thus source of those two visible labels is now established.

### Candidate prepared, not installed

`sdk_qm/zh_TW.official-simplified.qm` uses the SDK author's complete official zh_CN payload with only the language marker relabelled zh_TW (same length). All lookup source/context/hash data remain the official original zh_CN data. `sdk_qm/union_pcsdk.official-zhCN-in-zhTW.candidate.dll` replaces only the original zh_TW resource length prefix plus its data slot. New payload is 210 bytes shorter; that remaining slot space is zero padded so no later resource offsets or DLL size change. All differences are confined to [0x1819998,0x181CFAB). No channel code, endpoint or game language selection is changed.

Original SDK DLL is Authenticode Valid, signed by JIMI PTE. LTD. Candidate signature is HashMismatch as expected after editing signed bytes. This candidate therefore proves an offline resource replacement can be constructed, NOT that the installed SDK/launcher will accept it or that loading is safe to assume. No DLL was executed, no game was attached, and installation was not modified.

### Mainland wording parity boundary

Mainland SDK has a compressed 225-entry translation resource labelled en_US but containing Simplified Chinese. Exact Common context/source/comment intersection with TW SDK has 44 entries; 31 identical translations and 13 different translations. Some differences are channel semantics (SMS vs email) or incompatible placeholders (`%1` versus `${startTime}`). These must not be replaced indiscriminately. Full same-SDK official zh_CN coverage is available for all 143 Taiwan SDK entries, but exact mainland SDK wording parity across all 143 is not established. The welcome title uses a global-only source key without an exact mainland match.

Evidence and files: `sdk-language-xrefs.json`, `sdk-handler-disasm.txt`, `sdk_qm/*.qm`, `sdk_qm/*.json`, `sdk_qm/comparison.json`, `sdk_qm/candidate-validation.json`. All are workspace research outputs.


## Conservative mainland-common + global fallback candidate

Prepared `sdk_qm/union_pcsdk.mainland-common-plus-global.candidate.dll` (not installed). SHA256 `8ad021b8eb998ebf2e0791025a3962ec631cd1bcf674a88d20222bcaa07de7bf`.

143 total entries: 31 exact shared official translations, 7 safe mainland same-key wording changes, 6 retained Taiwan/global semantics, 99 global SDK official Simplified Chinese fallback. Safe changes: two password-format prompts, agreement refusal prompt, Privacy Policy/User Agreement titles, network-error punctuation, agreement-all-selected punctuation. Retained entries: generic/email verification versus mainland SMS, actual email-versus-SMS delivery prompt, two incompatible placeholder schemes, Taiwan agreement scope and regulatory premises. Complete 44-entry manifest: `sdk_qm/mainland-common-plus-global-manifest.json`.

Verification reparsed all 143 messages, preserved all source/context/comment fields, found exactly seven translation changes versus the global SDK official zh_CN baseline, and validated all 143 rewritten hash-index message offsets. New QM occupies 13,631 bytes inside the existing 13,839-byte slot. DLL file size and bytes outside that resource slot are unchanged. Signature check reports HashMismatch. No attempt to bypass signature checking was made.

The mainland SDK `mj_official_cn::LoginSucceedWnd` explicitly translates source `Welcome back` to 欢迎回来 and `Switch Account` to 切换账号. Those labels match the global SDK's official zh_CN text despite different source keys (`Common/manjuu_gamesdk_welcome_title` and `Common/manjuu_gamesdk_switch_account`). Thus the two reported status-strip labels can match authentic mainland wording using the existing global official Simplified Chinese translations.
