from pathlib import Path
import json,struct
root=Path('work/game_decrypt_paths/sdk_qm')
def parse(path):
 b=path.read_bytes();o=16;blocks={}
 while o<len(b):
  tag=b[o];n=int.from_bytes(b[o+1:o+5],'big');blocks[tag]=b[o+5:o+5+n];o+=5+n
 data=blocks[0x69];o=0;rows=[];r={};seq=[]
 while o<len(data):
  tag=data[o];o+=1
  if tag==1:rows.append(r);r={};continue
  if tag in [5,9]:n=4;s=data[o:o+4];o+=4
  else:n=int.from_bytes(data[o:o+4],'big');o+=4;s=data[o:o+n];o+=n
  value=s.decode('utf-16be' if tag==3 else 'utf-8','replace');r.setdefault(str(tag),[]).append(value)
 return {'language':blocks.get(0xa7,b'').decode(),'rows':rows}
for p in root.glob('*.qm'):
 if '-raw-' not in p.name and not p.name.startswith('cn-e'):continue
 d=parse(p);p.with_suffix('.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(p.name,d['language'],len(d['rows'])); print(json.dumps([r for r in d['rows'] if any('登入' in x or '登錄' in x or '切換' in x or '登录' in x or '切换' in x for x in r.get('3',[]))],ensure_ascii=True))
