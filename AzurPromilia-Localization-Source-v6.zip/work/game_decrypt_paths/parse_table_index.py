from pathlib import Path
import struct,json
for f in Path('work/game_mmap/decoded').glob('*.bin'):
 p=f.read_bytes();i=0
 def u():
  global i
  v=struct.unpack_from('<I',p,i)[0];i+=4;return v
 try:
  count=u();assert count<10000,count;base=[(u(),u()) for _ in range(count)];langs={};lc=u();assert lc<100,lc
  for _ in range(lc):
   key=u();n=u();assert n<10000,n;langs[key]=[(u(),u()) for z in range(n)]
  r={'file':f.name,'base_count':count,'language_count':lc,'index_end':i,'base':base,'langs':langs}
  Path('work/game_decrypt_paths/'+f.stem+'-index.json').write_text(json.dumps(r,indent=2));print(f.name,count,lc,i,[(hex(k),len(v)) for k,v in langs.items()]);print('First table',base[0],p[base[0][1]:base[0][1]+36].hex())
 except Exception as e:print(f.name,e,flush=True)

