from pathlib import Path
import json,re,collections
r=Path('work/game_decrypt_paths');tw=json.loads((r/'tw-language-rows.json').read_text(encoding='utf8'))['cht'];cn=json.loads((r/'cn-language-rows.json').read_text(encoding='utf8'))['chs'];bad=[];dups=[];matches=[]
def tokens(s):return sorted(re.findall(r'\{[^{}]+\}|%(?:\d+\$)?[-+#0 ]*(?:\d+|\*)?(?:\.(?:\d+|\*))?[a-zA-Z]',s or ''))
for name,rows in tw.items():
 ref={v['id']:v for v in cn.get(name,[])}
 for label,arr in [('tw',rows),('cn',cn.get(name,[]))]:
  c=collections.Counter(x['id'] for x in arr)
  if any(v>1 for v in c.values()):dups.append({'table':name,'region':label,'duplicates':sum(v-1 for v in c.values())})
 for row in rows:
  if row['id'] not in ref:continue
  x=ref[row['id']];item={'table':name,'id':row['id'],'tw_key':row['key'],'cn_key':x['key'],'tw_offset':row['value_offset'],'tw':row['value'],'cn':x['value']};matches.append(item)
  if tokens(row['value'])!=tokens(x['value']):bad.append(item|{'tw_tokens':tokens(row['value']),'cn_tokens':tokens(x['value'])})
(r/'official-text-matches.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n' for v in matches),encoding='utf8');(r/'placeholder-mismatches.json').write_text(json.dumps(bad,ensure_ascii=False,indent=2),encoding='utf8');(r/'duplicate-ids.json').write_text(json.dumps(dups,indent=2));print('placeholder mismatch',len(bad),'duplicate tables',len(dups));print(json.dumps(bad[:5],ensure_ascii=True)[:3500])
