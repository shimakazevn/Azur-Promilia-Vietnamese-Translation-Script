# Boot/login text source audit

- Running game process was left untouched. All inspection was static/read-only against installed resources plus prior workspace dumps.
- `VersionUpdateUI.Awake` RVA0x695DCE0 loads `UI/StaticPages/updatableBuiltInLangString.csv` at RVA0x695DD91 and, on successful asset load, obtains TextAsset.ToString and calls `BuiltInLangStringUtility.Initialize(csv)` at RVA0x695DDFC.
- `BuiltInLangStringUtility.Initialize` RVA0x6E4A2C0 only falls back to Resources.Load(builtInLangString) if the supplied CSV text is null/empty. Therefore the updatable CSV takes precedence over resources.assets.
- The currently installed resources.assets TextAsset builtInLangString was read and checking_update CHS+CHT columns are both simplified. Seeing traditional checking-update text is consistent with the overriding CSV.
- `VersionUpdateUI.OnCheckUpdateStart` RVA0x695E980 invokes BuiltInLangStringUtility.Get at0x695EA4C. Complete annotated static call evidence: boot-language-disasm.txt.
- compare_game_manifests agent mapped CSV to TW builtin static_package manifest assetkey295/index194/bundle1/pack2: nkewfips4anrz2bqfjhpg.r,65740185bytes,CRC2455484288,197assets. No update-manifest entry for the CSV.
- Existing TW updated VString pool contains exact traditional settings strings: key1562089 switch-account,1562155 restore-default-settings,1562156 confirmation,1563926 success. These have corresponding language rows, but serialized UI may also hold direct VString refs. Updating language table rows alone does not update direct VString refs.
- login-pool-texts.json and login-table-texts.json contain exact keys/row offsets. Native metadata literal scan found no exact traditional login-success, switch-account, server-not-open announcement. UTF8+UTF16LE exact scans of union_pcsdk.dll/sdkbrowser.exe/AzurPromiliaBase.dll found no login-success/server-not-open phrase. This does NOT establish their absence in serialized bundles or remote content; remote SDK/announcement is an unproven candidate.
- Do not translate service URLs, authentication tokens, account records or change SDK region. This audit read no credential-bearing logs.
