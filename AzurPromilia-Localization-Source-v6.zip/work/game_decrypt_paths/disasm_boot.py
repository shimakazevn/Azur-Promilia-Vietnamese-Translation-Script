exec(open('work/game_decrypt_paths/disasm.py').read().split('for i in md.disasm')[0])
import json,re
strings={int(x['address'],16)+base:x['value'] for x in json.loads(Path('work/game_decrypt_paths/il2cppdumper/stringliteral.json').read_text())}
dump=Path('work/game_decrypt_paths/il2cppdumper/dump.cs').read_text(encoding='utf-8-sig');methods={int(m[0],16)+base:m[1].strip() for m in re.findall(r'// RVA: (0x[0-9A-F]+)[^\n]*\n\s*([^\n]+)',dump)}
def raw(va):
 rva=va-base
 for lo,hi,v in sections:
  if v<=rva<v+hi-lo:return lo+rva-v
 raise ValueError(hex(va))
lines=[]
for rva,sz in [(0x695DCE0,0x5D0),(0x695FDC0,0x490),(0x6E4A2C0,0x430),(0x695F6E0,0xD0),(0x695E980,0x150)]:
 va=base+rva;lines.append('FUNCTION '+methods.get(va,hex(va)))
 for ins in md.disasm(p[raw(va):raw(va)+sz],va):
  extra=''
  if ins.mnemonic in ['call','jmp'] and ins.op_str.startswith('0x'):extra=methods.get(int(ins.op_str,16),'')
  m=re.search(r'\[rip ([+-]) (0x[0-9a-f]+)\]',ins.op_str)
  if m:
   target=ins.address+ins.size+(1 if m[1]=='+' else -1)*int(m[2],16);extra+=repr(strings.get(target,'')) if target in strings else ''
  lines.append(f'{ins.address-base:x} {ins.mnemonic} {ins.op_str} {extra}')
Path('work/game_decrypt_paths/boot-language-disasm.txt').write_text('\n'.join(lines));print('\n'.join(x for x in lines if 'call ' in x or 'csv' in x or 'FUNCTION' in x or 'BuiltIn' in x))

