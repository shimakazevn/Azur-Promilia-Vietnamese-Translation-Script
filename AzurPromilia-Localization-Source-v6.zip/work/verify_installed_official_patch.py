from pathlib import Path
import json,hashlib,sys,re,unicodedata,datetime
ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'work/official_game_patch'
sys.path[:0]=[str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/game_decrypt_paths'),str(ROOT/'work/font_deps')]
from vstring_pool import VStringPool
from parse_language_tables import read_index,read_rows
from fontTools.ttLib import TTFont
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'));data=Path(plan['data_root'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
backup=data.parent/'.zhcn-official-3221745-backup'
verified=[]
for entry in plan['files']:
 assert sha(data/entry['relative_path'])==entry['target_sha256'],entry['relative_path']
 assert sha(backup/entry['relative_path'])==entry['source_sha256'],entry['relative_path']
 verified.append(entry['relative_path'])
for entry in plan['required_unchanged_files']:assert sha(data/entry['relative_path'])==entry['sha256']
# Verify all resulting text, including unchanged rows, against the new font union.
plaintext=plan.get('residual_v3',{})
pool=VStringPool(Path(plaintext.get('plaintext_pool',OUT/'vstring-patched.bin')))
table=Path(plaintext.get('plaintext_table',OUT/'table-data-patched.bin')).read_bytes();base,langs,_=read_index(table)
chars=set();rows=0
for name,off in langs['cht'].items():
 for row in read_rows(table,off,pool):
  rows+=1;value=re.sub(r'<[^>]*>','',row['value'] or '')
  chars.update(c for c in value if not unicodedata.category(c).startswith('C') and not c.isspace())
combined=set()
for name in ['cn_a00.otf','cn_b00.otf','official_chs_c00.otf']:
 font=TTFont(ROOT/'work/game_decrypt_bundle'/name,lazy=True);combined.update(font.getBestCmap());font.close()
missing=sorted(c for c in chars if ord(c) not in combined)
report=dict(applied=True,patch_revision=plan.get('patch_revision',1),applied_at=datetime.datetime.now().astimezone().isoformat(),installed_files_verified=len(verified),original_backups_verified=len(verified),language='cht',region_config_unchanged=True,language_rows=rows,all_result_text_unique_characters=len(chars),combined_missing_characters=''.join(missing),combined_missing_count=len(missing),runtime_verified=False,backup_directory=str(backup),verified_files=verified)
for key in ['ui_v2','residual_v3']:
 if key in plan:report[key]=plan[key]
(OUT/'installed-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
(ROOT/'outputs/台服游戏官方简体应用记录.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k!='verified_files'},ensure_ascii=True),flush=True)
