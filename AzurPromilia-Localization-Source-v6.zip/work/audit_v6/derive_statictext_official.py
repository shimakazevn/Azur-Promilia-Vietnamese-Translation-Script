from pathlib import Path
import json,collections,sys
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'analysis_deps')]
from opencc import OpenCC
cc=OpenCC('t2s')
OUT=Path(__file__).resolve().parent
tw=json.loads((BASE/'game_decrypt_paths/tw-language-rows.json').read_text(encoding='utf8'))['cht']
cn=json.loads((BASE/'game_decrypt_paths/cn-language-rows.json').read_text(encoding='utf8'))['chs']
cnref={(n,r['id']):r['value'] for n,rows in cn.items() for r in rows}
bytw=collections.defaultdict(collections.Counter)
for n,rows in tw.items():
 for r in rows:
  v=r['value']
  if v and (n,r['id']) in cnref:bytw[v][cnref[(n,r['id'])]]+=1
only=json.loads((BASE/'official_parity_audit/statictext-taiwan-only.json').read_text(encoding='utf8'))
mapped=[];unmapped=[]
for r in only:
 o=r.get('originalTW') or ''
 c=bytw.get(o)
 if c:
  best,cnt=c.most_common(1)[0]
  mapped.append(dict(key=r['key'],originalTW=o,current=r['value'],officialCN=best,votes=cnt,alternatives=len(c),changes=best!=r['value']))
 else:unmapped.append(dict(key=r['key'],originalTW=o,current=r['value']))
# CN corpus term usage
corpus=[v for rows in cn.values() for r in rows for v in [r['value']] if v]
terms=['几率','概率','机率','默认','预设','设置','设定','界面','介面','网络','网路','信息','资讯','保存','储存','点击','点选','循环','回圈','字符','字元','连结','链接','画质','品质','服务器','伺服器','登录','登入','账号','帐号']
usage={t:sum(t in v for v in corpus) for t in terms}
res=dict(mapped=mapped,unmapped=unmapped,cn_term_usage=usage)
(OUT/'statictext-twonly-official-derivation.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
print('taiwan-only',len(only),'mapped',len(mapped),'changes',sum(m['changes'] for m in mapped),'ambiguous',sum(m['alternatives']>1 for m in mapped),'unmapped',len(unmapped))
print(json.dumps(usage,ensure_ascii=False))
for m in [m for m in mapped if m['changes']][:60]:print('MAP',m['key'],'|',m['current'][:50].replace(chr(10),' '),'=>',m['officialCN'][:50].replace(chr(10),' '),'| alt',m['alternatives'])