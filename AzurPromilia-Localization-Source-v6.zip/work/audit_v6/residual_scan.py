from pathlib import Path
import sys,json,re,csv,io,collections
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_compare_manifests'),str(BASE/'game_decrypt_paths'),str(BASE/'game_decrypt_bundle'),str(BASE/'analysis_deps')]
from opencc import OpenCC
from parse_manifest import parse
from patch_manifest import encode_name
from vstring_pool import VStringPool
from unity_setup import UnityPy
from parse_language_tables import read_index,read_rows
OUT=Path(__file__).resolve().parent
TW=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
cc=OpenCC('t2s')
def w(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
# Taiwan phrase dictionary (TW phrase -> CN phrase), compared in simplified form
twp={}
for line in (BASE/'analysis_deps/opencc/dictionary/TWPhrasesRev.txt').read_text(encoding='utf8').splitlines():
 parts=line.split('\t')
 if len(parts)>=2:
  k=cc.convert(parts[0]);v=parts[1].split(' ')[0]
  if len(k)>=2 and k!=v:twp[k]=v
extra={'伺服器':'服务器','登入':'登录','帐号':'账号','帳號':'账号','网路':'网络','讯息':'消息','影片':'视频','萤幕':'屏幕','滑鼠':'鼠标','游标':'光标','硬碟':'硬盘','记忆体':'内存','解析度':'分辨率','品质':'画质','预设':'默认','设定':'设置','连线':'连接','资讯':'信息','介面':'界面','档案':'文件','储存':'保存','载入':'加载','程式':'程序','支援':'支持','回馈':'反馈','即时':'实时','重新整理':'刷新','手把':'手柄','摇杆':'摇杆','音讯':'音频','视讯':'视频'}
twp.update(extra)
twkeys=sorted(twp,key=len,reverse=True)
def tw_terms(t):return sorted({k for k in twkeys if k in t})
# ---- sources
src=collections.defaultdict(list)
pool=VStringPool(BASE/'official_game_patch_v3/vstring-patched.bin');table=(BASE/'official_game_patch_v3/table-data-patched.bin').read_bytes();_,langs,_=read_index(table)
cn=json.loads((BASE/'game_decrypt_paths/cn-language-rows.json').read_text(encoding='utf8'))['chs']
cnref={(n,r['id']):r['value'] for n,rows in cn.items() for r in rows}
for name,off in langs['cht'].items():
 for r in read_rows(table,off,pool):
  if r['value']:src['language_tables'].append(dict(key=f"{name}:{r['id']}",value=r['value'],cn=cnref.get((name,r['id']))))
mp=TW/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes';m=parse(mp);sp=VStringPool(BASE/'game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin')
a=next(a for a in m['assets'] if sp[a['path_key']]=='Assets/ResourcesLang/cht/UI/StaticText/ast_staticTextKeyConfig.asset');b=m['bundles'][a['bundle']];pk=m['packs'][b['pack_id']];n=encode_name(pk['name0'],pk['name1']);p=TW/'.res/default_package/BundleFiles'/n
if not p.exists():p=TW/'StreamingAssets/.res/default_package'/n
with p.open('rb') as f:f.seek(b['offset']);raw=f.read(b['size'])
st=next(o for o in UnityPy.load(raw).objects if o.type.name=='MonoBehaviour').read_typetree()['list']
cnst={}
try:
 import importlib.util
 for r in json.loads((BASE/'official_parity_audit/statictext-taiwan-only.json').read_text(encoding='utf8')):pass
except Exception:pass
twonly={r['key'] for r in json.loads((BASE/'official_parity_audit/statictext-taiwan-only.json').read_text(encoding='utf8'))}
for r in st:
 if r['value']:src['statictext'].append(dict(key=r['key'],value=r['value'],cn=None if r['key'] in twonly else r['value']))
raw=(TW/'StreamingAssets/.res/static_package/nkewfips4anrz2bqfjhpg.r').read_bytes()
obj=next(o for o in UnityPy.load(raw).objects if o.path_id==-7652933866689782301);t=obj.read_typetree()['m_Script'];t=t.decode('utf8') if isinstance(t,bytes) else t
rows=list(csv.reader(io.StringIO(t)));h=[x.lstrip('\ufeff') for x in rows[0]];ci=h.index('cht');si=h.index('chs')
for r in rows[1:]:
 if len(r)>ci and r[ci]:src['startup_csv'].append(dict(key=r[0],value=r[ci],cn=r[si] or None))
for l in open(BASE/'official_parity_audit/serialized-ui-text-fields.jsonl',encoding='utf8'):
 r=json.loads(l)
 for x in r.get('tw_texts') or []:src['ui_direct'].append(dict(key=f"{r['paths'][0]}#{x['game_object']}{x['field']}",value=x['text'],cn=x['text']))
# ---- residual checks
res={};summary={}
for s,items in src.items():
 trad=[];tw=[];
 for it in items:
  v=it['value'];c=cc.convert(v)
  official_same = it['cn'] is not None and it['cn']==v
  if c!=v:
   diff=''.join(sorted({a for a,b2 in zip(v,c) if a!=b2})) if len(c)==len(v) else ''
   trad.append(dict(**it,t2s=c,chars=diff,official_identical=official_same))
  terms=tw_terms(v)
  if terms and not official_same:tw.append(dict(**it,taiwan_terms={k:twp[k] for k in terms}))
 res[s]=dict(traditional=trad,taiwan_terms_no_official=tw)
 summary[s]=dict(items=len(items),traditional_residual=len(trad),traditional_residual_not_official=sum(not x['official_identical'] for x in trad),taiwan_terms_no_official=len(tw))
w('residual-traditional-and-taiwan-terms.json',res);w('residual-summary.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=1))
for s,r in res.items():
 print('====',s)
 for x in [x for x in r['traditional'] if not x['official_identical']][:40]:print('TRAD',x['key'][:70],'|',x['value'][:80].replace('\n',' '),'|',x['chars'])
 for x in r['taiwan_terms_no_official'][:60]:print('TWTERM',x['key'][:70],'|',x['value'][:80].replace('\n',' '),'|',x['taiwan_terms'])