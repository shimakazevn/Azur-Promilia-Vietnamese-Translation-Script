from pathlib import Path
import json,collections
BASE=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
cn=json.loads((BASE/'game_decrypt_paths/cn-language-rows.json').read_text(encoding='utf8'))['chs']
corpus=[r['value'] for rows in cn.values() for r in rows if r['value']]
st=json.loads((BASE/'game_decrypt_bundle/statictext_v2_candidate.json').read_text(encoding='utf8')) if False else None
d=json.loads((OUT/'statictext-twonly-official-derivation.json').read_text(encoding='utf8'))
pairs=[('机率','概率'),('介面','界面'),('网路','网络'),('回圈','循环'),('字元','字符'),('暱称','昵称'),('自订','自定义'),('点选','点击'),('资讯','信息'),('预设','默认'),('设定','设置'),('储存','保存'),('目前','当前'),('配对','匹配'),('连结','链接'),('品质','品质'),('萤幕','屏幕'),('讯息','消息'),('影片','视频'),('档案','文件'),('载入','加载'),('程式','程序'),('支援','支持'),('游标','光标'),('滑鼠','鼠标'),('解析度','分辨率'),('帐号','账号'),('登入','登录'),('伺服器','服务器'),('撷取','截取'),('透过','通过'),('优化','优化'),('使用者','用户'),('预览','预览'),('物件','物体'),('图示','图标'),('选单','菜单'),('视窗','窗口'),('键盘','键盘'),('音效','音效'),('全萤幕','全屏'),('垂直同步','垂直同步'),('即时','实时'),('关卡','关卡'),('数据','数据'),('资料','数据'),('依','按'),('最佳化','优化'),('硬体','硬件'),('软体','软件'),('记忆体','内存'),('显示卡','显卡'),('回报','反馈'),('客服','客服'),('品项','物品'),('序号','序列号'),('兑换码','兑换码')]
usage={a+'/'+b:(sum(a in v for v in corpus),sum(b in v for v in corpus)) for a,b in pairs}
print(json.dumps(usage,ensure_ascii=False))
hits=collections.defaultdict(list)
for r in d['unmapped']:
 for a,b in pairs:
  if a!=b and a in r['current']:hits[a].append(r['key']+' '+r['current'][:60].replace(chr(10),' '))
for a,l in hits.items():
 print('==',a,len(l))
 for x in l[:12]:print('   ',x)