from pathlib import Path
import re,json,sys,collections
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE/'analysis_deps'))
from opencc import OpenCC
cc=OpenCC('t2s')
run=re.compile(r'[\u3000-\u303f\u3400-\u9fff\uff00-\uffef0-9A-Za-z%{}]{2,}')
han=re.compile(r'[\u3400-\u9fff]')
def strs(p):
 t=p.read_bytes().decode('utf8','ignore');return collections.Counter(s for s in run.findall(t) if len(han.findall(s))>=2)
tw=strs(BASE/'game_decrypt_paths/tw-global-metadata-decrypted.dat');cn=strs(BASE/'game_decrypt_paths/cn-global-metadata-decrypted.dat')
only=[s for s in tw if s not in cn]
trad=[s for s in only if cc.convert(s)!=s]
alltrad=[s for s in tw if cc.convert(s)!=s]
res=dict(tw_han_runs=len(tw),cn_han_runs=len(cn),tw_only=len(only),tw_only_traditional=len(trad),tw_traditional_total=len(alltrad),cn_traditional_total=sum(cc.convert(s)!=s for s in cn),samples=sorted(trad,key=len,reverse=True)[:300],tw_only_samples=sorted(only,key=len,reverse=True)[:150])
(Path(__file__).resolve().parent/'metadata-hardcoded-strings.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in res.items() if 'samples' not in k}))
for s in res['samples'][:80]:print('TRAD',s[:100])
for s in res['tw_only_samples'][:40]:print('ONLY',s[:100])