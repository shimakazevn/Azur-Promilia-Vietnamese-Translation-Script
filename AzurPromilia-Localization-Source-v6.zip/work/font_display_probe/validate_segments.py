from pathlib import Path
import sys,struct,json,io
BASE=Path(__file__).resolve().parents[1];sys.path[:0]=[str(BASE/'game_decrypt_bundle'),str(BASE/'analysis_deps')]
from unity_setup import UnityPy
from fontTools.ttLib import TTFont
OUT=Path(__file__).resolve().parent
plan=json.loads((OUT/'segment-plan.json').read_text(encoding='utf8'))
registry={};loaded=[]
for p in {r['sourcePack'] for r in plan}:
 raw=Path(p).read_bytes();off=0
 while off<len(raw):
  size=struct.unpack_from('>Q',raw,off+24)[0];env=UnityPy.load(raw[off:off+size]);loaded.append(env)
  for o in env.objects:registry[(o.assets_file.name.lower(),o.path_id)]=o
  off+=size
reports=[]
for row in plan:
 raw=Path(row['sourcePack']).read_bytes()[row['offset']:row['offset']+row['oldSize']];orig=UnityPy.load(raw);old={o.path_id:o for o in orig.objects}
 env=UnityPy.load(row['segmentCandidate']);results=[]
 for mutation in row['mutations']:
  o=next(o for o in env.objects if o.path_id==mutation['pathId']);tree=o.read_typetree();before=old[o.path_id].read_typetree()
  result={'name':tree['m_Name']}
  if mutation['type']=='Font':
   a=TTFont(io.BytesIO(bytes(before['m_FontData'])));b=TTFont(io.BytesIO(bytes(tree['m_FontData'])))
   table='CFF ' if 'CFF ' in a else 'glyf';result['glyphOutlineTableBytesUnchanged']=a.getTableData(table)==b.getTableData(table);result['glyphOrderUnchanged']=a.getGlyphOrder()==b.getGlyphOrder()
   if table=='CFF ':
    ac=a[table].cff.topDictIndex[0].CharStrings;bc=b[table].cff.topDictIndex[0].CharStrings;same=True
    for glyph in a.getGlyphOrder():
     x=ac[glyph];y=bc[glyph];x.decompile();y.decompile()
     if x.program!=y.program:same=False;break
    result['allGlyphOutlineProgramsUnchanged']=same
   else:result['allGlyphOutlineProgramsUnchanged']=result['glyphOutlineTableBytesUnchanged']
   assert result['glyphOrderUnchanged'] and result['allGlyphOutlineProgramsUnchanged']
  else:
   result['atlasAndGlyphTableUnchanged']=tree['m_GlyphTable']==before['m_GlyphTable'] and tree['m_AtlasTextures']==before['m_AtlasTextures'];result['fallbackReferencesPreserved']=tree['m_FallbackFontAssetTable']==before['m_FallbackFontAssetTable'];assert result['atlasAndGlyphTableUnchanged'] and result['fallbackReferencesPreserved']
   refs=[]
   for ptr in tree['m_FallbackFontAssetTable']:
    cab=o.assets_file.name if ptr['m_FileID']==0 else o.assets_file.externals[ptr['m_FileID']-1].path.split('/')[-1];target=registry.get((cab.lower(),ptr['m_PathID']));assert target is not None
    td=target.read_typetree();source=td['m_SourceFontFile'];scab=target.assets_file.name if source['m_FileID']==0 else target.assets_file.externals[source['m_FileID']-1].path.split('/')[-1];sf=registry.get((scab.lower(),source['m_PathID']));assert sf is not None
    refs.append({'fallback':td['m_Name'],'dynamic':td['m_AtlasPopulationMode']==1,'sourceFont':sf.read_typetree()['m_Name'],'sourcePathId':sf.path_id})
   result['resolvedFallbacks']=refs
  results.append(result)
 reports.append({'segment':row['segmentCandidate'],'validation':results})
(OUT/'segment-validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(reports,ensure_ascii=False,indent=2))
