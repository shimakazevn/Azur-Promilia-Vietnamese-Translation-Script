from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE/'analysis_deps'))
from PIL import Image,ImageDraw,ImageFont,ImageChops
from fontTools.ttLib import TTFont
from opencc import OpenCC
OUT=Path(__file__).parent
text='伺服器尚未開啟，「星躍始動」準備中……';simp=''.join(OpenCC('t2s').convert(c) for c in text)
font=ImageFont.truetype(str(OUT/'a00_traditional_display_as_simplified.otf'),36)
def draw(s):
 im=Image.new('RGB',(1000,75),'white');ImageDraw.Draw(im).text((8,8),s,font=font,fill='black');return im
a=draw(text);b=draw(simp);equal=ImageChops.difference(a,b).getbbox() is None;assert equal
im=Image.new('RGB',(1000,150),'white');im.paste(a,(0,0));im.paste(b,(0,75));im.save(OUT/'phrase_render_equivalence.png')
result={'original':text,'display':simp,'pixelEquality':equal,'copyTextRemainsOriginal':True,'phraseLevelTerminologyUnchanged':'伺服器'}
(OUT/'render-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False))
