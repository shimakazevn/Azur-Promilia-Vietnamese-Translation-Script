from pathlib import Path
import sys,struct,json,hashlib,io
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_decrypt_bundle'),str(BASE/'game_compare_manifests'),str(BASE/'analysis_deps')]
from unity_setup import UnityPy
from reencrypt_bundle import wrap
from fontTools.ttLib import TTFont
from parse_manifest import parse
from patch_manifest import encode_name
OUT=Path(__file__).resolve().parent
ROOT=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
spec=[('a00',ROOT/'StreamingAssets/.res/default_package/a66pm5ie1rrjguuzlsyq.r'),('c00',ROOT/'StreamingAssets/.res/default_package/p4hifvtlpthiunufa1lslg.r'),('sdf',ROOT/'StreamingAssets/.res/default_package/db0aboccfhk0ruhzeueydq.r'),('b00',ROOT/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r')]
fonts={n:(OUT/(n+'_traditional_display_as_simplified.otf')).read_bytes() for n in ['a00','b00','c00']}
maps={n:TTFont(io.BytesIO(b)).getBestCmap() for n,b in fonts.items()}
originals={n:TTFont(BASE/'game_decrypt_bundle'/f).getBestCmap() for n,f in [('a00','cn_a00.otf'),('b00','cn_b00.otf'),('c00','official_chs_c00.otf')]}
changedcp=set().union(*[{cp for cp,g in m.items() if originals[n].get(cp)!=g} for n,m in maps.items()])
manifestpaths=[ROOT/'StreamingAssets/.res/default_package/0release_default_package_3060618.bytes',ROOT/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes']
manifests=[(p,parse(p)) for p in manifestpaths]
report=[]
for name,p in spec:
 raw=p.read_bytes();off=0
 while off<len(raw):
  size=struct.unpack_from('>Q',raw,off+24)[0];segment=raw[off:off+size];env=UnityPy.load(segment);bundle=next(iter(env.files.values()));before={o.path_id:o.get_raw_data() for o in env.objects};mutations=[]
  for o in env.objects:
   if o.type.name=='Font' and name in fonts:
    tree=o.read_typetree()
    if tree['m_Name']!=name:continue
    tree['m_FontData']=list(fonts[name]);o.save_typetree(tree);mutations.append({'type':'Font','pathId':o.path_id,'name':tree['m_Name'],'cmapRemap':True})
   elif o.type.name=='MonoBehaviour':
    try:tree=o.read_typetree()
    except Exception:continue
    if tree.get('m_AtlasPopulationMode')!=0 or 'm_CharacterTable' not in tree:continue
    old=tree['m_CharacterTable'];new=[r for r in old if r['m_Unicode'] not in changedcp]
    if len(new)==len(old):continue
    tree['m_CharacterTable']=new;o.save_typetree(tree);mutations.append({'type':'TMP','pathId':o.path_id,'name':tree['m_Name'],'removedCharacters':len(old)-len(new),'fallback':tree['m_FallbackFontAssetTable']})
  if mutations:
   plain=bundle.save(packer='lz4');candidate,nblocks=wrap(plain,segment);dest=OUT/(name+'_offset'+str(off)+'_display_segment.r');dest.write_bytes(candidate)
   check=UnityPy.load(candidate);after={o.path_id:o.get_raw_data() for o in check.objects};changed=[i for i in before if before[i]!=after[i]];assert set(changed)=={m['pathId'] for m in mutations}
   refs=[]
   for mp,m in manifests:
    packids=[i for i,pack in enumerate(m['packs']) if encode_name(pack['name0'],pack['name1'])==p.name]
    for pi in packids:
     for bi,b in enumerate(m['bundles']):
      if b['pack_id']==pi and b['offset']==off:refs.append({'manifestPath':str(mp),'bundleIndex':bi,'packIndex':pi,'offset':off,'oldSize':b['size'],'sourceSizeMatches':b['size']==size})
   report.append({'sourcePack':str(p),'currentSHA256':hashlib.sha256(raw).hexdigest(),'offset':off,'oldSize':size,'segmentCandidate':str(dest),'candidateSize':len(candidate),'candidateSHA256':hashlib.sha256(candidate).hexdigest(),'mutations':mutations,'manifests':refs,'unrelatedObjectBytesPreserved':True,'blockRoundtrips':nblocks})
  off+=size
(OUT/'segment-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
