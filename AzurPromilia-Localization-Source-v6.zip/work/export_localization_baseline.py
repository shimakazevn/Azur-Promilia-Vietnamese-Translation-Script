import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "analysis_deps"))
import UnityPy

ROOT = Path(r"E:\AzurPromilia_TC\AzurPromilia_TC_game")
DATA = ROOT / "AzurPromilia_Data"
OUT = HERE.parent / "outputs"
OUT.mkdir(exist_ok=True)
env = UnityPy.load(str(DATA / "resources.assets"))
assets = {}
for obj in env.objects:
    if obj.type.name == "TextAsset":
        asset = obj.read()
        assets[asset.m_Name] = (obj, asset.m_Script)

table = assets["builtInLangString"][1].lstrip("\ufeff")
(OUT / "启动界面语言表.csv").write_text(table, encoding="utf-8-sig")
rows = list(csv.DictReader(io.StringIO(table)))
config = json.loads(assets["appConfig"][1])
safe_config = {key: config.get(key) for key in (
    "appVersion", "assetVersion", "channel", "region", "language",
    "supportedLanguage", "configVersionPatch",
)}
(OUT / "语言配置摘录.json").write_text(
    json.dumps(safe_config, ensure_ascii=False, indent=2), encoding="utf-8"
)
path_tokens = assets["txt_buildInAssetPathMap"][1].lstrip("\ufeff").splitlines()
(HERE / "built_in_path_tokens.txt").write_text("\n".join(path_tokens), encoding="utf-8")

def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(path.relative_to(ROOT)), "size": path.stat().st_size,
            "sha256": digest.hexdigest()}

bundle_summary = []
with gzip.open(HERE / "tc_bundle_inventory.jsonl.gz", "wt", encoding="utf-8") as stream:
    for base in (DATA / "StreamingAssets" / ".res", DATA / ".res"):
        for package in sorted(base.iterdir()):
            if not package.is_dir():
                continue
            files = list(package.rglob("*.r"))
            total = 0
            for path in files:
                size = path.stat().st_size
                total += size
                stream.write(json.dumps({"path": str(path.relative_to(ROOT)), "size": size}) + "\n")
            bundle_summary.append({"path": str(package.relative_to(ROOT)),
                                   "count": len(files), "bytes": total})

identities = [identity(DATA / name) for name in (
    "resources.assets", "globalgamemanagers.assets", "globalgamemanagers"
)]
for base in (DATA / "StreamingAssets" / ".res", DATA / ".res"):
    for path in sorted(base.rglob("0release_*.bytes")):
        identities.append(identity(path))

baseline = {
    "date": "2026-11-24", "game_root": str(ROOT),
    "method": "Read-only local file parsing with UnityPy 1.25.4 and saved game logs. No game file or registry modification.",
    "language_config": safe_config,
    "bootstrap_table": {"source": "AzurPromilia_Data/resources.assets",
                        "name": "builtInLangString", "path_id": 209,
                        "rows": len(rows), "columns": list(rows[0]),
                        "scope": "startup, update, download, errors, early UI"},
    "app_config": {"source": "AzurPromilia_Data/resources.assets", "name": "appConfig", "path_id": 216},
    "path_dictionary": {"source": "AzurPromilia_Data/resources.assets", "name": "txt_buildInAssetPathMap",
                        "path_id": 223, "token_count": len(path_tokens),
                        "caution": "Directory/name tokens only; these do not reconstruct complete paths on their own."},
    "localization_module_names": ["Lens.Gameplay.Managers.I18NManager.I18NManager",
                                  "LangAssetManifest", "II18NTranslator", "SettingItem_Language"],
    "encrypted_bundle_probe": {"sample": "AzurPromilia_Data/StreamingAssets/.res/static_package/3kuwgykc0rdjxcshnnjsq.r",
                               "result": "UnityPy reports encrypted AssetBundle; no decryption key provided."},
    "full_game_text_table": {"status": "unresolved", "reason": "No full dialogue/item/UI table has been extracted or mapped to a specific .r file."},
    "bundles": bundle_summary, "source_identities": identities,
}
(OUT / "繁体版语言基线.json").write_text(json.dumps(baseline, ensure_ascii=False, indent=2), encoding="utf-8")

report = f"""# 《蓝色星原：旅谣》繁体版语言资源定位

检查日期：2026-11-24。游戏目录：`{ROOT}`。

## 已确认的文字资源

`{DATA / 'resources.assets'}` 是 Unity 资源文件，以下对象嵌在文件内部，并非独立的同名文件。

| 内部对象 | Path ID | 已确认用途 |
|---|---:|---|
| builtInLangString | 209 | 启动、更新、下载、错误提示等早期界面文字，共 {len(rows)} 条 |
| appConfig | 216 | 客户端语言、地区、支持语言和渠道配置 |
| txt_buildInAssetPathMap | 223 | {len(path_tokens)} 个资源路径词元；包含 ResourcesLang、NewTable、Lua、lang、chs、cht |
| chineseCharacters | 214 | 字符列表；不能单凭该列表认定字体覆盖完整 |

`builtInLangString` 已解析并导出为 `启动界面语言表.csv`。表头为 `key,chs,cht,en,jp,kr`，可直接观察简繁对应，例如 `confirm` 的 `chs=确定`、`cht=確定`。此表的内容不能代表全部剧情、道具和游戏内 UI 文本。

## 当前语言配置

```json
{json.dumps(safe_config, ensure_ascii=False, indent=2)}
```

当前配置将文字语言与地区分别设为 `cht`，支持列表为 `cht` 和 `en`。虽然启动文本表已有 `chs` 列，但尚无证据证明完整简体游戏文本也已随繁体客户端提供。不能据此认定把 `language` 改为 `chs` 就能完成全游戏切换。

## 游戏内语言模块与资源容器

`globalgamemanagers.assets` 可解析到以下脚本类型标识：`I18NManager`、`LangAssetManifest`、`II18NTranslator`、`SettingItem_Language`。日志中也记录了 `I18NManager.Initialize`，所以本地化模块并非仅由目录名推测。

安装资源位于 `{DATA / 'StreamingAssets' / '.res'}`；更新缓存位于 `{DATA / '.res'}`。各目录包含 `default_package`、`raw_base_package`、`raw_nostreaming_package`、`raw_streaming_package` 等资源分包。目录和分包名本身不能证明某个文件就是文字表。

已有资源清单分别标记为 `3060618` 与 `3221745`；运行日志记录的资源版本为 `3060618.3221745.3221745.3221745.3221745`。后续对比简体客户端应同时检查安装资源和更新缓存，避免只比较旧的内置文件。

对 `static_package/3kuwgykc0rdjxcshnnjsq.r` 的实际解析返回“AssetBundle 已加密，未提供密钥”。这确认至少该样本受加密保护；不据此断言所有分包使用相同封装。

路径词元中的 `ResourcesLang`、`NewTable`、`Lua`、`lang` 是下一步定位线索，尚未还原为完整虚拟路径，也尚未映射到具体 `.r` 文件。

## 当前边界与后续对比

已完成：启动文字表定位及导出；语言配置定位及安全字段摘录；本地化模块确认；安装包和缓存目录基线。

尚未完成：剧情、道具说明、技能描述等完整文本表到具体 `.r` 文件的映射；加密资源的解包；替换后客户端的加载与校验验证。

简体客户端下载后，优先比较这两份 `resources.assets` 的语言对象、`LangAssetManifest` 对应资源、各分包清单和字体引用。当前未修改游戏文件或注册表，未启动或注入游戏进程。

辅助工具限制：REA CLI 诊断因缺少其 MCP 客户端依赖而未能运行；本报告证据来自普通文件读取、UnityPy 解析和本机既有日志，不是 REA Evidence。
"""
(OUT / "游戏语言定位报告.md").write_text(report, encoding="utf-8")
print(json.dumps({"rows": len(rows), "columns": list(rows[0]), "outputs": [p.name for p in OUT.iterdir()], "config": safe_config}, ensure_ascii=False))
