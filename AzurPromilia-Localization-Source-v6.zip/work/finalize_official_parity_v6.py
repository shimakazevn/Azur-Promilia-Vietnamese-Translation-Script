from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v6';STABLE=ROOT/'work/official_game_patch'
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'))
data=Path(plan['data_root']);backup=data.parent/'.zhcn-official-3221745-backup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in plan['files']:
 assert sha(data/f['relative_path'])==f['target_sha256'],f['relative_path']
 assert sha(backup/f['relative_path'])==f['source_sha256'],f['relative_path']
 assert sha(Path(f['candidate']))==f['target_sha256'],f['relative_path']
for f in plan['required_unchanged_files']:assert sha(data/f['relative_path'])==f['sha256']
archive=STABLE/'deployment-plan.v5.json'
if not archive.exists():
 assert json.loads((STABLE/'deployment-plan.json').read_text('utf8'))['patch_revision']==5
 archive.write_bytes((STABLE/'deployment-plan.json').read_bytes())
for name in ['deployment-plan.json','Apply-OfficialZH.ps1']:
 t=STABLE/(name+'.stage');t.write_bytes((OUT/name).read_bytes());t.replace(STABLE/name)
report=dict(applied=True,patch_revision=6,applied_at=datetime.datetime.now().astimezone().isoformat(),installed_files_verified=len(plan['files']),original_backups_verified=len(plan['files']),candidates_verified=len(plan['files']),language='cht',runtime_verified=False,backup_directory=str(backup),ui_v2=plan['ui_v2'],residual_v3=plan['residual_v3'],official_parity_v4=plan['official_parity_v4'],official_parity_v5=plan['official_parity_v5'],official_parity_v6=plan['official_parity_v6'],verified_files=[f['relative_path'] for f in plan['files']])
for p in [OUT/'installed-verification.json',STABLE/'installed-verification.json',ROOT/'outputs/台服游戏官方简体应用记录.json']:p.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
dp=ROOT/'outputs/台服游戏官方简体替换说明.md';doc=dp.read_text('utf8')
doc=doc.replace('（官方用词补漏第五版）','（官方用词补漏第六版）').replace('升级到第五版','升级到第六版').replace('第五版19个安装文件','第六版19个安装文件')
ch=plan['official_parity_v6']['changes']
lines='\n'.join(f"- `{c['before']}` → `{c['after']}`" for c in ch)
doc=doc.replace('## 第五版：登录程序与官方专用字形',f'''## 第六版：台服独有界面文字改用国服写法

StaticText 中590项台服独有条目此前只做了字形转简，仍保留台湾用词。第六版修正29条：

- 24条：台服原文在台服语言表中有完全相同的句子，取国服同表同ID的官方译文。
- 5条：无国服来源，按国服文本里几乎统一的用词替换（机率→概率、网路→网络、回圈→循环、资讯→信息）。
- 3条（普通攻击/普攻、Max/MAX）国服有多种写法，保持不变。

{lines}

## 第五版：登录程序与官方专用字形''')
doc=doc.replace('`work/official_game_patch_v5`','`work/official_game_patch_v5`、`work/official_game_patch_v6`')
dp.write_text(doc,'utf8');print(json.dumps(dict(revision=6,verified=len(plan['files']))))