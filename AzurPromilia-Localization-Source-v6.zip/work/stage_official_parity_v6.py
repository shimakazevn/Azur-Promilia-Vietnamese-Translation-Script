from pathlib import Path
import sys,json,hashlib,copy
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/game_decrypt_bundle'),str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/analysis_deps')]
from unity_setup import UnityPy
from reencrypt_bundle import wrap
from parse_manifest import parse
from patch_manifest import encode_name,replace_pack_segments,patch_manifest
from vstring_pool import VStringPool
sha=lambda b:hashlib.sha256(b).hexdigest()
OUT=ROOT/'work/official_game_patch_v6';OUT.mkdir(exist_ok=True)
STABLE=ROOT/'work/official_game_patch'
plan=json.loads((STABLE/'deployment-plan.json').read_text('utf8'));assert plan['patch_revision']==5
data=Path(plan['data_root'])
for f in plan['files']:assert sha((data/f['relative_path']).read_bytes())==f['target_sha256'],f['relative_path']
mp=data/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes';mbytes=mp.read_bytes();m=parse(mp)
sp=VStringPool(ROOT/'work/game_mmap/decoded/tw_update_v0k2cafcxjxawklow6skg.bin')
a=next(a for a in m['assets'] if sp[a['path_key']]=='Assets/ResourcesLang/cht/UI/StaticText/ast_staticTextKeyConfig.asset')
bi=a['bundle'];b=m['bundles'][bi];pk=m['packs'][b['pack_id']];name=encode_name(pk['name0'],pk['name1']);pack=data/'.res/default_package/BundleFiles'/name
assert pack.exists() and name=='owmxh3bjdhcwjoabqv67q.r'
original=pack.read_bytes();seg=original[b['offset']:b['offset']+b['size']]
env=UnityPy.load(seg);obj=next(o for o in env.objects if o.type.name=='MonoBehaviour');before={o.path_id:o.get_raw_data() for o in env.objects}
tree=obj.read_typetree();rows={r['key']:r for r in tree['list']}
der=json.loads((ROOT/'work/audit_v6/statictext-twonly-official-derivation.json').read_text('utf8'))
changes=[];skipped=[]
for x in der['mapped']:
 if not x['changes']:continue
 r=rows[x['key']]
 if x['alternatives']>1:skipped.append(dict(key=x['key'],current=r['value'],candidates='multiple official renderings',top=x['officialCN']));continue
 assert r['value']==x['current'],x['key']
 changes.append(dict(key=x['key'],before=r['value'],after=x['officialCN'],basis='CN same table+ID translation of identical TW source text'));r['value']=x['officialCN']
terms=[('机率','概率'),('网路','网络'),('回圈','循环'),('资讯','信息')]
unm={x['key'] for x in der['unmapped']}
for k in sorted(unm):
 r=rows[k];v=r['value'];nv=v
 for t,c in terms:nv=nv.replace(t,c)
 if nv!=v:changes.append(dict(key=k,before=v,after=nv,basis='CN corpus uniform term (TW term count 0-3 vs CN term 15-628)'));r['value']=nv
obj.save_typetree(tree);plain=next(iter(env.files.values())).save(packer='lz4');newseg,nblocks=wrap(plain,seg)
check=UnityPy.load(newseg);after={o.path_id:o.get_raw_data() for o in check.objects};assert [i for i in before if before[i]!=after[i]]==[obj.path_id]
assert next(o for o in check.objects if o.path_id==obj.path_id).read_typetree()==tree
assert mp.with_suffix('.hash').read_bytes()==hashlib.md5(mbytes).hexdigest().encode('ascii')
newpack,newman,mhash,rep=replace_pack_segments(mbytes,pack,{bi:newseg},original)
_,_,r2=patch_manifest(newman,pack,newpack,newpack);assert r2['original_validated']
staged={}
for src,payload in [(pack,newpack),(mp,newman),(mp.with_suffix('.hash'),hashlib.md5(newman).hexdigest().encode('ascii'))]:
 dest=OUT/src.relative_to(data);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload);staged[src]=dest
for src,dest in staged.items():
 rel=src.relative_to(data).as_posix();e=next(f for f in plan['files'] if f['relative_path']==rel)
 e['previous_sha256']=sorted(set(e.get('previous_sha256',[])+[e['target_sha256']]))
 e.update(target_sha256=sha(dest.read_bytes()),candidate=str(dest),size=dest.stat().st_size)
plan['patch_revision']=6;plan['runtime_tested']=False
plan['official_parity_v6']=dict(statictext_official_derived=sum(c['basis'].startswith('CN same') for c in changes),statictext_term_unified=sum(c['basis'].startswith('CN corpus') for c in changes),statictext_ambiguous_kept=skipped,changes=changes,
 unresolved=['远端公告词汇（伺服器等）尚无可验证的显示处理入口','台服独有StaticText其余条目无国服来源，仅字形转简','SDK与sdkbrowser加载需运行验证'])
(OUT/'deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
(OUT/'Apply-OfficialZH.ps1').write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
(OUT/'stage-report.json').write_text(json.dumps(dict(installed_modified=False,bundle_index=bi,old_segment=len(seg),new_segment=len(newseg),blocks=nblocks,manifest_report=rep,changes=changes,skipped=skipped),ensure_ascii=False,indent=2,default=str),'utf8')
print(json.dumps(dict(revision=6,files=len(plan['files']),changes=len(changes),skipped=len(skipped),staged=[str(v) for v in staged.values()]),ensure_ascii=False))
for c in changes:print(c['key'],'|',c['before'][:40],'=>',c['after'][:40])