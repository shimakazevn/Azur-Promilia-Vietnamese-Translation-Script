from pathlib import Path
import datetime, hashlib, json

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'work/official_game_patch_v2'
STABLE = ROOT / 'work/official_game_patch'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((OUT / 'deployment-plan.json').read_text('utf8'))
data = Path(plan['data_root'])
backup = data.parent / '.zhcn-official-3221745-backup'
verified = []
for f in plan['files']:
    assert sha(data / f['relative_path']) == f['target_sha256'], f['relative_path']
    assert sha(backup / f['relative_path']) == f['source_sha256'], f['relative_path']
    assert sha(Path(f['candidate'])) == f['target_sha256'], f['relative_path']
    verified.append(f['relative_path'])
for f in plan['required_unchanged_files']:
    assert sha(data / f['relative_path']) == f['sha256'], f['relative_path']

old_archive = STABLE / 'deployment-plan.v1.json'
if not old_archive.exists():
    assert json.loads((STABLE / 'deployment-plan.json').read_text('utf8')).get('patch_revision', 1) == 1
    old_archive.write_bytes((STABLE / 'deployment-plan.json').read_bytes())
# Keep the existing BAT entry point and V1 payloads, but promote its plan and deployer.
for name, payload in [
    ('deployment-plan.json', (OUT / 'deployment-plan.json').read_bytes()),
    ('Apply-OfficialZH.ps1', (OUT / 'Apply-OfficialZH.ps1').read_bytes()),
]:
    stage = STABLE / (name + '.stage')
    stage.write_bytes(payload)
    stage.replace(STABLE / name)

report = dict(applied=True, patch_revision=2,
    applied_at=datetime.datetime.now().astimezone().isoformat(),
    installed_files_verified=len(verified), original_backups_verified=len(verified),
    candidates_verified=len(verified), language='cht', runtime_verified=False,
    backup_directory=str(backup), verified_files=verified,
    inherited_main_language_patch=True, ui_v2=plan['ui_v2'],
    stable_bat=str(ROOT / 'outputs/台服游戏官方简体替换与还原.bat'))
payload = json.dumps(report, ensure_ascii=False, indent=2)
for p in [OUT / 'installed-verification.json', STABLE / 'installed-verification.json',
          ROOT / 'outputs/台服游戏官方简体应用记录.json']:
    p.write_text(payload, 'utf8')

doc = '''# 台服游戏官方简体替换试验（补漏第二版）

已安装到 `E:\\AzurPromilia_TC\\AzurPromilia_TC_game`。游戏语言仍为 `cht`。

## 覆盖内容

- 延续第一版357张语言表：按表名与文本ID匹配国服，实际替换131,439条不同文案；保留台服区服内容。台服特有26条提示按既有规则补齐。
- 新增独立StaticText静态界面表3232条：2642条按同key匹配国服，590条台服独有内容转简；共2390条变化，包括“关闭”“开启”“恢复默认设置”。
- 新增热更新启动CSV：101条cht文案替换为同表官方chs文案，包括“正在检查更新…”及下载、错误弹窗等；其他语言列保持。
- 健康/癫痫警告页使用国服同ID、同尺寸官方简体图，配套Sprite网格一并替换，保留台服资源对象ID。
- 字体补救：为现有a00/b00/c00字体添加繁体码位到简体字形映射；四份静态TMP表移除对应繁体静态字，使之通过动态字体回退显示。保留字形轮廓、图集及加载依赖。

## 已知边界

服务器公告不在本地语言表中。字体方案只改变显示字形，复制文本仍是服务器原始文字，也不会将“伺服器”改成“服务器”。例如原公告预期显示为“伺服器尚未开启，「星跃始动」准备中……”。字体显示小样已验证，游戏内效果待确认。

截图中的“登入成功 / 切換帳號”仍在追踪来源，本版尚未确认覆盖，不能称为全部汉化。其他未检查界面、独立字体及图片也可能存在遗漏。

## 使用及还原

双击同目录 `台服游戏官方简体替换与还原.bat`：

1. 应用或升级到第二版。
2. 还原本工具修改的17个文件至第一版安装前备份。
3. 检查当前状态。

原始资源备份：`E:\\AzurPromilia_TC\\AzurPromilia_TC_game\\.zhcn-official-3221745-backup`。

保留工作区 `work/official_game_patch`、`work/official_game_patch_v2`，BAT依赖这些目录中的脚本及资源。第一版候选和原始备份未覆盖；新版支持从第一版升级，失败回到调用前状态。

此还原操作针对上述17个文件；更早的独立resources.assets启动文字补丁维持既有状态，其原版另保存在 `.before-game-zhcn-20261124.bak`。

## 验证

第二版17个安装文件、17个原始备份及17个候选SHA256一致；合并后所有相关资源段大小、CRC及清单MD5通过。加密往返、警告图像素与Sprite、其他对象保留、字体轮廓及回退引用均已离线验证。部署脚本10项测试通过，覆盖应用、还原、重复应用、未知版本拒绝写入、升级及中途失败回滚。

尚未代用户启动游戏，实际显示待用户重启检查。
'''
(ROOT / 'outputs/台服游戏官方简体替换说明.md').write_text(doc, 'utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ('verified_files','ui_v2')}, ensure_ascii=True), flush=True)
