import hashlib,json,shutil,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).parent.resolve()
m=json.loads((HERE/'game_bootstrap_patch.json').read_text('utf-8'))
folder=HERE/'game_bootstrap_qa'/'游戏 测试 & 路径'/'AzurPromilia_TC_game'
(folder/'AzurPromilia_Data').mkdir(parents=True,exist_ok=True)
shutil.copy2('C:/Windows/System32/cmd.exe',folder/'AzurPromilia.exe')
archive=folder/'AzurPromilia_Data/resources.assets'
shutil.copy2(m['target'],archive)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['original_sha256']
backup=archive.with_name(archive.name+'.before-game-zhcn-20261124.bak')
if backup.exists():
    assert hashlib.sha256(backup.read_bytes()).hexdigest()==m['original_sha256']
    backup.unlink()
bat=folder.parent/'启动文本工具 & 测试.bat'
shutil.copy2(HERE.parent/'outputs/台服游戏启动文本简体试验版.bat',bat)
checks=[]
def run(name,action,expect,success=True,hint=folder,tool=bat):
    command=f'cmd.exe /d /s /c ""{tool}" "{hint}""'
    r=subprocess.run(command,input=action+'\n\n',encoding='utf-8',errors='replace',capture_output=True,timeout=30)
    text=r.stdout+r.stderr
    assert (r.returncode==0)==success,(name,text)
    assert expect in text and 'is not recognized' not in text and '�' not in text,(name,text)
    checks.append(dict(name=name,returncode=r.returncode,output=text))
    print(name,'PASS',flush=True)
def original():assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['original_sha256']
def patched():assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['patched_sha256']
run('quit','Q','完整文本尚未汉化');original()
run('apply','1','启动文本简体补丁已应用。');patched()
assert hashlib.sha256(backup.read_bytes()).hexdigest()==m['original_sha256']
run('repeat_apply','1','当前已经应用启动文本补丁。');patched()
run('restore','2','游戏原文件已还原。');original()
run('repeat_restore','2','当前已经是原文件。');original()
run('reject_cn','1','没有找到匹配的台服游戏',False,hint=r'D:\AzurPromilia\AzurPromilia_Game');original()
shutil.copy2(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data\resources.assets',backup)
run('reject_bad_backup','1','原版备份校验失败',False);original()
shutil.copy2(m['target'],backup)
active=subprocess.Popen([str(folder/'AzurPromilia.exe'),'/d','/q','/k'],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
try:
    run('reject_running_game','1','请先退出台服游戏',False);original()
finally:active.terminate();active.wait(timeout=10)
lf=folder.parent/'LF 换行.bat';lf.write_bytes(bat.read_bytes().replace(b'\r\n',b'\n'))
run('LF_line_endings','Q','完整文本尚未汉化',tool=lf)
(HERE/'game_bootstrap_validation.json').write_text(json.dumps(dict(passed=True,cases=len(checks),checks=checks),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=True,cases=len(checks)),ensure_ascii=False))
