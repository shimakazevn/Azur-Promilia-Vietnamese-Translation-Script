"""Resolve region UI asset counterparts from both active manifests, offline."""
from pathlib import Path
from collections import Counter
import json,sys,gc
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/game_compare_manifests')]
from vstring_pool import VStringPool
from parse_manifest import parse
from patch_manifest import encode_name
OUT=ROOT/'work/official_parity_audit';OUT.mkdir(exist_ok=True)
regions={
 'tw':(Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data'),'0release_default_package_3221745.bytes','tw_update_v0k2cafcxjxawklow6skg.bin','cht'),
 'cn':(Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data'),'00_default_package_3217420.bytes','cn_update_bjzqzapbodx6zodmvtrta.bin','chs')}
catalogs={}
for region,(base,manifest,poolname,locale) in regions.items():
 mp=base/'.res/default_package/ManifestFiles'/manifest;m=parse(mp)
 pool=VStringPool(ROOT/'work/game_mmap/decoded'/poolname)
 rows=[]
 for a in m['assets']:
  path=pool[a['path_key']]
  if not path:continue
  if path.startswith(f'Assets/ResourcesLang/{locale}/') or ('/UI/' in path and path.endswith(('.prefab','.asset'))):
   b=m['bundles'][a['bundle']];name=encode_name(m['packs'][b['pack_id']]['name0'],m['packs'][b['pack_id']]['name1'])
   pack=base/'.res/default_package/BundleFiles'/name
   if not pack.exists():pack=base/'StreamingAssets/.res/default_package'/name
   rows.append(dict(path=path,normalized=path.replace(f'/ResourcesLang/{locale}/','/ResourcesLang/{locale}/'),
                    bundle=a['bundle'],pack=str(pack),offset=b['offset'],size=b['size'],exists=pack.exists()))
 catalogs[region]=rows
 (OUT/f'{region}-ui-catalog.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),'utf8')
 print(region,'assets',len(rows),'regional',sum('/ResourcesLang/' in r['path'] for r in rows),'extensions',dict(Counter(Path(r['path']).suffix for r in rows)),flush=True)
 del m,pool;gc.collect()
cn={r['normalized']:r for r in catalogs['cn']}
matching=[dict(tw=r,cn=cn.get(r['normalized'])) for r in catalogs['tw']]
(OUT/'ui-counterparts.json').write_text(json.dumps(matching,ensure_ascii=False,indent=2),'utf8')
report=dict(tw=len(matching),matched=sum(x['cn'] is not None for x in matching),unmatched=[x['tw']['path'] for x in matching if x['cn'] is None])
(OUT/'ui-catalog-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k!='unmatched'}),flush=True)
