from pathlib import Path
from collections import defaultdict
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v5';OUT.mkdir(exist_ok=True)
STABLE=ROOT/'work/official_game_patch'
sys.path.insert(0,str(ROOT/'work/game_compare_manifests'))
from patch_manifest import replace_pack_segments,patch_manifest
sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads((STABLE/'deployment-plan.json').read_text('utf8'));assert plan['patch_revision']==4
data=Path(plan['data_root'])
for f in plan['files']:assert sha((data/f['relative_path']).read_bytes())==f['target_sha256'],f['relative_path']
groups=defaultdict(lambda:dict(sha=None,manifests=defaultdict(dict)))
for item in json.loads((ROOT/'work/font_official_glyph_v5/segment-plan.json').read_text('utf8')):
 p=Path(item['sourcePack']);g=groups[p];assert g['sha'] in (None,item['currentSHA256']);g['sha']=item['currentSHA256']
 payload=Path(item['segmentCandidate']).read_bytes();assert sha(payload)==item['candidateSHA256']
 for m in item['manifests']:g['manifests'][Path(m['manifestPath'])][m['bundleIndex']]=payload
staged={};manifests={};reports=[]
for p,g in groups.items():
 original=p.read_bytes();assert sha(original)==g['sha'],str(p);packed=None
 for mp,rep in g['manifests'].items():
  if mp not in manifests:
   manifests[mp]=mp.read_bytes();assert mp.with_suffix('.hash').read_bytes()==hashlib.md5(manifests[mp]).hexdigest().encode('ascii')
  out,nm,_,r=replace_pack_segments(manifests[mp],p,rep,original)
  if packed is not None:assert packed==out
  packed=out;manifests[mp]=nm;reports.append(dict(pack=str(p),manifest=str(mp),**r));print('Staged',p.name,'in',mp.name,flush=True)
 dest=OUT/p.relative_to(data);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);staged[p]=dest
for mp,payload in manifests.items():
 for p,g in groups.items():
  if mp in g['manifests']:
   cur=staged[p].read_bytes();_,_,r=patch_manifest(payload,p,cur,cur);assert r['original_validated']
 dest=OUT/mp.relative_to(data);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 dest.with_suffix('.hash').write_bytes(hashlib.md5(payload).hexdigest().encode('ascii'))
 staged[mp]=dest;staged[mp.with_suffix('.hash')]=dest.with_suffix('.hash')
for p,c in staged.items():
 rel=p.relative_to(data).as_posix();e=next(f for f in plan['files'] if f['relative_path']==rel)
 e['previous_sha256']=sorted(set(e.get('previous_sha256',[])+[e['target_sha256']]))
 e.update(target_sha256=sha(c.read_bytes()),candidate=str(c),size=c.stat().st_size)
val=json.loads((ROOT/'work/game_decrypt_paths/sdk_qm/sdkbrowser-candidate-validation.json').read_text('utf8'))
rel='Plugins/mj_sdk/sdkbrowser.exe';inst=data/rel;cand=ROOT/'work/game_decrypt_paths/sdk_qm/sdkbrowser.mainland-common-plus-global.candidate.exe'
assert sha(inst.read_bytes())==val['original_sha256'];assert sha(cand.read_bytes())==val['candidate_sha256'];assert inst.stat().st_size==cand.stat().st_size
assert not any(f['relative_path']==rel for f in plan['files'])
plan['files'].append(dict(relative_path=rel,source_sha256=val['original_sha256'],target_sha256=val['candidate_sha256'],candidate=str(cand),size=cand.stat().st_size,previous_sha256=[]))
plan['patch_revision']=5;plan['runtime_tested']=False
plan['official_parity_v5']=dict(sdkbrowser_qm_replaced=True,sdkbrowser_qm_identical_to_v4_dll=val['qm_identical_to_original_dll_zhTW'],sdkbrowser_code_unchanged=True,sdkbrowser_original_signature=val['signature_original'],sdkbrowser_modified_signature=val['signature_candidate'],font_official_glyphs_restored=['U+4E7E 乾','U+7B8B 箋'],font_official_glyphs_kept=['U+95C7 闇'],ui_direct_text_fields=18719,ui_direct_text_identical=18719,ui_direct_text_different=0,placeholder_texts_not_restored='宠物说明默认繁体占位与日文商店占位文本在国服预制体中同样存在，运行时由语言表覆盖；为不影响远端繁体文字显示，未恢复 個內圍惡於範義釋飾點償無聖 原字形',unresolved=['远端公告词汇（伺服器等）尚无可验证的显示处理入口','台服独有条目无同ID国服来源','SDK与sdkbrowser加载需运行验证'])
(OUT/'deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
(OUT/'Apply-OfficialZH.ps1').write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
(OUT/'integration-report.json').write_text(json.dumps(dict(installed_modified=False,files=len(plan['files']),segment_changes=reports,staged=[str(v) for v in staged.values()]),ensure_ascii=False,indent=2),'utf8')
print(json.dumps(dict(revision=5,files=len(plan['files']),changed=[p.relative_to(data).as_posix() for p in staged]+[rel]),ensure_ascii=False),flush=True)