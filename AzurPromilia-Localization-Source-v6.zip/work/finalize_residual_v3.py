from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v3';STABLE=ROOT/'work/official_game_patch'
plan=json.loads((OUT/'deployment-plan.json').read_text('utf8'))
data=Path(plan['data_root']);backup=data.parent/'.zhcn-official-3221745-backup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in plan['files']:
 assert sha(data/f['relative_path'])==f['target_sha256'],f['relative_path']
 assert sha(backup/f['relative_path'])==f['source_sha256'],f['relative_path']
 assert sha(Path(f['candidate']))==f['target_sha256'],f['relative_path']
for f in plan['required_unchanged_files']:assert sha(data/f['relative_path'])==f['sha256']
archive=STABLE/'deployment-plan.v2.json'
if not archive.exists():
 assert json.loads((STABLE/'deployment-plan.json').read_text('utf8'))['patch_revision']==2
 archive.write_bytes((STABLE/'deployment-plan.json').read_bytes())
for name in ['deployment-plan.json','Apply-OfficialZH.ps1']:
 temporary=STABLE/(name+'.stage');temporary.write_bytes((OUT/name).read_bytes());temporary.replace(STABLE/name)
report=dict(applied=True,patch_revision=3,applied_at=datetime.datetime.now().astimezone().isoformat(),
 installed_files_verified=len(plan['files']),original_backups_verified=len(plan['files']),
 candidates_verified=len(plan['files']),language='cht',runtime_verified=False,
 backup_directory=str(backup),ui_v2=plan['ui_v2'],residual_v3=plan['residual_v3'],
 verified_files=[f['relative_path'] for f in plan['files']])
for path in [OUT/'installed-verification.json',STABLE/'installed-verification.json',ROOT/'outputs/台服游戏官方简体应用记录.json']:
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
docpath=ROOT/'outputs/台服游戏官方简体替换说明.md'
doc=docpath.read_text('utf8')
doc=doc.replace('（补漏第二版）','（补漏第三版）').replace('升级到第二版','升级到第三版').replace('检查和还原第二版','检查和还原第三版')
doc=doc.replace('## 覆盖内容','''## 第三版精确修正

- `未入駐` → `未入驻`。
- `当前状态不能切換` → `当前状态不能切换`。
- 启动CSV的 `shader_loading`：`正在編譯著色器` → `正在编译着色器`；该项官方chs栏为空，因此另作精确补充。
- 保留官方专名 `闇星庇佑`。三套字体同时恢复“闇”的原始字形，避免第二版的显示映射将它显示成“暗”。其余字体映射保持。
- 仅改上述两条cht主表记录和一条cht启动提示；其他语言行、旧池键值、健康警告图及第二版其他对象保持。

## 覆盖内容''')
doc=doc.replace('`work/official_game_patch_v2`','`work/official_game_patch_v2`、`work/official_game_patch_v3`')
doc=doc.replace('第二版17个安装文件','第三版17个安装文件')
docpath.write_text(doc,'utf8')
print(json.dumps(dict(revision=3,verified_files=len(plan['files']),runtime_verified=False),ensure_ascii=True),flush=True)
