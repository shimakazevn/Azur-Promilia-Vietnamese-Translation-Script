"""Exercise actual Windows PowerShell apply/restore and failure rollback on fixtures."""
from pathlib import Path
import subprocess,json,hashlib,uuid
ROOT=Path(__file__).resolve().parent.parent
test=ROOT/'work/deployer-tests'/uuid.uuid4().hex
data=test/'game/AzurPromilia_Data';data.mkdir(parents=True)
script=test/'Apply-OfficialZH.ps1'
script.write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
sha=lambda b:hashlib.sha256(b).hexdigest()
original=[b'original-a\0\xff',b'original-b\n']
patched=[b'new-simplified-a\0',b'new-font-b\x80']
files=[]
for i in range(2):
 rel=f'resources/file{i}.bin';p=data/rel;p.parent.mkdir(exist_ok=True);p.write_bytes(original[i])
 c=test/f'candidate{i}.bin';c.write_bytes(patched[i])
 files.append(dict(relative_path=rel,source_sha256=sha(original[i]),target_sha256=sha(patched[i]),candidate=str(c)))
plan=test/'plan.json';plan.write_text(json.dumps(dict(data_root=str(data),game_root=str(data.parent),files=files)),'utf8')
def run(action):
 p=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),'-Action',action,'-PlanPath',str(plan)],capture_output=True)
 return p.returncode,p.stdout.decode('utf8','replace'),p.stderr.decode('utf8','replace')
def state():return [(data/r['relative_path']).read_bytes() for r in files]
results=[]
rc,out,err=run('Apply');assert rc==0,(rc,out,err);assert state()==patched;results.append('apply_and_sha_verification')
rc,out,err=run('Apply');assert rc==0 and state()==patched;results.append('apply_idempotent')
rc,out,err=run('Restore');assert rc==0,(rc,out,err);assert state()==original;results.append('restore_byte_exact')
# Hold the second file open, denying replacement, after the first write succeeds.
with (data/files[1]['relative_path']).open('rb') as locked:
 rc,out,err=run('Apply')
 assert rc!=0,(out,err)
assert state()==original,(out,err,state());results.append('apply_partial_failure_rolls_back')
assert run('Apply')[0]==0
with (data/files[1]['relative_path']).open('rb') as locked:
 rc,out,err=run('Restore');assert rc!=0,(out,err)
assert state()==patched,(out,err,state());results.append('restore_partial_failure_rolls_back')
assert run('Restore')[0]==0
(data/files[1]['relative_path']).write_bytes(b'unknown version')
rc,out,err=run('Apply');assert rc!=0;assert (data/files[0]['relative_path']).read_bytes()==original[0];results.append('version_mismatch_prevents_any_write')
(data/files[1]['relative_path']).write_bytes(original[1])
assert run('Apply')[0]==0
v2=[b'updated-a-v2',b'updated-b-v2']
for i,entry in enumerate(files):
 entry['previous_sha256']=[entry['target_sha256']]
 entry['target_sha256']=sha(v2[i])
 c=test/f'candidate-v2-{i}.bin';c.write_bytes(v2[i]);entry['candidate']=str(c)
plan.write_text(json.dumps(dict(data_root=str(data),game_root=str(data.parent),files=files)),'utf8')
with (data/files[1]['relative_path']).open('rb') as locked:
 rc,out,err=run('Apply');assert rc!=0,(out,err)
assert state()==patched,(out,err,state());results.append('upgrade_failure_rolls_back_previous_patch')
with (data/files[1]['relative_path']).open('rb') as locked:
 rc,out,err=run('Restore');assert rc!=0,(out,err)
assert state()==patched,(out,err,state());results.append('restore_previous_patch_failure_rolls_back')
rc,out,err=run('Apply');assert rc==0,(out,err);assert state()==v2;results.append('upgrade_from_previous_patch')
rc,out,err=run('Restore');assert rc==0,(out,err);assert state()==original;results.append('restore_original_after_upgrade')
report=dict(passed=results,count=len(results),fixture=str(test),installed_game_modified=False)
(ROOT/'work/official_game_patch/deployer-test-report.json').write_text(json.dumps(report,indent=2),'utf8')
print(json.dumps(report),flush=True)
