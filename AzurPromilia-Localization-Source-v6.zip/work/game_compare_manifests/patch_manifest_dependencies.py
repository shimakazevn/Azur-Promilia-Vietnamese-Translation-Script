"""Append manifest dependency ranges; write no installed files.

BundleReferencePool contains reverse references. AssetDependPool contains the
complete load closure. Caller supplies the new target direct external count.
"""
import struct,hashlib
from parse_manifest import parse

def extend_dependencies(raw,target_bundle,closure_additions,new_direct_bundles,new_direct_count=None):
 m=parse(raw);data=bytearray(raw);assets=m['assets'];bundles=m['bundles']
 if not 0<=target_bundle<len(bundles):raise ValueError('Invalid target bundle')
 additions=list(dict.fromkeys(closure_additions));direct=list(dict.fromkeys(new_direct_bundles))
 if any(not 0<=i<len(bundles) for i in additions+direct):raise ValueError('Invalid dependency bundle')
 if target_bundle in additions+direct:raise ValueError('A bundle cannot depend on itself')
 ap=list(m['asset_depend_pool']);rp=list(m['bundle_reference_pool']);changed_assets=[];changed_reverse=[]
 for i,a in enumerate(assets):
  old=ap[a['depend_start']:a['depend_start']+a['depend_count']]
  if a['bundle']!=target_bundle and target_bundle not in old:continue
  new=sorted(set(old+additions))
  if old==new:continue
  start=len(ap);ap.extend(new)
  pos=m['asset_count_offset']+4+i*24
  struct.pack_into('<ii',data,pos+8,start,len(new));changed_assets.append(dict(asset=i,old=old,new=new))
 for bi in direct:
  b=bundles[bi];old=rp[b['reference_offset']:b['reference_offset']+b['reference_count']]
  if target_bundle in old:continue
  new=sorted(set(old+[target_bundle]));start=len(rp);rp.extend(new)
  pos=m['bundle_count_offset']+4+bi*56
  struct.pack_into('<ii',data,pos+20,start,len(new))
  # This byte counts asset references, distinct from deduplicated bundle refs.
  # Do not guess its increment; it is preserved until independently verified.
  changed_reverse.append(dict(bundle=bi,old=old,new=new))
 if new_direct_count is not None:
  struct.pack_into('<i',data,m['bundle_count_offset']+4+target_bundle*56+16,new_direct_count)
 asset_pool_pos=m['asset_count_offset']+4+len(assets)*24
 reference_pool_pos=m['bundle_count_offset']+4+len(bundles)*56
 hash_pos=reference_pool_pos+4+4*len(m['bundle_reference_pool'])
 encode=lambda seq:struct.pack('<i',len(seq))+struct.pack('<'+'i'*len(seq),*seq)
 patched=bytes(data[:asset_pool_pos])+encode(ap)+bytes(data[m['bundle_count_offset']:reference_pool_pos])+encode(rp)+bytes(data[hash_pos:])
 report=dict(target_bundle=target_bundle,assets=changed_assets,reverse_references=changed_reverse,direct_count=new_direct_count,asset_reference_count_preserved=True)
 return patched,hashlib.md5(patched).hexdigest().encode('ascii'),report
