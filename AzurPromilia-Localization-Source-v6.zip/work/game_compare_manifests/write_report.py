from pathlib import Path
import json,hashlib,collections,re,sys
sys.stdout.reconfigure(encoding='utf-8')
out=Path('work/game_compare_manifests');records=json.loads((out/'lua-inventory.json').read_text('utf-8'))
counts=collections.Counter((r['region'],r['layer']) for r in records)
roots={'cn':Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data'),'tw':Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')}
manifest=[]
for region,root in roots.items():
 for layer,base in [('builtin',root/'StreamingAssets'/'.res'),('update',root/'.res')]:
  for p in base.rglob('*.bytes'):
   if ('ManifestFiles' in p.parts or p.parent==base/p.parent.name) and p.name.startswith(('00_','0release_')):
    b=p.read_bytes();manifest.append(dict(region=region,layer=layer,path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest(),magic=b[:4].hex(),ascii_header=[m.group().decode('ascii') for m in re.finditer(rb'[ -~]{5,}',b[:110])]))
(out/'manifest-identities.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
report='''# 国服 / 台服游戏资源：清单与 Lua 只读对比

2026-11-24。未修改游戏、启动器、用户配置；未运行、附加或注入游戏进程。使用普通本地文件解析；REA CLI 既有依赖故障仍未修复，本报告不是 REA Evidence。

## 范围与确定结果

- 国服：D:\\AzurPromilia\\AzurPromilia_Game\\AzurPromilia_Data。
- 台服：E:\\AzurPromilia_TC\\AzurPromilia_TC_game\\AzurPromilia_Data。
- 内置清单位于 StreamingAssets\\.res；更新清单位于 .res\\各package\\ManifestFiles。
- 清单文件 magic=4F 4F 59 00，头部长度前缀字符串包含2.3.1、RawFileBuildPipeline或ScriptableBuildPipeline、包名、资源版本、构建时间。
- 国服内置资源2868078，更新资源3217420；台服内置3060618，更新3221745。不同构建间哈希文件名不能直接视作同一资产。
- BuildinCatalog.json 只把BundleGUID映射到.r文件名，不提供完整虚拟路径。部分清单资产记录用整数ID表示路径，台服raw_base可见连续ID约31450..31468；尚未完成这些整数到完整路径的映射。

## Lua 编码与语言读取链

raw_nostreaming_package 的 Lua .r 前128字节是不可读前缀。从128开始各字节XOR 0x40后，得到完整标准Lua5.3字节码（1B 4C 75 61 53 00），debug source字段包含完整Lua源路径。本次解码仅写到work副本。

确认Lua字节码数量：国服内置3591、更新74；台服内置3592、更新8。完整映射在lua-inventory.json。

已恢复并重点检查：

- 台服core/lang.lua：原文件 raw_nostreaming_package/ikhoaj7ffj0niwo1rkyqfg.r，4532字节。
- 国服core/lang.lua：原文件 raw_nostreaming_package/eof2amjcfngwxtufg2awqa.r，4547字节。
- ui/configTpl/wordsTpl.lua。
- configParser.lua。
- ui/store/setting/settingStore.lua、settingState.lua。
- settingConst.lua。
- ui/pages/option/pageLanguagePack.lua、cellLanguage.lua。

core/lang.lua 常量确认 `Azur.Gameplay.Core.Table.TableMgr.CheckLangTableLoaded`、`GetLangValue`、`lang_`、`lang_%s`；wordsTpl.lua确认 `G_Tables.TDWordsTable`、`L_Lang`。这将游戏内文字读取定位到原生TableMgr及语言表，Lua不是剧情/物品全量文字表。仅字符串/字节码证据，不声称已完整还原控制流。

settingStore可见getIsExistsLangPack、downLangPack、deleteLangPack及languageText等标识；settingConst包含C_I18NConst.LanguageCht/LanguageChs等。语言包管理存在，但没有证据证明可只改配置安全切到全量简体。

## raw_base 与 raw_streaming 检查

台服raw_base共19份.r，已确认多份AKPK音频与CRID视频。四个非影音候选：

- 4w2z6egapavqvdmaqnetra.r，5,031,421字节，头部像数值块。
- 7gbx1y4a3f3botmglix6mq.r，29,036,604字节。
- mjsd3ojqtcpsyxkepjq6tw.r，135,968,049字节。
- z6iva5l1smgwhho7ox1aw.r，149,402,266字节。

后三个共享01 00 00 00 10 10 00 00开头及高熵块。各只读前128KiB，原始与XOR0x40都未见连续四汉字或十二ASCII字母路径；不能据此认定其格式、解密方式或语言用途。

台服raw_streaming共27,203份.r，各仅读首512字节（约14MB）；主要看到浮点/导航数值块、类似protobuf的tag结构、CRID视频。首512字节内未命中lang/chs/cht/SQLite探针。这是有界搜索，不能排除语言表藏在文件后段、压缩或加密中。

## UnityCN标准解包可选验证

static_package/3kuwgykc0rdjxcshnnjsq.r是加密UnityFS样本。依据本地UnityPy ArchiveStorageManager实现提取header向量，用Node内置crypto执行AES-128-ECB签名验证。

对本地AzurPromiliaBase.dll、UnityPlayer.dll、global-metadata.dat、GameAssembly.dll中ASCII及UTF16LE字母数字/下划线长度16..64串的所有16字符窗口，总计250,090个去重候选进行离线验证，未匹配。没有执行游戏，无密钥输出/保存；这仅否定该候选范围，不能证明密钥不存在。结果见bundle_key_probe.json。

## 结论与下一步

可以恢复主要Lua模块和语言访问链；完整剧情/道具语言表到实际.r的映射仍未知。下一步应先还原原生TableMgr资源路径及全路径ID映射，再识别语言表容器、字段/校验，最后考虑受控替换。不能据此直接把国服资源包整体覆盖台服，也不应把仅113条启动文本修改称作全游戏汉化。

辅助产物：lua-inventory.json、language-candidates.json、manifest-identities.json、raw_streaming_header_inventory.json、bundle_key_probe.json，以及decoded子目录中的语言相关Lua字节码和字符串副本。
'''
(out/'findings.md').write_text(report,encoding='utf-8')
print(json.dumps({'manifest_count':len(manifest),'lua_counts':{f'{a}/{b}':n for (a,b),n in counts.items()},'report':str(out/'findings.md')},ensure_ascii=False))
