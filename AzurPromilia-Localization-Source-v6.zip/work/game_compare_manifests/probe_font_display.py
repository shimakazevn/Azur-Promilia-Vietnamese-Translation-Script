from pathlib import Path
import sys,io,json,hashlib,copy,struct
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_decrypt_bundle'),str(BASE/'analysis_deps')]
from unity_setup import UnityPy
from fontTools.ttLib import TTFont
from opencc import OpenCC
from PIL import Image,ImageDraw,ImageFont,ImageChops
OUT=BASE/'font_display_probe';OUT.mkdir(exist_ok=True)
cc=OpenCC('t2s')
phrase='伺服器尚未開啟，「星躍始動」準備中……'
roots=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
report={'installedFilesModified':False,'phrase':phrase,'singleCharacterResult':''.join(cc.convert(c) for c in phrase),'fonts':[],'sdf':[]}
maps={}
for name,source in [('a00','cn_a00.otf'),('b00','cn_b00.otf'),('c00','official_chs_c00.otf')]:
 font=TTFont(BASE/'game_decrypt_bundle'/source);before=font.getBestCmap();mapping={cp:ord(t) for cp in range(0x3400,0xa000) if len(t:=cc.convert(chr(cp)))==1 and t!=chr(cp) and ord(t) in before}
 oldOrder=font.getGlyphOrder();count=0
 for table in font['cmap'].tables:
  if table.isUnicode() and table.format in (4,12,13):
   for a,b in mapping.items():
    if table.format==4 and a>0xffff:continue
    table.cmap[a]=before[b];count+=1
 dest=OUT/(name+'_traditional_display_as_simplified.otf');font.save(dest)
 check=TTFont(dest);after=check.getBestCmap();assert check.getGlyphOrder()==oldOrder
 assert all(after[a]==before[b] for a,b in mapping.items())
 assert all(after[k]==v for k,v in before.items() if k not in mapping)
 maps[name]=mapping
 report['fonts'].append({'name':name,'path':str(dest.resolve()),'mappedCodepoints':len(mapping),'allGlyphIdsPreserved':True,'unrelatedCmapEntriesPreserved':True,'phraseMappings':{c:chr(mapping[ord(c)]) for c in phrase if ord(c) in mapping}})
# Inspect currently installed bundle sets, and validate every external fallback
# pointer against CAB identity and path ID in loaded installed font packs.
paths=[roots/'StreamingAssets/.res/default_package'/n for n in ['a66pm5ie1rrjguuzlsyq.r','p4hifvtlpthiunufa1lslg.r','db0aboccfhk0ruhzeueydq.r']]+[roots/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r']
envs=[];objects={};cabfiles={}
for p in paths:
 raw=p.read_bytes();off=0
 while off<len(raw):
  size=struct.unpack_from('>Q',raw,off+24)[0];env=UnityPy.load(raw[off:off+size]);envs.append((p,off,env))
  for o in env.objects:
   cab=o.assets_file.name.lower();objects[(cab,o.path_id)]=o
  off+=size
for p,off,env in envs:
 for o in env.objects:
  if o.type.name!='MonoBehaviour':continue
  try:d=o.read_typetree()
  except Exception:continue
  if 'm_CharacterTable' not in d:continue
  charmap={x['m_Unicode']:x for x in d['m_CharacterTable']};new=copy.deepcopy(d);redirect=[];remove=[]
  # Prefer an existing simplified glyph in this exact atlas, else let dynamic
  # fallback resolve the original codepoint through the modified font cmap.
  mapping=maps['a00'];newchars=[]
  for row in new['m_CharacterTable']:
   cp=row['m_Unicode'];target=mapping.get(cp)
   if target is None:newchars.append(row)
   elif target in charmap:
    row['m_GlyphIndex']=charmap[target]['m_GlyphIndex'];newchars.append(row);redirect.append(cp)
   else:remove.append(cp)
  new['m_CharacterTable']=newchars
  refs=[]
  for ptr in d['m_FallbackFontAssetTable']:
   cab=o.assets_file.name if ptr['m_FileID']==0 else o.assets_file.externals[ptr['m_FileID']-1].path.split('/')[-1]
   target=objects.get((cab.lower(),ptr['m_PathID']))
   refs.append({'pointer':ptr,'resolved':target is not None,'name':target.read_typetree().get('m_Name') if target else None})
  changes={chr(cp):('redirect' if cp in redirect else 'fallback' if cp in remove else 'absent') for cp in {ord(c) for c in phrase} if cp in mapping}
  if redirect or remove:
   before=o.get_raw_data();o.save_typetree(new);reread=o.read_typetree();assert [(r['m_Unicode'],r['m_GlyphIndex']) for r in reread['m_CharacterTable']]==[(r['m_Unicode'],r['m_GlyphIndex']) for r in newchars];o.set_raw_data(before)
   (OUT/(d['m_Name']+'_character_table.json')).write_text(json.dumps(newchars,ensure_ascii=False),encoding='utf8')
  report['sdf'].append({'name':d['m_Name'],'mode':d['m_AtlasPopulationMode'],'file':p.name,'offset':off,'pathId':o.path_id,'staticCharacters':len(charmap),'redirectCount':len(redirect),'removedCount':len(remove),'phrase':changes,'fallback':refs,'typetreeRoundtrip':True})
font=ImageFont.truetype(str(OUT/'a00_traditional_display_as_simplified.otf'),36)
def draw(text):
 im=Image.new('L',(1000,80),255);ImageDraw.Draw(im).text((8,8),text,font=font,fill=0);return im
im1=draw(phrase);im2=draw(report['singleCharacterResult']);assert ImageChops.difference(im1,im2).getbbox() is None
canvas=Image.new('RGB',(1000,160),'white');canvas.paste(im1,(0,0));canvas.paste(im2,(0,80));canvas.save(OUT/'phrase_render_equivalence.png')
report['pixelEqualityTraditionalInputVsSimplifiedInput']=True
(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
