from pathlib import Path
import sys,json,re,hashlib,collections,struct
sys.stdout.reconfigure(encoding='utf-8')
OUT=Path('work/game_compare_manifests');OUT.mkdir(exist_ok=True)
ROOTS={'cn':Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data'),'tw':Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')}
records=[];selected=[]
tr=bytes(i^0x40 for i in range(256))
for region,root in ROOTS.items():
 for layer,base in [('builtin',root/'StreamingAssets'/'.res'),('update',root/'.res')]:
  package=base/'raw_nostreaming_package'
  for p in package.rglob('*.r'):
   b=p.read_bytes(); decoded=b[128:].translate(tr)
   if decoded[:4]!=b'\x1bLua':continue
   name=re.search(rb'@[^\x00]{0,500}?Lua[/\\]src[/\\]([^\x00]{0,300}?\.lua)',decoded)
   source=name.group(1).decode('utf-8',errors='replace').replace('\\','/') if name else None
   rec=dict(region=region,layer=layer,file=str(p),size=len(b),source=source,decoded_sha256=hashlib.sha256(decoded).hexdigest())
   records.append(rec)
   if source and re.search(r'i18n|lang|localiz|config.*manager|setting.*language',source,re.I):
    target=OUT/'decoded'/region/layer/source;target.parent.mkdir(parents=True,exist_ok=True);target.with_suffix('.luac').write_bytes(decoded)
    selected.append(rec)
(OUT/'lua-inventory.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'language-candidates.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2),encoding='utf-8')
print('Counts',collections.Counter((r['region'],r['layer']) for r in records))
print(json.dumps(selected,ensure_ascii=False,indent=2))
