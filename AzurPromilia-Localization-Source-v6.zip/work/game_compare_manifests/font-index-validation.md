# Font resource index validation

Read-only checks, 2026-11-24.

`StreamingAssets/.res/default_package/BuildinCatalog.bytes` is 451073 bytes:

- uint32 magic `0x0133c5ee`.
- Three ushort-prefixed UTF-8 strings: `1.0.0`, `default_package`, `3060618`.
- int32 wrapper count, 9265.
- 9265 pairs of ushort-prefixed strings: `BundleGUID`, `FileName`.

Parsing ends exactly at EOF and every pair matches the companion JSON. There
are no size, CRC or offset fields. This agrees with native
`DefaultBuildinFileCatalog.FileWrapper` (TypeDefIndex 44169), whose only fields
are `BundleGUID` and `FileName`. Retaining the original resource names means
neither catalog format needs editing.

The font plan references a00/c00/sdf_a00_b from both builtin and current update
manifests, and b00 only from the update manifest. Both manifests must describe
the final bytes: changed bundle sizes and CRCs, offsets of following bundles
inside a shared pack, and full PackRes size/CRC. Each changed manifest's `.hash`
is standard MD5 of its final bytes. All other fields, including name/hash keys,
can remain unchanged for local lookup.

Native `DefaultBuildinFileSystem.LoadEncryptedAssetBundle` (RVA D3D96A0)
obtains the pack path from the manifest PackRes and passes `bundle.FileOffset`
from compact offset 0x24 to the decryption service. This confirms that shared
pack offsets must be rebuilt in each referencing manifest. There is no second
catalog offset source in this path.

The four installed font packs have no sidecar files. The update package has
only the current manifest, its `.hash`, and `ApplicationFootPrint.bytes` in
ManifestFiles; UnpackManifestFiles contains only the footprint. The footprint
is Unity `Application.buildGUID`, not a resource checksum, and should remain
unchanged.

Conclusion: for the inspected local resource loader, rebuilding the four font
packs plus both corresponding default-package manifests and their `.hash`
files is sufficient. No BuildinCatalog edit is required. This conclusion does
not assert that a later launcher repair or online resource update will retain
modified local resources; runtime startup has not been performed here.
