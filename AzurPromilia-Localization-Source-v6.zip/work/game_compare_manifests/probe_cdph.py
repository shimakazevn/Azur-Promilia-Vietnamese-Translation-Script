from pathlib import Path
import struct,json
DIR=Path('work/game_decrypt_bundle/display_code')
d=(DIR/'Assembly-CSharp.dll.bytes').read_bytes();o=d.find(b'BSJB');n=struct.unpack_from('<I',d,o+12)[0];p=(o+16+n+3)&~3;fl,c=struct.unpack_from('<HH',d,p);p+=4
print('metadataRoot',o,'versionlen',n,'flags',fl,'streams',c)
streams={}
for i in range(c):
 a,b=struct.unpack_from('<II',d,p);p+=8;e=d.index(0,p);name=d[p:e].decode();p=(e+4)&~3;streams[name]=(o+a,b);print(name,a,b,'absolute',o+a,'prefix',d[o+a:o+a+20].hex())
p=0x110;blocks=[]
for i in range(8):
 n=struct.unpack_from('<I',d,p)[0];p+=4;assert p+n<=len(d);blocks.append({'index':i,'offset':p,'size':n});p=(p+n+3)&~3
print('CDPH blocks',blocks,'postBlocks',p,'postHeaderIntegers',struct.unpack_from('<8I',d,p+16))
mv=(DIR/'Assembly-CSharp.mv.bytes').read_bytes();magic,version,metaversion,count=struct.unpack_from('<4sIII',mv);q=16+count*8;count2=struct.unpack_from('<I',mv,q)[0];q+=4;print('CPMV',version,metaversion,'recordGroup1',count,'recordGroup2',count2,'group2offset',q,'length',len(mv))
