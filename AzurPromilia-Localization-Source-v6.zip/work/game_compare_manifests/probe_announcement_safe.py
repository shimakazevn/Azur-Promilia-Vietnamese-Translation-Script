from pathlib import Path
import re,json
p=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\PersistentDataPath\Log\MJLog_2026_1124_2300_10.log')
ls=p.read_text(encoding='utf8',errors='replace').splitlines()
i=next(i for i,l in enumerate(ls) if '伺服器尚未' in l)
line=ls[i]
print('line',i+1,'length',len(line))
print('keys',re.findall(r'"([A-Za-z_][A-Za-z_0-9]*)"\s*:',line))
print('prefix',re.sub(r'https?://\S+','[URL]',line[:min(line.find('{'),120)]))
obj=json.JSONDecoder().raw_decode(line[line.find('{'):])[0]
def walk(v,path='root'):
 if isinstance(v,dict):
  for k,x in v.items():walk(x,path+'.'+k)
 elif isinstance(v,list):
  for j,x in enumerate(v):walk(x,path+f'[{j}]')
 elif isinstance(v,str) and '伺服器尚未' in v:
  print('phrase_path',path)
  print('phrase',v)
walk(obj)
print('symbols',json.dumps([s for s in ls[max(0,i-20):i+25] if re.match(r'^[A-Za-z_.<>`]+[:.]',s) and not re.search(r'token|account|url|ticket|udid|device',s,re.I)],ensure_ascii=False))
