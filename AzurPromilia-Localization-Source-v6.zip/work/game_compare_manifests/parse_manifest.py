from pathlib import Path
import struct,json,collections
OUT=Path(__file__).parent
ROOTS={'cn':Path(r'D:\AzurPromilia\AzurPromilia_Game\AzurPromilia_Data'),'tw':Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')}
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def get(self,fmt):
  v=struct.unpack_from('<'+fmt,self.b,self.p);self.p+=struct.calcsize('<'+fmt);return v[0] if len(v)==1 else v
 def string(self):
  n=self.get('H');v=self.b[self.p:self.p+n].decode();self.p+=n;return v
 def array(self,fmt):return [self.get(fmt) for _ in range(self.get('i'))]
def parse(path):
 raw=path if isinstance(path,(bytes,bytearray)) else path.read_bytes()
 r=Reader(raw);assert r.get('I')==0x594f4f
 out=dict(file='<memory>' if isinstance(path,(bytes,bytearray)) else str(path),format=r.string(),flags=r.get('3B'),name_style=r.get('i'),bundle_type=r.get('i'))
 out.update(zip(['pipeline','package','version','note'],[r.string() for _ in range(4)]))
 out['asset_count_offset']=r.p
 out['assets']=[dict(zip(['bundle','path_key','depend_start','depend_count','tags','index'],v)) for v in r.array('6i')]
 out['asset_depend_pool']=r.array('i')
 out['bundle_count_offset']=r.p
 out['bundles']=[dict(zip(['size','crc','name_index','depend_count','reference_offset','reference_count','asset_count','pack_id','offset','tags','index','encrypted','ref_count','reserved1','reserved2'],v)) for v in r.array('qIiiiiiiqIi4B')]
 out['bundle_reference_pool']=r.array('i')
 hash_count=r.get('i');out['hashes']=[r.get('QQ') for _ in range(hash_count)]
 out['pack_count_offset']=r.p
 out['packs']=[dict(zip(['name0','name1','hash0','hash1','size','uid','crc'],v)) for v in r.array('QQQQqII')]
 assert r.p==len(r.b),(path,r.p,len(r.b))
 return out
if __name__=='__main__':
 results=[]
 for region,root in ROOTS.items():
  for layer,base in [('builtin',root/'StreamingAssets'/'.res'),('update',root/'.res')]:
   for p in base.rglob('*.bytes'):
    if p.name=='BuildinCatalog.bytes' or not p.name.startswith(('0release_','00_')):continue
    try:v=parse(p)
    except Exception as e:print('ERROR',p,e);continue
    v.update(region=region,layer=layer)
    # Size is only a candidate mapping, never proof where duplicates exist.
    sizes=collections.defaultdict(list)
    for f in p.parent.rglob('*.r'):sizes[f.stat().st_size].append(str(f))
    if layer=='update':
     for f in p.parent.parent.rglob('*.r'):sizes[f.stat().st_size].append(str(f))
    for a in v['assets']:
     b=v['bundles'][a['bundle']];a['size']=b['size'];a['size_matched_files']=list(set(sizes[b['size']]))
    results.append(v)
 (OUT/'parsed-manifests.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 for v in results:
  print(v['region'],v['layer'],v['package'],len(v['assets']),len(v['bundles']))
  if v['package']=='raw_base_package':
   for a in v['assets']:print(a)
