"""Unity Hash128.Compute short-input SpookyHash V2, first ulong.

Only short inputs supported until independently validated long-input code exists.
"""
MASK=(1<<64)-1
CONST=0xdeadbeefdeadbeef
def rot(x,n):return ((x<<n)|(x>>(64-n)))&MASK
def short_mix(v):
 a,b,c,d=v
 c=rot(c,50);c=(c+d)&MASK;a^=c
 d=rot(d,52);d=(d+a)&MASK;b^=d
 a=rot(a,30);a=(a+b)&MASK;c^=a
 b=rot(b,41);b=(b+c)&MASK;d^=b
 c=rot(c,54);c=(c+d)&MASK;a^=c
 d=rot(d,48);d=(d+a)&MASK;b^=d
 a=rot(a,38);a=(a+b)&MASK;c^=a
 b=rot(b,37);b=(b+c)&MASK;d^=b
 c=rot(c,62);c=(c+d)&MASK;a^=c
 d=rot(d,34);d=(d+a)&MASK;b^=d
 a=rot(a,5);a=(a+b)&MASK;c^=a
 b=rot(b,36);b=(b+c)&MASK;d^=b
 return a,b,c,d
def short_end(v):
 a,b,c,d=v
 for n,i in [(15,0),(52,1),(26,2),(51,3),(28,0),(9,1),(47,2),(54,3),(32,0),(25,1),(63,2)]:
  if i==0:d^=c;c=rot(c,n);d=(d+c)&MASK
  elif i==1:a^=d;d=rot(d,n);a=(a+d)&MASK
  elif i==2:b^=a;a=rot(a,n);b=(b+a)&MASK
  else:c^=b;b=rot(b,n);c=(c+b)&MASK
 return a,b,c,d
def spooky_short(data):
 n=len(data)
 if n>=192:raise ValueError('Only SpookyHash short inputs (<192 bytes) are validated')
 a=b=0;c=d=CONST;p=0
 while n-p>=32:
  c=(c+int.from_bytes(data[p:p+8],'little'))&MASK;d=(d+int.from_bytes(data[p+8:p+16],'little'))&MASK
  a,b,c,d=short_mix((a,b,c,d))
  a=(a+int.from_bytes(data[p+16:p+24],'little'))&MASK;b=(b+int.from_bytes(data[p+24:p+32],'little'))&MASK;p+=32
 if n-p>=16:
  c=(c+int.from_bytes(data[p:p+8],'little'))&MASK;d=(d+int.from_bytes(data[p+8:p+16],'little'))&MASK
  a,b,c,d=short_mix((a,b,c,d));p+=16
 d=(d+(n<<56))&MASK
 tail=data[p:]
 if not tail:c=(c+CONST)&MASK;d=(d+CONST)&MASK
 else:
  c=(c+int.from_bytes(tail[:8],'little'))&MASK
  d=(d+int.from_bytes(tail[8:],'little'))&MASK
 return short_end((a,b,c,d))[:2]
def text_hash(text):return spooky_short(text.encode('utf-8'))[0]
