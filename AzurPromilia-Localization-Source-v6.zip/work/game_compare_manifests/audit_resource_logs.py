from pathlib import Path
import re,json
root=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\PersistentDataPath\Log')
p=max(root.glob('*.log'),key=lambda p:p.stat().st_mtime)
print('Log',p.name,p.stat().st_size)
text=p.read_bytes().decode('utf-8',errors='replace')
words=re.compile(r'manifest|3221745|3060618|v0k2caf|3iffxe|table_data|vstring|crc|verif|integrity|redownload|hash mismatch|checksum|repair|lang_cht|LanguageCht',re.I)
lines=[]
for line in text.splitlines():
 if not words.search(line):continue
 if re.search(r'(?i)token|account|ticket|authorization|sdk.login',line):continue
 line=re.sub(r'https?://[^\s"<>]+','[URL]',line)
 lines.append(line[:1200])
out=Path(__file__).parent/'postlaunch-sanitized-resource-log.txt'
out.write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines[-100:]))
