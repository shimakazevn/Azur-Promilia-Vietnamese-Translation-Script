import sys,struct
sys.path.insert(0,'work/game_mmap');import native
targets=[0xfa48978,0xffd8ba4]
for start,size,raw in native.sections[:2]:
 data=native.binary[raw:raw+size]
 for pattern in [b'\x48\x8d',b'\x4c\x8d']:
  pos=0
  while (pos:=data.find(pattern,pos))>=0:
   if pos+7<len(data) and data[pos+2]&0xc7==5:
    target=start+pos+7+struct.unpack_from('<i',data,pos+3)[0]
    if any(abs(target-t)<16 for t in targets):print(hex(start+pos),hex(target))
   pos+=1
