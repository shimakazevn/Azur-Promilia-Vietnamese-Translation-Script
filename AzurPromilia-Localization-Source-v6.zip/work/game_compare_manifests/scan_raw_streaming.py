from pathlib import Path
import collections,json,re,sys
sys.stdout.reconfigure(encoding='utf-8')
root=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\raw_streaming_package')
counts=collections.Counter();examples={};selected=[]
for p in root.glob('*.r'):
 size=p.stat().st_size
 with p.open('rb') as f:b=f.read(512)
 k=b[:8].hex();counts[k]+=1
 if len(examples.setdefault(k,[]))<3:examples[k].append(dict(file=p.name,size=size,head=repr(b[:64])))
 if size<5000000 and (any(x in b for x in [b'lang',b'chs',b'cht',b'SQLite']) or 20000000<=size<=40000000):selected.append(dict(file=p.name,size=size,head=repr(b[:64])))
report=dict(counts=counts.most_common(30),examples=examples,selected=selected)
Path('work/game_compare_manifests/raw_streaming_header_inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('files',sum(counts.values()),'unique heads',len(counts));print(json.dumps(dict(counts=counts.most_common(10),examples={k:examples[k] for k,c in counts.most_common(10)},selected=selected[:30]),ensure_ascii=False,indent=2))
