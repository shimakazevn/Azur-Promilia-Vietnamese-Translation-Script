from pathlib import Path
import json,re
from parse_manifest import parse,ROOTS
from vstring_pool import VStringPool
OUT=Path(__file__).parent
POOLS={('cn','builtin'):'cn_builtin_xjlaljvfh6vdjilpk62knq.bin',('cn','update'):'cn_update_bjzqzapbodx6zodmvtrta.bin',('tw','builtin'):'tw_builtin_mjsd3ojqtcpsyxkepjq6tw.bin',('tw','update'):'tw_update_v0k2cafcxjxawklow6skg.bin'}
result=[]
for (region,layer),name in POOLS.items():
 pool=VStringPool(Path('work/game_mmap/decoded')/name)
 base=ROOTS[region]/('StreamingAssets/.res' if layer=='builtin' else '.res')
 paths=[]
 for key in range(len(pool)):
  s=pool[key]
  if s and s.startswith('Assets/') and re.search(r'lang_|NewTableMMap|/VString/|LangString',s,re.I):paths.append((key,s))
 known=dict(paths)
 for p in base.rglob('*.bytes'):
  if p.name=='BuildinCatalog.bytes' or not p.name.startswith(('0release_','00_')):continue
  m=parse(p)
  hits=[]
  for a in m['assets']:
   if a['path_key'] in known:
    b=m['bundles'][a['bundle']];hits.append(dict(path=known[a['path_key']],key=a['path_key'],bundle=a['bundle'],size=b['size'],crc=b['crc']))
  if hits:result.append(dict(region=region,layer=layer,package=m['package'],manifest=str(p),assets=hits))
 (OUT/f'{region}_{layer}_language_path_keys.json').write_text(json.dumps(paths,ensure_ascii=False,indent=2),encoding='utf-8')
 print(region,layer,'path count',len(paths))
(OUT/'language_path_manifests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
