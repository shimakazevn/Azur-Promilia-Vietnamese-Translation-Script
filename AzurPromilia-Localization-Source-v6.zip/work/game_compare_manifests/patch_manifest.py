"""Rebuild local resource metadata, retaining names and all unrelated fields.

This API writes no installed files. Whole pack replacement supports standalone
packs and equal size shared packs. Explicit segment replacement also rebuilds
shared packs with changed segment sizes, preserving gaps and trailing bytes.
"""
from pathlib import Path
import hashlib,struct,zlib
from parse_manifest import parse
ALPHABET=' 0123456789abcdefghijklmnopqrstuvwxyz.'
def _encode_u64(n):
 result=''
 while n:
  n,d=divmod(n,38);result=ALPHABET[d]+result
 return result
def encode_name(a,b):return _encode_u64(a)+_encode_u64(b)
def patch_manifest(manifest_bytes,original_filename,new_bytes,original_bytes=None):
 """Return (patched_manifest_bytes, md5_ascii_bytes, report).

 original_filename is a basename, or an actual file path. If original_bytes is
 supplied (or the supplied path exists), validate its size and CRC first.
 """
 m=parse(manifest_bytes)
 filename=Path(original_filename).name
 candidates=[(i,p) for i,p in enumerate(m['packs']) if encode_name(p['name0'],p['name1']) in (filename,Path(filename).stem)]
 if len(candidates)!=1:raise ValueError(f'Expected one pack matching {filename}; found {len(candidates)}')
 pack_index,pack=candidates[0]
 bundles=[(i,b) for i,b in enumerate(m['bundles']) if b['pack_id']==pack_index]
 shared=len(bundles)!=1 or bundles[0][1]['offset']!=0
 if shared and len(new_bytes)!=pack['size']:raise ValueError('Size-changing shared pack requires explicit new bundle boundaries')
 if original_bytes is None and Path(original_filename).is_file():original_bytes=Path(original_filename).read_bytes()
 if original_bytes is not None:
  size=len(original_bytes);crc=zlib.crc32(original_bytes)
  if (size,crc)!=(pack['size'],pack['crc']):raise ValueError('Original pack size/CRC does not agree with the manifest')
  for _,bundle in bundles:
   segment=original_bytes[bundle['offset']:bundle['offset']+bundle['size']]
   if (len(segment),zlib.crc32(segment))!=(bundle['size'],bundle['crc']):raise ValueError('Original bundle size/CRC does not agree with the manifest')
 out=bytearray(manifest_bytes);size=len(new_bytes);crc=zlib.crc32(new_bytes)
 pack_pos=m['pack_count_offset']+4+pack_index*48
 updated_bundles=[]
 for bundle_index,bundle in bundles:
  bundle_pos=m['bundle_count_offset']+4+bundle_index*56
  segment=new_bytes[bundle['offset']:bundle['offset']+bundle['size']] if shared else new_bytes
  segment_crc=zlib.crc32(segment)
  struct.pack_into('<qI',out,bundle_pos,len(segment),segment_crc)
  updated_bundles.append(dict(index=bundle_index,manifest_offset=bundle_pos,size=len(segment),crc=segment_crc))
 struct.pack_into('<q',out,pack_pos+32,size)
 struct.pack_into('<I',out,pack_pos+44,crc)
 patched=bytes(out)
 report=dict(filename=filename,bundles=updated_bundles,pack_index=pack_index,pack_offset=pack_pos,old_size=pack['size'],new_size=size,old_crc=pack['crc'],new_crc=crc,original_validated=original_bytes is not None)
 return patched,hashlib.md5(patched).hexdigest().encode('ascii'),report

def replace_pack_segments(manifest_bytes,original_filename,replacements,original_bytes=None):
 """Replace selected bundle segments and preserve all other bytes, including gaps.

 replacements maps manifest bundle index to replacement bytes. Returns
 (new_pack, new_manifest, new_manifest_hash, report), writing no files.
 """
 if original_bytes is None:original_bytes=Path(original_filename).read_bytes()
 # First verify every original segment and the complete pack.
 _,_,check=patch_manifest(manifest_bytes,original_filename,original_bytes,original_bytes)
 m=parse(manifest_bytes);pack_index=check['pack_index']
 bundles=sorted(((i,b) for i,b in enumerate(m['bundles']) if b['pack_id']==pack_index),key=lambda x:x[1]['offset'])
 if not set(replacements).issubset(i for i,_ in bundles):raise ValueError('Replacement targets a bundle outside the selected pack')
 new_pack=bytearray();manifest=bytearray(manifest_bytes);old_cursor=0;changes=[]
 for i,b in bundles:
  start=b['offset'];end=start+b['size']
  if start<old_cursor:raise ValueError('Overlapping bundle segments are unsupported')
  new_pack.extend(original_bytes[old_cursor:start]);offset=len(new_pack)
  segment=replacements.get(i,original_bytes[start:end]);new_pack.extend(segment)
  pos=m['bundle_count_offset']+4+i*56
  struct.pack_into('<qI',manifest,pos,len(segment),zlib.crc32(segment))
  struct.pack_into('<q',manifest,pos+36,offset)
  if i in replacements:changes.append(dict(bundle_index=i,old_size=b['size'],new_size=len(segment),old_offset=start,new_offset=offset))
  old_cursor=end
 new_pack.extend(original_bytes[old_cursor:]);new_pack=bytes(new_pack)
 pos=m['pack_count_offset']+4+pack_index*48
 struct.pack_into('<q',manifest,pos+32,len(new_pack));struct.pack_into('<I',manifest,pos+44,zlib.crc32(new_pack))
 manifest=bytes(manifest)
 return new_pack,manifest,hashlib.md5(manifest).hexdigest().encode('ascii'),dict(pack_index=pack_index,changes=changes,old_size=len(original_bytes),new_size=len(new_pack))
