from pathlib import Path
import re,json
roots=[Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\PersistentDataPath\Log'),Path(r'C:\Users\xiaoxi\AppData\LocalLow\manjuu\AzurPromilia')]
out=[]
for root in roots:
 for p in root.glob('*.log'):
  lines=p.read_text(encoding='utf8',errors='replace').splitlines()
  for i,line in enumerate(lines):
   m=re.search(r'(伺服器尚未[^"\r\n]{0,300}|星躍始動[^"\r\n]{0,200})',line)
   if m:
    # Only a narrowly selected phrase and nearby code-stack symbols are kept.
    symbols=[x for x in lines[max(0,i-4):i+5] if re.match(r'^[A-Za-z_.<>`]+[:.]',x) and not re.search(r'token|account|url|ticket',x,re.I)]
    out.append(dict(file=p.name,line=i+1,phrase=m.group(1),symbols=symbols))
Path(__file__).with_name('announcement-evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(out[-12:],ensure_ascii=False,indent=2))
