# 用户六张截图的补漏核对

2026-11-24，第二版已安装；以下为离线证据，不表示已经观察到游戏运行效果。

| 截图文字 | 来源证据 | 第二版处理 | 游戏内验证 |
| --- | --- | --- | --- |
| 關閉 / 開啟 | cht独立StaticText表key B15D9127 / CC42DD31 | 按国服同key替换独立表；包含在2390条变化中 | 待重启 |
| 恢復默認設定 | 同表key 7C254EBF | 按国服同key替换 | 待重启 |
| 健康/癫痫警告全文 | static包tex_welcome_word_xq，Texture ID -2427943613944446068，Sprite ID 3251021402728481676 | 国服同ID纹理和网格成对替换，保留台服对象ID | 待重启 |
| 登入成功 / 切換帳號 | 登录prefab未包含完整原文；主词池有独立“登入”“成功”和“切換帳號”，实际使用链尚未确认 | 主表及字体可能覆盖部分显示；本次没有足够证据声称已覆盖。“登入”是词汇差异，字形转换不改词 | 未确认覆盖 |
| 正在檢查更新… | VersionUpdateUI加载updatableBuiltInLangString.csv，覆盖resources.assets启动表 | cht列使用同CSV官方chs，101行变化 | 待重启 |
| 伺服器尚未開啟，「星躍始動」準備中…… | 服务端公告响应title，非本地语言表 | 字体显示层映射传统码位到简体字形，预期“伺服器尚未开启，「星跃始动」准备中……”；不改服务端内容及用词 | 待重启 |

关联证据：

- `../game_decrypt_bundle/statictext_v2_candidate.json`
- `../game_decrypt_bundle/ui-v2-changes.json`
- `../game_decrypt_bundle/login-status-followup-evidence.txt`
- `../game_decrypt_paths/login-text-sources.md`
- `../font_display_probe/segment-validation.json`
- `../font_display_probe/render-validation.json`
- `integration-report.json`
- `installed-verification.json`
- `ui-font-coverage.json`

保留原始备份，现有BAT支持应用、检查和还原第二版。
