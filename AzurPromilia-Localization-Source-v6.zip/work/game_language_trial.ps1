$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
function Hash([byte[]]$bytes) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
function Answer([string]$prompt) { Write-Host $prompt -NoNewline; return [Console]::ReadLine() }
try {
    $mapping = '__MAPPING__' | ConvertFrom-Json
    $offset = 818010
    Write-Host '台服 language=chs 试验（不代表已完成全量汉化）'
    Write-Host '1. 切换 language 为 chs'
    Write-Host '2. 还原本次试验前的文件'
    Write-Host 'Q. 退出'
    $action = Answer '请选择：'
    if ($action -eq 'q') { exit 0 }
    if ($action -notin @('1', '2')) { throw '选项无效。' }
    $game = $env:AZUR_PATCH_HINT
    if (-not $game) { $game = 'E:\AzurPromilia_TC\AzurPromilia_TC_game' }
    if (Test-Path -LiteralPath (Join-Path $game 'AzurPromilia_TC_game')) { $game = Join-Path $game 'AzurPromilia_TC_game' }
    $target = Join-Path $game 'AzurPromilia_Data\resources.assets'
    if (-not (Test-Path -LiteralPath $target)) { throw '找不到台服 resources.assets，可将游戏目录作为参数传入。' }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'AzurPromilia.exe'" | Where-Object { -not $_.ExecutablePath -or $_.ExecutablePath -eq (Join-Path $game 'AzurPromilia.exe') })
    if ($running.Count) { throw '请先退出台服游戏。' }
    $bytes = [IO.File]::ReadAllBytes($target)
    $current = Hash $bytes
    $row = @($mapping | Where-Object { $_.before -eq $current -or $_.after -eq $current })
    if ($row.Count -ne 1) { throw '文件版本或内容已变化，已停止。' }
    $row = $row[0]
    $backup = $target + '.before-language-chs-' + $row.before.Substring(0,12) + '.bak'
    if ($action -eq '1' -and $current -eq $row.after) { Write-Host '当前已经是 language=chs。'; exit 0 }
    if ($action -eq '2' -and $current -eq $row.before) { Write-Host '当前已经是试验前状态。'; exit 0 }
    if ($action -eq '1') {
        if ([IO.File]::Exists($backup)) {
            if ((Hash ([IO.File]::ReadAllBytes($backup))) -ne $row.before) { throw '备份校验失败。' }
        } else { [IO.File]::Copy($target, $backup, $false) }
        if ((Hash ([IO.File]::ReadAllBytes($backup))) -ne $row.before) { throw '备份校验失败。' }
        if ([Text.Encoding]::ASCII.GetString($bytes, $offset, 3) -ne 'cht') { throw '语言字段校验失败。' }
        $result = $bytes.Clone()
        [Array]::Copy([Text.Encoding]::ASCII.GetBytes('chs'), 0, $result, $offset, 3)
        $expected = $row.after
    } else {
        if (-not [IO.File]::Exists($backup)) { throw '缺少本次试验前备份。' }
        $result = [IO.File]::ReadAllBytes($backup)
        $expected = $row.before
    }
    if ((Hash $result) -ne $expected) { throw '结果校验失败。' }
    if ((Hash ([IO.File]::ReadAllBytes($target))) -ne $current) { throw '写入前文件发生变化。' }
    $staging = $target + '.chs-trial-writing.tmp'
    if ([IO.File]::Exists($staging)) { throw '存在待处理临时文件，已停止。' }
    try {
        [IO.File]::WriteAllBytes($staging, $result)
        if ((Hash ([IO.File]::ReadAllBytes($staging))) -ne $expected) { throw '临时文件校验失败。' }
        [IO.File]::Replace($staging, $target, [NullString]::Value)
    } finally { if ([IO.File]::Exists($staging)) { [IO.File]::Delete($staging) } }
    if ((Hash ([IO.File]::ReadAllBytes($target))) -ne $expected) { throw '写入后校验失败。' }
    if ($action -eq '1') { Write-Host '已切换 language=chs；请启动台服验证。' }
    else { Write-Host '已还原本次语言试验。' }
    Write-Host ('目标：' + $target)
    Write-Host ('备份：' + $backup)
    $null = Answer '按回车退出。'
    exit 0
} catch {
    Write-Host ('操作停止：' + $_.Exception.Message) -ForegroundColor Red
    $null = Answer '按回车退出。'
    exit 1
}
