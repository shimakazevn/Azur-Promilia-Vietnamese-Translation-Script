import struct,hashlib,json,subprocess
from pathlib import Path
HERE=Path(__file__).parent
m=Path('work/game_decrypt_paths/tw-global-metadata-decrypted.dat').read_bytes()
head=struct.unpack_from('<64I',m)
strings=m[head[6]:head[6]+head[7]]
default_records={struct.unpack_from('<iii',m,o)[0]:struct.unpack_from('<iii',m,o) for o in range(head[16],head[16]+head[17],12)}
targets={'key':('C8B871500DA1BA1E0DA55C41F88A216145F0EFB067327C72222A04D84E3BC50B',32),'iv':('4B836389DDF3EC29A55A7F5CA38042DE7D26AB6F3B26645EB85B4D2D8BB0533A',16)}
secrets={}
for kind,(name,length) in targets.items():
    needle=name.encode()+b'\0';index=strings.index(needle)
    hits=[]
    for field_index,o in enumerate(range(head[24],head[24]+head[25],12)):
        if struct.unpack_from('<i',m,o)[0]==index:hits.append(field_index)
    assert len(hits)==1,hits
    record=default_records[hits[0]]
    value=m[head[18]+record[2]:head[18]+record[2]+length]
    assert hashlib.sha256(value).hexdigest().upper()==name,kind
    (HERE/('local_mmap_'+kind+'.bin')).write_bytes(value)
    secrets[kind]=value.hex()
source=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\StreamingAssets\.res\raw_base_package\7gbx1y4a3f3botmglix6mq.r')
with source.open('rb') as f: header=f.read(4120)
assert struct.unpack_from('<II',header)==(1,4112)
js="const fs=require('fs'),x=JSON.parse(fs.readFileSync(0,'utf8')),d=require('crypto').createDecipheriv('aes-256-cbc',Buffer.from(x.key,'hex'),Buffer.from(x.iv,'hex'));process.stdout.write(Buffer.concat([d.update(Buffer.from(x.data,'hex')),d.final()]));"
secrets['data']=header[8:].hex()
keyblock=subprocess.check_output(['node','-e',js],input=json.dumps(secrets).encode())
assert len(keyblock)==4096,len(keyblock)
(HERE/'local_mmap_xor_keys.bin').write_bytes(keyblock)
with source.open('rb') as f:f.seek(4120);data=f.read(65536)
decrypted=bytes(value^keyblock[i%4096] for i,value in enumerate(data))
(HERE/'mmap_first64k.bin').write_bytes(decrypted)
print(json.dumps(dict(aes_constants_validated=True,xor_key_bytes=len(keyblock),plaintext_head=decrypted[:128].hex(),ascii_preview=repr(decrypted[:300])),indent=2))
