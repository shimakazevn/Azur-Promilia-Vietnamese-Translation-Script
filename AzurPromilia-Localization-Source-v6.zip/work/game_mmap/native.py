import struct,sys
from pathlib import Path
sys.path.insert(0,str(Path('work/game_decrypt_paths/pylibs').resolve()))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
binary=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\GameAssembly.dll').read_bytes()
pe=struct.unpack_from('<I',binary,60)[0]
section_count=struct.unpack_from('<H',binary,pe+6)[0]
optional_size=struct.unpack_from('<H',binary,pe+20)[0]
base=struct.unpack_from('<Q',binary,pe+48)[0]
sections=[]
for i in range(section_count):
    o=pe+24+optional_size+i*40
    virtual_size,rva,raw_size,raw=struct.unpack_from('<IIII',binary,o+8)
    sections.append((rva,raw_size,raw))
def file_offset(va):
    rva=va-base if va>=base else va
    for start,size,raw in sections:
        if start<=rva<start+size:return raw+rva-start
    raise ValueError(hex(va))
def read(va,n):
    o=file_offset(va);return binary[o:o+n]
def disasm(rva,n):
    va=rva if rva>=base else rva+base
    return list(Cs(CS_ARCH_X86,CS_MODE_64).disasm(read(va,n),va))
if __name__=='__main__':
    for line in disasm(int(sys.argv[1],0),int(sys.argv[2],0)):
        print(f'{line.address:x} {line.mnemonic} {line.op_str}')
