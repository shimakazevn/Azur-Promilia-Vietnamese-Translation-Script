"""Build the standalone pack. To add a new region/game later, append an entry to GAMES or LAUNCHERS."""
# build: QUktR0VORVJBVEVEfOWwlOWuiXwyMDI2LTExLTI1 ⁠​‌​​​​​‌​‌​​‌​​‌​​‌​‌‌​‌​‌​​​‌‌‌​‌​​​‌​‌​‌​​‌‌‌​​‌​​​‌​‌​‌​‌​​‌​​‌​​​​​‌​‌​‌​‌​​​‌​​​‌​‌​‌​​​‌​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​‌‌​​​​‌​​‌​‌​​‌‌‌​​‌​‌‌​‌​‌‌‌​‌​​​‌​​‌​‌‌‌‌‌​​​​‌‌​​‌​​​‌‌​​​​​​‌‌​​‌​​​‌‌​‌‌​​​‌​‌‌​‌​​‌‌​​​‌​​‌‌​​​‌​​‌​‌‌​‌​​‌‌​​‌​​​‌‌​‌​‌⁠
from pathlib import Path
import json,hashlib,shutil,datetime
ROOT=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PACK=ROOT/'outputs/蓝色星原简体汉化独立版'
OLD=ROOT/'outputs/台服简体汉化独立版'

tw_plan=json.loads((ROOT/'work/official_game_patch/deployment-plan.json').read_text('utf8'));assert tw_plan['patch_revision']==6
tw_files=[dict(relative_path=f['relative_path'],source_sha256=f['source_sha256'],target_sha256=f['target_sha256'],previous_sha256=f.get('previous_sha256',[]),candidate=f['candidate']) for f in tw_plan['files']]
tw_files.append(dict(relative_path='resources.assets',source_sha256='f96fc1afe1675cdabd3c3d54008b539e89e3e65399511aa23cfc864b91c74d9f',target_sha256='5c1af532a79dbae32a297418c0782447960142e8c95d28bbfb099b5301206b25',previous_sha256=[],candidate=str(ROOT/'work/game_bootstrap_zhcn.resources.assets')))

GAMES=[dict(id='tw_game',label='台服游戏',version='资源 3221745',exe='AzurPromilia.exe',data_dir='AzurPromilia_Data',
  marker_dir='.res/default_package/ManifestFiles',marker_filter='0release_default_package_*.bytes',
  search_subpaths=['AzurPromilia_TC/AzurPromilia_TC_game','AzurPromilia_TC_game'],registry_patterns=['Azurpromilia_TC*','藍色星原*'],
  process_names=['AzurPromilia.exe','sdkbrowser.exe'],backup_folder_name='.zhcn-official-3221745-backup',files=tw_files)]
LAUNCHERS=[
 dict(id='tw_launcher',label='台服启动器',version='1.0.1.4',exe='launcher.exe',relative_path='resources/app.asar',backup_suffix='.before-zhcn-20261124.bak',
  source_sha256='30b1d20cf58649f553fa4cf3b006f26a847958fd2cf2a005b410baf178d3eafa',target_sha256='42a6240ba33f793c247fb44cd5fdf211670a9256c09513366155277912393a47',
  previous_sha256=['1b9de08cf73e5c44e98b26d06df58b7a0d36d2fb7629c6014b413f35c548c1e3','67a4704230cc64b328e4945ce032b0417e7a17254e27eb0b7d5f8dc086e1367f'],
  candidate=str(ROOT/'work/launcher_complete.app.asar'),search_subpaths=['AzurPromilia_TC'],registry_patterns=['Azurpromilia_TC*','藍色星原*']),
 dict(id='jp_launcher',label='日服启动器',version='1.8.1',exe='AZUPRO_JP_Gamelauncher.exe',relative_path='resources/app.asar',backup_suffix='.before-zhcn-20261124.bak',
  source_sha256='4f013026736f6afa819a37f299caa9577140e88254ef4097b4d4589fa47f0818',target_sha256='32e4bf1a78bba0c5ab910bcacc7580ff109d3cfdb68741474284e9a1e03a63b3',
  previous_sha256=[],candidate=str(ROOT/'work/launcher_jp_zhcn.app.asar'),
  search_subpaths=['YostarGames/AZUPRO_JP_Gamelauncher','AZUPRO_JP_Gamelauncher','YostarGames'],registry_patterns=['アズールプロミリア*','bbbc3006-6fe5-52d1-8f2c-e554c31fefef'])]

for old in (PACK,OLD):
 if old.exists():shutil.rmtree(old)
(PACK/'tools').mkdir(parents=True)
out_games=[];out_launchers=[];total=0
for g in GAMES:
 g=dict(g);g['payload_dir']=g['id'];files=[]
 for f in g['files']:
  c=Path(f.pop('candidate'));assert sha(c)==f['target_sha256'],f['relative_path']
  d=PACK/'payload'/g['id']/f['relative_path'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(c,d);f['size']=d.stat().st_size;total+=f['size'];files.append(f)
 g['files']=files;out_games.append(g)
for L in LAUNCHERS:
 L=dict(L);L['payload_dir']=L['id'];c=Path(L.pop('candidate'));assert sha(c)==L['target_sha256'],L['id']
 d=PACK/'payload'/L['id']/L['relative_path'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(c,d);L['size']=d.stat().st_size;total+=L['size'];out_launchers.append(L)
plan=dict(pack_title='蓝色星原：旅谣 简体汉化',author='尔安',build_id='QUktR0VORVJBVEVEfOWwlOWuiXwyMDI2LTExLTI1',patch_revision=6,built_at=datetime.datetime.now().astimezone().isoformat(),games=out_games,launchers=out_launchers)
(PACK/'tools/deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
shutil.copyfile(ROOT/'work/standalone_pack/Apply-OfficialZH.ps1',PACK/'tools/Apply-OfficialZH.ps1')
bat=('@echo off\r\nrem QUktR0VORVJBVEVEfOWwlOWuiXwyMDI2LTExLTI1\r\nchcp 65001 >nul\r\ncd /d "%~dp0"\r\n'
 'if "%~1"=="" (\r\n  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\\Apply-OfficialZH.ps1"\r\n'
 ') else (\r\n  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\\Apply-OfficialZH.ps1" -Hint "%~1"\r\n)\r\necho.\r\npause\r\n')
(PACK/'双击运行-汉化或还原.bat').write_bytes(bat.encode('ascii'))
rows='\n'.join(f"| {x['label']} | {x['version']} |" for x in out_games+out_launchers)
readme=f'''# 蓝色星原：旅谣 简体汉化独立版（第 6 版）

## 使用方法

1. 把整个文件夹（含 `payload`、`tools`）完整解压到任意位置，路径可以有中文和空格。
2. 完全退出游戏和启动器（包括右下角托盘图标）。
3. 双击 `双击运行-汉化或还原.bat`。脚本会自动查找下表中的项目，列出位置和当前状态，然后按菜单输入数字：

| 选项 | 作用 |
|---|---|
| 1 | 全部汉化（找到的所有项目） |
| 2 | 全部还原 |
| 3 | 选择项目汉化（输入编号，多个用逗号分隔） |
| 4 | 选择项目还原 |
| 5 | 查看文件状态 |

只装了其中一部分（例如只装台服）也可以，没找到的项目会自动跳过。不需要国服、Python 或其他工具。

## 支持的项目与版本

| 项目 | 版本 |
|---|---|
{rows}

每个文件都按 SHA-256 校验。某个项目更新后版本不符时，只跳过该项目，不修改它的任何文件，其他项目照常处理。

## 自动识别路径

依次检查：系统“已安装程序”登记、正在运行的游戏或启动器、补丁所在的上级目录、各磁盘根目录和常见游戏文件夹（Games、游戏、Program Files 等）。

找不到时，可以把安装文件夹拖到 BAT 图标上，或在提示时拖进窗口回车。

游戏装在需要管理员权限的目录时，会自动请求管理员权限。

## 修改内容

- 台服游戏：357 张语言表（剧情、对话、选项、道具等）、界面固定文字、启动提示、字体、健康提示图，以及登录 SDK（`union_pcsdk.dll`、`sdkbrowser.exe`）的文字资源，共 {len(out_games[0]["files"])} 个文件。采用国服官方简体文案；语言设置仍为 cht，区服、账号、服务器不变。
- 台服 / 日服启动器：界面、设置、提示和窗口标题改为简体，图片和 Logo 不变。

## 备份与还原

- 台服游戏原版备份：游戏目录下 `.zhcn-official-3221745-backup`。
- 启动器原版备份：各启动器 `resources\\app.asar.before-zhcn-20261124.bak`（与之前的启动器 BAT 通用）。
- 选 2 即可还原。请不要删除这些备份。写入中途出错会自动回滚到操作前状态。

## 注意

- 登录 SDK 文件修改后数字签名不再匹配，没有绕过任何校验；若无法启动，请选 2 还原。
- 游戏或启动器更新后，请先还原（或用启动器校验修复），等待新版补丁。
- 未覆盖：服务器下发的公告用词（如“伺服器”只转了字形）、图片里画上去的繁体字、约 400 条台服独有且国服没有对应文本的界面文字（已转简体字形）。
'''
shutil.copyfile(ROOT/'work/standalone_pack/使用说明.txt',PACK/'使用说明.txt')
print(json.dumps(dict(items=[x['label'] for x in out_games+out_launchers],game_files=len(out_games[0]['files']),bytes=total),ensure_ascii=False))