import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
fixture=ROOT/'bat_jp_qa'/'游戏 测试 & 路径'
version=fixture/'AZUPRO_JP_Gamelauncher';resources=version/'resources';resources.mkdir(parents=True,exist_ok=True)
exe=version/'AZUPRO_JP_Gamelauncher.exe'
if not exe.exists():exe.write_bytes(b'Test fixture only; never executed.')
source=Path(r'E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar.before-zhcn-20261124.bak')
target=resources/'app.asar';backup=resources/'app.asar.before-zhcn-20261124.bak'
shutil.copy2(source,target)
if backup.exists():
 assert hashlib.sha256(backup.read_bytes()).hexdigest()=='4f013026736f6afa819a37f299caa9577140e88254ef4097b4d4589fa47f0818'
bat=fixture/'汉化工具 & 测试.bat'
shutil.copy2(ROOT.parent/'outputs'/'日服启动器简体汉化与还原.bat',bat)
original='4f013026736f6afa819a37f299caa9577140e88254ef4097b4d4589fa47f0818'
patched='32e4bf1a78bba0c5ab910bcacc7580ff109d3cfdb68741474284e9a1e03a63b3'
checks=[]
def run(action,expected,argument=None,success=True):
 command=f'cmd.exe /d /s /c ""{bat}"'+(f' "{argument}"' if argument else '')+'"'
 r=subprocess.run(command,input=action+'\n\n',encoding='utf-8',errors='replace',capture_output=True,cwd=fixture,timeout=60)
 text=r.stdout+r.stderr
 assert (r.returncode==0)==success,(r.returncode,text)
 assert 'is not recognized' not in text and '�' not in text,text
 assert '1. 汉化为简体中文' in text and '2. 还原原版启动器' in text and 'Q. 退出' in text,text
 assert expected in text,text
 checks.append({'action':action,'expect':expected,'exit_code':r.returncode,'output':text})
run('1','简体汉化完成！')
assert hashlib.sha256(target.read_bytes()).hexdigest()==patched
assert hashlib.sha256(backup.read_bytes()).hexdigest()==original
run('1','当前已经是完整简体汉化版本。')
run('2','已成功还原原版启动器。')
assert hashlib.sha256(target.read_bytes()).hexdigest()==original
run('Q','Q. 退出')
run('2','当前已经是原版，无需还原。',argument=fixture)
run('1','指定路径没有匹配的日服启动器',argument=r'D:\AzurPromilia',success=False)
shutil.copy2(ROOT.parent/'outputs'/'日服启动器简体汉化与还原.bat',fixture/'lf_only.bat')
# ASCII CMD stub is also safe when an editor changes CRLF to LF.
lf=fixture/'lf_only.bat';lf.write_bytes(lf.read_bytes().replace(b'\r\n',b'\n'))
bat=lf
run('Q','Q. 退出')
run('2','当前已经是原版，无需还原。',argument=fixture)
(ROOT/'bat_jp_validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'cases':len(checks),'chinese_space_ampersand_path':True,'automatic_location':str(version),'auto_backup':True,'apply_restore_hashes':True,'refuse_cn_launcher':True,'lf_line_endings':True},ensure_ascii=False,indent=2))
