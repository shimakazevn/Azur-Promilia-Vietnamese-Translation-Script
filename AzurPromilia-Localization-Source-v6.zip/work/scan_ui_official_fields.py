"""Read UI serialized text defaults and compare matching official counterparts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import defaultdict
import json,re,sys,hashlib
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'work/game_decrypt_bundle'))
from unity_setup import UnityPy
OUT=ROOT/'work/official_parity_audit'
catalog=json.loads((OUT/'ui-counterparts.json').read_text('utf8'))
groups={}
for row in catalog:
 t=row['tw']
 if t['path'].endswith('.prefab') or (t['path'].endswith('.asset') and '/Font' not in t['path'] and '/StaticText/' not in t['path']):
  groups.setdefault(t['bundle'],[]).append(row)
han=re.compile(r'[\u3400-\u9fff]')
fields={'m_text','m_Text','text','Text','title','Title','content','Content','label','Label','placeholder','Placeholder'}
def read_segment(meta):
 with Path(meta['pack']).open('rb') as f:f.seek(meta['offset']);return f.read(meta['size'])
def extract(raw):
 e=UnityPy.load(raw);objects=list(e.objects);names={};texts=[]
 for o in objects:
  if o.type.name=='GameObject':
   try:names[o.path_id]=o.read_typetree().get('m_Name','')
   except Exception:pass
 for o in objects:
  if o.type.name!='MonoBehaviour':continue
  try:tree=o.read_typetree()
  except Exception:continue
  go=tree.get('m_GameObject',{}).get('m_PathID',0);script=tree.get('m_Script',{})
  def walk(v,path='',key=''):
   if isinstance(v,str):
    if key in fields and han.search(v):
     texts.append(dict(object_id=o.path_id,game_object=names.get(go,''),script=script,field=path,text=v))
   elif isinstance(v,dict):
    for k,x in v.items():walk(x,path+'.'+k,k)
   elif isinstance(v,list):
    if len(v)>20000:return
    for i,x in enumerate(v):walk(x,path+f'[{i}]',key)
  walk(tree)
 return texts
def task(rows):
 meta=rows[0]['tw'];result=dict(bundle=meta['bundle'],paths=[r['tw']['path'] for r in rows],source=meta)
 try:
  texts=extract(read_segment(meta));result['tw_texts']=texts
  if texts:
   cnmeta=next((r['cn'] for r in rows if r['cn']),None)
   if cnmeta:result['cn_texts']=extract(read_segment(cnmeta));result['cn_source']=cnmeta
 except Exception as ex:result['error']=type(ex).__name__+': '+str(ex)[:180]
 return result
total=len(groups);done=hits=errors=0
with (OUT/'serialized-ui-text-fields.jsonl').open('w',encoding='utf8') as f,ThreadPoolExecutor(max_workers=4) as executor:
 futures=[executor.submit(task,rows) for rows in groups.values()]
 for future in as_completed(futures):
  row=future.result();done+=1
  if row.get('tw_texts') or row.get('error'):
   f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush()
  hits+=bool(row.get('tw_texts'));errors+=bool(row.get('error'))
  if done%100==0:print(json.dumps(dict(done=done,total=total,text_bundles=hits,errors=errors)),flush=True)
report=dict(scanned_bundles=done,requested_bundles=total,text_bundles=hits,errors=errors,installed_modified=False,
            scope='serialized MonoBehaviour visible-text-named fields containing Han; excludes fonts/static table already audited')
(OUT/'serialized-ui-scan-summary.json').write_text(json.dumps(report,indent=2),'utf8')
print(json.dumps(report),flush=True)
