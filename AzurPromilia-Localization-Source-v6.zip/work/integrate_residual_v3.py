from pathlib import Path
from collections import defaultdict
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'work/official_game_patch_v3'
sys.path.insert(0,str(ROOT/'work/game_compare_manifests'))
from patch_manifest import replace_pack_segments,patch_manifest
sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads((OUT/'text-stage-plan.json').read_text('utf8'))
data=Path(plan['data_root']);groups=defaultdict(lambda:dict(sha=None,manifests=defaultdict(dict)))

for item in json.loads((ROOT/'work/font_proper_name_v3/segment-plan.json').read_text('utf8')):
 p=Path(item['sourcePack']);g=groups[p]
 assert g['sha'] in (None,item['currentSHA256'])
 g['sha']=item['currentSHA256'];payload=Path(item['segmentCandidate']).read_bytes()
 assert sha(payload)==item['candidateSHA256']
 for m in item['manifests']:
  g['manifests'][Path(m['manifestPath'])][m['bundleIndex']]=payload
ui=json.loads((ROOT/'work/game_decrypt_bundle/ui-v3-changes.json').read_text('utf8'))
for item in ui['packs']:
 p=Path(item['installedPath']);g=groups[p]
 assert g['sha'] in (None,item['currentSHA'])
 g['sha']=item['currentSHA']
 assert sha(Path(item['candidatePath']).read_bytes())==item['candidateSHA']
 for m in item['manifestPaths']:
  for s in item['segmentReplacements']:
   assert s['bundleIndex'] not in g['manifests'][Path(m)]
   g['manifests'][Path(m)][s['bundleIndex']]=Path(s['candidateSegmentPath']).read_bytes()
staged={};manifests={};reports=[]
for p,g in groups.items():
 original=p.read_bytes();assert sha(original)==g['sha'],str(p)
 packed=None
 for mp,replacements in g['manifests'].items():
  if mp not in manifests:
   manifests[mp]=mp.read_bytes()
   assert mp.with_suffix('.hash').read_bytes()==hashlib.md5(manifests[mp]).hexdigest().encode('ascii')
  out,nm,_,r=replace_pack_segments(manifests[mp],p,replacements,original)
  if packed is not None:assert packed==out
  packed=out;manifests[mp]=nm;reports.append(dict(pack=str(p),manifest=str(mp),**r))
  print('Staged',p.name,'in',mp.name,flush=True)
 dest=OUT/p.relative_to(data);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);staged[p]=dest
for mp,payload in manifests.items():
 for p,g in groups.items():
  if mp in g['manifests']:
   current=staged[p].read_bytes();_,_,r=patch_manifest(payload,p,current,current);assert r['original_validated']
 dest=OUT/mp.relative_to(data);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 dest.with_suffix('.hash').write_bytes(hashlib.md5(payload).hexdigest().encode('ascii'))
 staged[mp]=dest;staged[mp.with_suffix('.hash')]=dest.with_suffix('.hash')
for p,candidate in staged.items():
 rel=p.relative_to(data).as_posix();entry=next(f for f in plan['files'] if f['relative_path']==rel)
 entry['previous_sha256']=sorted(set(entry.get('previous_sha256',[])+[entry['target_sha256']]))
 entry.update(target_sha256=sha(candidate.read_bytes()),candidate=str(candidate),size=candidate.stat().st_size)
plan['residual_v3'].update(startup_changes=ui['packs'][0]['changes'],
                         proper_name_glyph_restored=True,
                         plaintext_pool=str(OUT/'vstring-patched.bin'),
                         plaintext_table=str(OUT/'table-data-patched.bin'))
(OUT/'deployment-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf8')
(OUT/'integration-report.json').write_text(json.dumps(dict(installed_modified=False,
    files=len(plan['files']),segment_changes=reports,final_crcs_verified=True),ensure_ascii=False,indent=2),'utf8')
(OUT/'Apply-OfficialZH.ps1').write_text((ROOT/'work/deploy_official_patch.ps1').read_text('utf8'),'utf-8-sig')
print(json.dumps(dict(files=len(plan['files']),additional_changed_files=len(staged))),flush=True)
