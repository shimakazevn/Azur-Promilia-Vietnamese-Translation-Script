from pathlib import Path
import sys,io,json,struct,hashlib
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'game_decrypt_bundle'),str(BASE/'game_compare_manifests'),str(BASE/'analysis_deps'),str(BASE/'font_deps')]
from unity_setup import UnityPy
from reencrypt_bundle import wrap
from fontTools.ttLib import TTFont
from parse_manifest import parse
from patch_manifest import encode_name
OUT=Path(__file__).resolve().parent
ROOT=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data')
CPS=[0x4E7E,0x7B8B]
KEEP=[0x95C7]
spec=[('a00',ROOT/'StreamingAssets/.res/default_package/a66pm5ie1rrjguuzlsyq.r','cn_a00.otf','120cec42d77110361d0900a99bac4b3be5aff4df973705e5d0516b80806d1b75'),('c00',ROOT/'StreamingAssets/.res/default_package/p4hifvtlpthiunufa1lslg.r','official_chs_c00.otf','0d91d5ed1becc79fe29c72559fd3eb6806ca0193288534570e8ccf2519c4b672'),('b00',ROOT/'.res/default_package/BundleFiles/owmxh3bjdhcwjoabqv67q.r','cn_b00.otf','49877b94b705c214a2fcd024f77dbbc5f8c73a342eb9c329b0bba0e4243565f2')]
manifestpaths=[ROOT/'StreamingAssets/.res/default_package/0release_default_package_3060618.bytes',ROOT/'.res/default_package/ManifestFiles/0release_default_package_3221745.bytes']
manifests=[(p,parse(p)) for p in manifestpaths];report=[]
for name,p,official,v4sha in spec:
 raw=p.read_bytes();cur=hashlib.sha256(raw).hexdigest();assert cur==v4sha,(name,cur)
 size=struct.unpack_from('>Q',raw,24)[0];segment=raw[:size];env=UnityPy.load(segment);bundle=next(iter(env.files.values()));before={o.path_id:o.get_raw_data() for o in env.objects}
 obj=next(o for o in env.objects if o.type.name=='Font' and o.read_typetree()['m_Name']==name);tree=obj.read_typetree()
 oldfont=TTFont(io.BytesIO(bytes(tree['m_FontData'])));font=TTFont(io.BytesIO(bytes(tree['m_FontData'])));orig=TTFont(BASE/'game_decrypt_bundle'/official).getBestCmap()
 for k in KEEP:assert oldfont.getBestCmap()[k]==orig[k]
 muts=[];oldmaps=[dict(t.cmap) if hasattr(t,'cmap') else None for t in font['cmap'].tables]
 for cp in CPS:
  g=orig[cp];og=oldfont.getBestCmap()[cp]
  if og==g:continue
  for t in font['cmap'].tables:
   if t.isUnicode() and hasattr(t,'cmap') and cp in t.cmap:t.cmap[cp]=g
  muts.append({'unicode':f'U+{cp:04X}','char':chr(cp),'oldGlyph':og,'newGlyph':g})
 data=io.BytesIO();font.save(data);newbytes=data.getvalue();chk=TTFont(io.BytesIO(newbytes))
 for cp in CPS+KEEP:assert chk.getBestCmap()[cp]==orig[cp]
 changed={int(m['unicode'][2:],16) for m in muts}
 for i,t in enumerate(chk['cmap'].tables):
  if oldmaps[i] is not None:assert {k:v for k,v in t.cmap.items() if k not in changed}=={k:v for k,v in oldmaps[i].items() if k not in changed}
 assert oldfont.getGlyphOrder()==chk.getGlyphOrder()
 a=oldfont['CFF '].cff.topDictIndex[0].CharStrings;b=chk['CFF '].cff.topDictIndex[0].CharStrings
 for g in oldfont.getGlyphOrder():
  x=a[g];y=b[g];x.decompile();y.decompile();assert x.program==y.program
 tree['m_FontData']=list(newbytes);obj.save_typetree(tree);plain=bundle.save(packer='lz4');candidate,nblocks=wrap(plain,segment);dest=OUT/(name+'_official_glyph_segment.r');dest.write_bytes(candidate)
 check=UnityPy.load(candidate);after={o.path_id:o.get_raw_data() for o in check.objects};assert [i for i in before if before[i]!=after[i]]==[obj.path_id]
 assert bytes(next(o for o in check.objects if o.path_id==obj.path_id).read_typetree()['m_FontData'])==newbytes
 refs=[]
 for mp,m in manifests:
  for pi,pack in enumerate(m['packs']):
   if encode_name(pack['name0'],pack['name1'])!=p.name:continue
   for bi,bb in enumerate(m['bundles']):
    if bb['pack_id']==pi and bb['offset']==0:assert bb['size']==size;refs.append({'manifestPath':str(mp),'bundleIndex':bi,'packIndex':pi,'offset':0,'oldSize':size})
 report.append({'sourcePack':str(p),'currentSHA256':cur,'packSize':len(raw),'offset':0,'oldSize':size,'segmentCandidate':str(dest),'candidateSize':len(candidate),'candidateSHA256':hashlib.sha256(candidate).hexdigest(),'fontPathId':obj.path_id,'mutations':muts,'kept':['U+95C7'],'manifests':refs,'unrelatedObjectBytesPreserved':True,'allOtherCmapEntriesPreserved':True,'allGlyphOutlineProgramsPreserved':True,'glyphOrderPreserved':True,'fontDataReloadVerified':True,'blockRoundtrips':nblocks})
(OUT/'segment-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=1))