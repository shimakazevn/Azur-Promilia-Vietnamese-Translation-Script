import sys,json,subprocess,shutil,hashlib
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
here=Path(__file__).parent.resolve();m=json.loads((here/'game_language_trial.json').read_text('utf-8'))
folder=here/'game_language_trial_qa'/'游戏 测试 & 路径';(folder/'AzurPromilia_Data').mkdir(parents=True,exist_ok=True)
target=folder/'AzurPromilia_Data/resources.assets';tool=Path(m['tool']);checks=[]
def run(action,expected,success=True):
    r=subprocess.run(f'cmd.exe /d /s /c ""{tool}" "{folder}""',input=action+'\n\n',encoding='utf-8',errors='replace',capture_output=True,timeout=30)
    text=r.stdout+r.stderr
    assert (r.returncode==0)==success,text
    assert expected in text and '\ufffd' not in text and 'is not recognized' not in text,text
    checks.append(dict(action=action,output=text,exit_code=r.returncode))
for v in m['variants']:
    shutil.copy2(v['source'],target)
    run('1','已切换 language=chs')
    assert hashlib.sha256(target.read_bytes()).hexdigest()==v['after']
    run('1','当前已经是 language=chs')
    run('2','已还原本次语言试验')
    assert hashlib.sha256(target.read_bytes()).hexdigest()==v['before']
    run('2','当前已经是试验前状态')
b=bytearray(target.read_bytes());b[900000]^=1;target.write_bytes(b)
run('1','文件版本或内容已变化',False)
run('Q','不代表已完成全量汉化')
(here/'game_language_trial_qa.json').write_text(json.dumps(dict(passed=True,cases=len(checks),checks=checks),ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS',len(checks),'cases')
