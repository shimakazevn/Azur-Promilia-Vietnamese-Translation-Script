import sys,json,hashlib,csv,io
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
root=Path.cwd();sys.path.insert(0,str(root/'work/analysis_deps'))
import UnityPy
out=root/'work/game_compare';out.mkdir(exist_ok=True)
report={}
for tag,game in [('cn',Path(r'D:\AzurPromilia\AzurPromilia_Game')),('tw',Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game'))]:
 data=game/'AzurPromilia_Data';source=data/'resources.assets';env=UnityPy.load(str(source));texts={};assets=[]
 for obj in env.objects:
  if obj.type.name=='TextAsset':
   a=obj.read();text=a.m_Script;raw=text.encode('utf-8',errors='surrogateescape');texts[a.m_Name]=text
   assets.append(dict(name=a.m_Name,path_id=obj.path_id,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
   if a.m_Name in ['builtInLangString','txt_buildInAssetPathMap','chineseCharacters']:(out/f'{tag}_{a.m_Name}.txt').write_bytes(raw)
 cfg=json.loads(texts['appConfig']);safe={k:cfg.get(k) for k in ['appVersion','assetVersion','channel','region','language','supportedLanguage','configVersionPatch']}
 report[tag]=dict(root=str(game),unity=env.file.unity_version if hasattr(env.file,'unity_version') else None,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),text_assets=assets,config=safe,config_fields=list(cfg))
 report[tag]['table_rows']=len(list(csv.DictReader(io.StringIO(texts['builtInLangString'].lstrip('\ufeff')))))
 print(json.dumps({tag:report[tag]},ensure_ascii=False,indent=2))
(out/'resources-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
