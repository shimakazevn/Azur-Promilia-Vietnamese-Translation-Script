import sys,json,struct,hashlib,re,ast
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).parent
def parse(path):
 data=path.read_bytes(); h=json.loads(data[16:16+struct.unpack_from('<I',data,12)[0]]); base=8+struct.unpack_from('<I',data,4)[0]
 out={}
 def walk(h,p=''):
  for k,v in h.get('files',{}).items():
   if 'files' in v: walk(v,p+k+'/')
   elif 'offset' in v: out[p+k]=data[base+int(v['offset']):base+int(v['offset'])+v['size']]
 walk(h);return out
cn=parse(Path(r'D:\AzurPromilia\1.0.1.1\resources\app.asar'))
tw=parse(Path(r'E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak'))
for tag,items in [('cn',cn),('tw',tw)]:
 dest=ROOT/('launcher_'+tag);dest.mkdir(exist_ok=True)
 for k,v in items.items():
  if k.endswith(('.js','.json','.html')):
   p=dest/k;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(v)
 langs={}
 for k,v in items.items():
  if k.endswith('.js'):
   text=v.decode('utf-8')
   for m in re.finditer(r'(\d+):function\(e\)\{"use strict";e.exports=JSON.parse\((\x27(?:\\.|[^\x27\\])*\x27)\)\}',text):
    d=json.loads(ast.literal_eval(m[2]))
    if 'BTN_MAIN_START' in d: langs[m[1]]=d
 (dest/'dictionaries.json').write_text(json.dumps(langs,ensure_ascii=False,indent=2),encoding='utf-8')
 print(tag,'members',len(items),'dictionaries',[(k,len(v),sum(not x for x in v.values())) for k,v in langs.items()])
 print('preload',items.get('preload.js',b'').decode())
 print('package',items.get('package.json',b'').decode())
common=set(cn)&set(tw)
different=[k for k in sorted(common) if cn[k]!=tw[k]]
report={'cn_only':sorted(set(cn)-set(tw)),'tw_only':sorted(set(tw)-set(cn)),'changed_common':different,'same_members':len(common)-len(different)}
(ROOT/'launcher_comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
