from pathlib import Path
from collections import Counter
import json,sys
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/font_deps'),str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/game_decrypt_paths')]
from fontTools.ttLib import TTFont
from vstring_pool import VStringPool
from parse_language_tables import read_index,read_rows
old=TTFont(ROOT/'work/game_decrypt_bundle/cn_a00.otf').getBestCmap()
new=TTFont(ROOT/'work/font_display_probe/a00_traditional_display_as_simplified.otf').getBestCmap()
remap={chr(cp) for cp in new if cp in old and old[cp]!=new[cp] and cp!=ord('闇')}
pool=VStringPool(ROOT/'work/official_game_patch_v3/vstring-patched.bin')
table=(ROOT/'work/official_game_patch_v3/table-data-patched.bin').read_bytes()
_,langs,_=read_index(table);hits=[];counts=Counter()
for name,off in langs['cht'].items():
 for row in read_rows(table,off,pool):
  matched=sorted(set(row['value'] or '')&remap)
  if matched:counts.update(matched);hits.append(dict(table=name,id=row['id'],value=row['value'],mapped_characters=''.join(matched)))
report=dict(affected_rows=len(hits),characters=dict(counts),samples=hits[:25],all_affected=hits)
(ROOT/'work/official_parity_audit/font-official-wording-impact.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k!='all_affected'},ensure_ascii=True),flush=True)
