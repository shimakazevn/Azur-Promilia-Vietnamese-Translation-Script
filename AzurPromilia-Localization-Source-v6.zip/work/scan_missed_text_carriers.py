from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
targets=['關閉','開啟','恢復默認設定','警告：遊戲前詳細閱讀','有極少數的人在觀看','登入成功','切換帳號','正在檢查更新','伺服器尚未開放','星躍始動']
files=list((ROOT/'work/game_mmap/decoded').glob('tw_update_*.bin'))+[ROOT/'work/game_decrypt_paths/tw-global-metadata-decrypted.dat']
plugin=Path(r'E:\AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data\Plugins\mj_sdk')
files += [plugin/'union_pcsdk.dll',plugin/'sdkbrowser.exe']
rows=[]
for p in files:
 b=p.read_bytes()
 for text in targets:
  for enc in ['utf8','utf-16-le']:
   n=text.encode(enc);offsets=[];pos=0
   while (pos:=b.find(n,pos))>=0:
    offsets.append(pos);pos+=len(n)
   if offsets:rows.append(dict(file=str(p),text=text,encoding=enc,count=len(offsets),sample_offsets=offsets[:8]))
(ROOT/'work/missed-text-carriers.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(rows,ensure_ascii=True),flush=True)
