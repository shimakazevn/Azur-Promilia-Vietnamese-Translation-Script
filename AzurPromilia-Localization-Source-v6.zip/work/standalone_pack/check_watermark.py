from pathlib import Path
import base64, re
PACK = Path(r'C:\Users\xiaoxi\Documents\Codex\2026-11-24\new-chat\outputs\蓝色星原简体汉化独立版')
Z1, ZB = '\u200c', '\u2060'
def unzw(t):
    out = []
    for m in re.finditer(ZB + '([\u200b\u200c]+)' + ZB, t):
        bits = ''.join('1' if c == Z1 else '0' for c in m.group(1))
        out.append(bytes(int(bits[i:i+8], 2) for i in range(0, len(bits), 8)).decode())
    return out
def unb64(t): return [base64.b64decode(m).decode() for m in set(re.findall(r'QUktR0VORVJBVEVE[A-Za-z0-9+/=]+', t))]
for f in ['双击运行-汉化或还原.bat', '使用说明.txt', 'tools/Apply-OfficialZH.ps1', 'tools/deployment-plan.json']:
    t = (PACK/f).read_text('utf-8-sig', errors='replace')
    print(f, '| base64:', unb64(t), '| zero-width x', len(unzw(t)), unzw(t)[:1])
print('visible usage tail:', repr((PACK/'使用说明.txt').read_text('utf-8-sig').strip().splitlines()[-1][:6]))