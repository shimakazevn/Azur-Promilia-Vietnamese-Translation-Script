from pathlib import Path
W = Path(r'C:\Users\xiaoxi\Documents\Codex\2026-11-24\new-chat')
u = W/'work/standalone_pack/使用说明.txt'
x = u.read_text('utf-8-sig')
warn = '- 开服后若登录异常请还原文件，此脚本未进行反作弊验证。'
if warn not in x:
    assert '说明：\n' in x
    x = x.replace('说明：\n', '说明：\n' + warn + '\n', 1)
u.write_text(x, 'utf-8-sig')
print('ok', warn in u.read_text('utf-8-sig'))