from pathlib import Path
W = Path(r'C:\Users\xiaoxi\Documents\Codex\2026-11-24\new-chat')
p = W/'work/standalone_pack/Apply-OfficialZH.ps1'
s = p.read_text('utf-8-sig')
old_t = '    Write-Host ("  {0}" -f $plan.pack_title)\n'
old_a = '    if ($plan.author) { Write-Host ("  制作：{0}" -f $plan.author) }\n'
assert old_t in s and old_a in s, 'anchors'
new_t = '    if ($plan.author) { Write-Host ("  {0}/{1}" -f $plan.pack_title, $plan.author) } else { Write-Host ("  {0}" -f $plan.pack_title) }\n'
new_a = '    Write-Host \'  开服后若登录异常请还原文件，此脚本未进行反作弊验证\' -ForegroundColor Red\n'
s = s.replace(old_t, new_t, 1).replace(old_a, new_a, 1)
p.write_text(s, 'utf-8-sig')
u = W/'work/standalone_pack/使用说明.txt'
x = u.read_text('utf-8-sig')
assert '制作：尔安' in x
x = x.replace('制作：尔安', '/尔安', 1)
warn = '- 开服后若登录异常请还原文件，此脚本未进行反作弊验证。'
if warn not in x:
    x = x.replace('说明：\r\n', '说明：\r\n' + warn + '\r\n', 1)
u.write_text(x, 'utf-8-sig')
print('edited')