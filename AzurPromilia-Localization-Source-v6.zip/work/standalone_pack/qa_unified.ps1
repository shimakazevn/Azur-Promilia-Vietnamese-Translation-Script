﻿$ErrorActionPreference = 'Stop'
function Sha($p){$s=[IO.File]::OpenRead($p);$a=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($a.ComputeHash($s)).Replace('-','').ToLower()}finally{$a.Dispose();$s.Dispose()}}
$W = 'C:\Users\xiaoxi\Documents\Codex\2026-11-24\new-chat'
$pack = Join-Path $W 'outputs\蓝色星原简体汉化独立版'
$ps = Join-Path $pack 'tools\Apply-OfficialZH.ps1'
$plan = Get-Content (Join-Path $pack 'tools\deployment-plan.json') -Raw -Encoding UTF8 | ConvertFrom-Json
'##### LIVE VERIFY (read-only) #####'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Verify 2>&1 | Out-String -Width 220
'exit=' + $LASTEXITCODE
$stamp = Get-Date -Format 'yyyyMMddHHmmss'
$qa = Join-Path $W ("work\standalone_qa_$stamp\测试 & 路径")
$g = 'E:\AzurPromilia_TC\AzurPromilia_TC_game'; $bk = Join-Path $g '.zhcn-official-3221745-backup'
$gq = Join-Path $qa 'AzurPromilia_TC\AzurPromilia_TC_game'
New-Item -ItemType Directory -Force (Join-Path $gq 'AzurPromilia_Data') | Out-Null
[IO.File]::WriteAllText((Join-Path $gq 'AzurPromilia.exe'),'dummy')
$gm = $plan.games[0]
foreach ($f in $gm.files) {
  $rel = $f.relative_path -replace '/','\'
  $dst = Join-Path (Join-Path $gq 'AzurPromilia_Data') $rel
  New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
  if ($rel -eq 'resources.assets') { $src = Join-Path $g 'AzurPromilia_Data\resources.assets.before-game-zhcn-20261124.bak' } else { $src = Join-Path $bk $rel }
  Copy-Item -LiteralPath $src -Destination $dst
  if ((Sha $dst) -ne $f.source_sha256) { throw "seed mismatch $rel" }
}
$launchers = @(@{d=(Join-Path $qa 'AzurPromilia_TC\1.0.1.4'); src='E:\AzurPromilia_TC\1.0.1.4\resources\app.asar.before-zhcn-20261124.bak'; i=0}, @{d=(Join-Path $qa 'YostarGames\AZUPRO_JP_Gamelauncher'); src='E:\YostarGames\AZUPRO_JP_Gamelauncher\resources\app.asar.before-zhcn-20261124.bak'; i=1})
foreach ($lc in $launchers) {
  $LP = $plan.launchers[$lc.i]
  New-Item -ItemType Directory -Force (Join-Path $lc.d 'resources') | Out-Null
  [IO.File]::WriteAllText((Join-Path $lc.d $LP.exe),'dummy')
  Copy-Item -LiteralPath $lc.src -Destination (Join-Path $lc.d 'resources\app.asar')
  if ((Sha (Join-Path $lc.d 'resources\app.asar')) -ne $LP.source_sha256) { throw "launcher seed mismatch $($LP.label)" }
}
"QA root: $qa"
function Count($field) {
  $n = 0
  foreach ($f in $gm.files) { if ((Sha (Join-Path (Join-Path $gq 'AzurPromilia_Data') ($f.relative_path -replace '/','\'))) -eq $f.$field) { $n++ } }
  foreach ($lc in $launchers) { if ((Sha (Join-Path $lc.d 'resources\app.asar')) -eq $plan.launchers[$lc.i].$field) { $n++ } }
  return $n
}
$total = @($gm.files).Count + 2
'##### APPLY ALL #####'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Apply -Hint $qa -OnlyHint 2>&1 | Out-String -Width 220
'exit=' + $LASTEXITCODE + "  patched $(Count 'target_sha256')/$total"
'##### APPLY AGAIN #####'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Apply -Hint $qa -OnlyHint 2>&1 | Out-String -Width 220
'##### RESTORE ONLY JP LAUNCHER (item 3) #####'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Restore -Select 3 -Hint $qa -OnlyHint 2>&1 | Select-Object -Last 4 | Out-String -Width 220
'jp state original: ' + ((Sha (Join-Path $launchers[1].d 'resources\app.asar')) -eq $plan.launchers[1].source_sha256)
'##### RESTORE ALL #####'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Restore -Hint $qa -OnlyHint 2>&1 | Select-Object -Last 8 | Out-String -Width 220
'exit=' + $LASTEXITCODE + "  restored $(Count 'source_sha256')/$total"
'##### MISMATCH: corrupt sdkbrowser, apply all #####'
$m = Join-Path $gq 'AzurPromilia_Data\Plugins\mj_sdk\sdkbrowser.exe'
$fs = [IO.File]::OpenWrite($m); $fs.Seek(0,'End') | Out-Null; $fs.WriteByte(0); $fs.Dispose()
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Apply -Hint $qa -OnlyHint 2>&1 | Out-String -Width 220
'exit=' + $LASTEXITCODE
$gOrig = 0; foreach ($f in $gm.files) { if ((Sha (Join-Path (Join-Path $gq 'AzurPromilia_Data') ($f.relative_path -replace '/','\'))) -eq $f.source_sha256) { $gOrig++ } }
'game files still original: ' + $gOrig + '/' + @($gm.files).Count + ' (expect ' + (@($gm.files).Count - 1) + ')'
'launchers patched: ' + @($launchers | Where-Object { (Sha (Join-Path $_.d 'resources\app.asar')) -eq $plan.launchers[$_.i].target_sha256 }).Count + '/2'
'leftover stage files: ' + @(Get-ChildItem -LiteralPath $qa -Recurse -Filter '*.zhcn-stage-*' -Force).Count
'leftover snapshot files: ' + @(Get-ChildItem -LiteralPath $qa -Recurse -Force -File | Where-Object { $_.FullName -match 'rollback\\' }).Count
'##### EMPTY HINT DIR #####'
$empty = Join-Path $W ("work\standalone_qa_$stamp\empty"); New-Item -ItemType Directory -Force $empty | Out-Null
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps -Action Verify -Hint $empty -OnlyHint 2>&1 | Select-Object -Last 2 | Out-String -Width 220
'exit=' + $LASTEXITCODE