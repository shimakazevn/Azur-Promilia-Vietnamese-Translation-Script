from pathlib import Path
import base64, re, json
W = Path(r'C:\Users\xiaoxi\Documents\Codex\2026-11-24\new-chat')
MARK = 'AI-GENERATED|尔安|2026-11-25'
B64 = base64.b64encode(MARK.encode()).decode()
Z0, Z1, ZB = '\u200b', '\u200c', '\u2060'
def zw(s): return ZB + ''.join(Z1 if b == '1' else Z0 for c in s.encode() for b in f'{c:08b}') + ZB
ZWM = zw(MARK)

# 1) deploy script: help block (base64), hidden variable, zero-width comments
p = W/'work/standalone_pack/Apply-OfficialZH.ps1'
s = p.read_text('utf-8-sig')
if B64 not in s:
    s = s.replace('param(', '<#\n.NOTES\n  build: ' + B64 + '\n#>\n# ' + ZWM + '\nparam(', 1)
    s = s.replace('$script:hashCache = @{}', '$script:hashCache = @{}\n$script:buildTag = \'' + B64 + '\'', 1)
    s = s.replace('# ---------------- 主流程 ----------------', '# ---------------- 主流程 ----------------' + ZWM, 1)
    s = s.replace('# ---------------- 汉化 / 还原 ----------------', '# ---------------- 汉化 / 还原 ----------------' + ZWM, 1)
    p.write_text(s, 'utf-8-sig')

# 2) build script: comment + BAT rem line + plan field
b = W/'work/build_standalone_pack.py'
t = b.read_text('utf-8')
if B64 not in t:
    t = t.replace('from pathlib import Path', '# build: ' + B64 + ' ' + ZWM + '\nfrom pathlib import Path', 1)
    old = "'@echo off\\r\\nchcp"
    assert old in t, 'bat anchor'
    t = t.replace(old, "'@echo off\\r\\nrem " + B64 + "\\r\\nchcp", 1)
    assert "author='尔安'," in t, 'plan anchor'
    t = t.replace("author='尔安',", "author='尔安',build_id='" + B64 + "',", 1)
    b.write_text(t, 'utf-8')

# 3) usage txt: zero-width after signature
u = W/'work/standalone_pack/使用说明.txt'
x = u.read_text('utf-8-sig')
if ZB not in x:
    x = x.replace('制作：尔安', '制作：尔安' + ZWM, 1)
    u.write_text(x, 'utf-8-sig')
print('sources marked')