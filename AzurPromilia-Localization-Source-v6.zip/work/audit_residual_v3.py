from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/game_compare_manifests'),str(ROOT/'work/game_decrypt_paths')]
from vstring_pool import VStringPool
from parse_language_tables import read_index,read_rows
OUT=ROOT/'work/official_game_patch_v3';OUT.mkdir(exist_ok=True)
pool=VStringPool(ROOT/'work/official_game_patch/vstring-patched.bin')
cn=VStringPool(ROOT/'work/game_mmap/decoded/cn_update_bjzqzapbodx6zodmvtrta.bin')
table=(ROOT/'work/official_game_patch/table-data-patched.bin').read_bytes()
ct=(ROOT/'work/game_decrypt_paths/cn-update-table-data.bin').read_bytes()
_,langs,_=read_index(table);_,clangs,_=read_index(ct)
terms=['未入駐','当前状态不能切換','正在編譯著色器','闇星庇佑']
matches=[]
for name,off in langs['cht'].items():
 rows=read_rows(table,off,pool)
 hit=[r for r in rows if any(t in (r['value'] or '') for t in terms)]
 if hit:
  reference={r['id']:r for r in read_rows(ct,clangs['chs'][name],cn)}
  for row in hit:
   rr=reference.get(row['id'])
   matches.append(dict(table=name,**row,cn=rr['value'] if rr else None))
poolhits=[]
for k in range(pool.count):
 s=pool[k]
 if s and any(t in s for t in terms):poolhits.append(dict(key=k,value=s))
report=dict(language_rows=matches,pool_matches=poolhits)
(OUT/'residual-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=True),flush=True)
